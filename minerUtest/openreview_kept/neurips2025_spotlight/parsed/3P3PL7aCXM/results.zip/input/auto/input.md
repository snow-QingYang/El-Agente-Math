# ErrorTrace: A Black-Box Traceability Mechanism Based on Model Family Error Space

Chuanchao Zang1, Xiangtao Meng1, Wenyu Chen1, Tianshuo Cong2,6, Yaxing $\mathrm { Z h a } ^ { 3 }$ , Dong $\mathrm { Q i ^ { 4 } }$ , Zheng Li1,5,6,\*, Shanqing Guo1,5,6,\*

1School of Cyber Science and Technology, Shandong University 2School of Cryptologic Science and Engineering, Shandong University 3China Transportation Information Technology Group Co., Ltd., China 4Shandong Branch, China United Network Communications Group Co., Ltd., China 5State Key Laboratory of Cryptography and Digital Economy Security, Shandong University 6Shandong Key Laboratory of Artificial Intelligence Security, Shandong University

# Abstract

The open-source release of large language models (LLMs) enables malicious users to create unauthorized derivative models at low cost, posing significant threats to intellectual property (IP) and market stability. Existing IP protection methods either require access to model parameters or are vulnerable to fine-tuning attacks. To fill this gap, we propose ErrorTrace, a robust and black-box traceability mechanism for protecting LLM IP. Specifically, ErrorTrace leverages the unique error patterns of model families by mapping and analyzing their distinct error spaces, enabling robust and efficient IP protection without relying on internal parameters or specific query responses. Experimental results show that ErrorTrace achieves a traceability accuracy of 0.8518 for 27 base models when the suspect model is not included in ErrorTrace’s training set, outperforming the baseline by 0.2593. Additionally, ErrorTrace successfully tracks 34 finetuned, pruned, and merged models across various scenarios, demonstrating its broad applicability and robustness. In addition, ErrorTrace shows a certain level of resilience when subjected to adversarial attacks. Our code is available at: https://github.com/csdatazcc/ErrorTrace.

# 1 Introduction

Large language models (LLMs) have advanced rapidly in recent years, with increasing model sizes and expanding training datasets significantly improving their capabilities in language understanding and generation (1; 20; 28; 47). However, these advancements come at the cost of requiring both substantial computational resources and deep domain expertise (27), raising critical concerns about model copyright and intellectual property (IP) rights. One major concern is the risk of unauthorized use and repackaging of original models. Malicious actors can fine-tune open models and claim them as their own, undermining the contributions of the original developers (10; 26; 27; 28). A notable case in 2024 involved a group of Stanford University students allegedly plagiarizing MiniCPM-Llama3-V2.5, a Chinese open-source model developed by Facade Intelligence (39).1

To protect LLM IP, various traceability methods have been proposed. Watermarking, the most prominent approach, typically requires modifying the original model parameters (2; 3; 15; 16; 25; 34; 38; 43), while other methods avoid modifying the model but still require access to its parameters (21; 42; 37; 40; 41). Thus, these methods are limited to white-box settings, which restricts their applicability. Black-box query-based methods rely on carefully designed prompts but often involve high computational costs or require human expertise. They are also sensitive to changes in model behavior, such as those introduced by fine-tuning, which limits their robustness (8; 11; 18).

To fill this gap, we propose implicit fingerprinting via data-driven error analysis—a black-box mechanism that identifies the likely family origin of a suspicious model based solely on its error patterns. Instead of relying on white-box access or carefully crafted queries, our method analyzes the statistical consistency of prediction errors to uncover distinctive failure behaviors shared within a model family. The core insight driving our method is that how models fail can be more revealing than where they succeed. While correct outputs may arise from convergent behaviors across in

![](images/5306d9ad1c81a15bf042f32b524cad8582eb7795abdf4572ee690659cd79ad67.jpg)  
Figure 1: (a) Intersection of erroneous data from different family models. (b) Error space dimensionality reduction display.

dependently trained models, consistent and uncommon errors often reflect deeper shared characteristics—such as architectural biases, training regimes, or optimization strategies (see details in Appendix D). Analogous to human behavior, rare mistakes shared by multiple individuals can imply similar training or background; likewise, models from the same family tend to exhibit stable and structured error patterns, whereas models from different families display more diverse failure distributions. This phenomenon is empirically validated in Figure 1a, which shows significantly higher error similarity within families than across unrelated models (see section 3 for details).

Building on this insight, we introduce ErrorTrace, a black-box traceability framework for LLM IP protection. Given a set of data samples, we extract each model family’s error patterns and embed them into an error space via graph-based analysis (illustrated in Figure 1b). A suspect model’s error behavior is then projected into this space to infer its likely family affiliation, enabling reliable lineage attribution without internal access or watermarking.

We evaluate our method on five benchmark datasets and 27 models from four popular LLM families. The results show that our method achieves $100 \%$ traceability accuracy when the suspect model exists in ErrorTrace’s model set, and $8 5 . 1 8 \%$ when it does not exist, outperforming the baseline by $2 5 . 9 3 \%$ . Additionally, our method performs well across various fine-tuning, pruning, and merging strategies. In addition, ErrorTrace shows a certain level of resilience when subjected to adversarial attacks.

Contributions. Our contributions are three-fold:

• A novel traceability perspective: We introduce a new approach to model traceability by analyzing error space differences across model families, providing new insights into LLM IP protection.   
• An effective and adaptable method: We construct a model family error space using unique error patterns and graph-based connections, enabling reliable traceability even among models with similar architectures.   
• Comprehensive evaluation: We validate our method on 27 models from four families, which range from 3B to 141B, this marks the first instance of achieving such a wide range of traceability verification. Our approach outperforms baselines and accurately traces all fine-tuned, pruned, and merged models, demonstrating its effectiveness and robustness.

# 2 Threat Model and Related Works

# 2.1 Threat Model

The auditor, either the original model owner or a third-party detection agency, has full access to the original model but only black-box access to the suspect model, i.e., <query, output> pairs.

A suspect model is one modified through unauthorized fine-tuning or other actions that infringe on the original model’s IP. It typically has two characteristics: similarity to the original model in architecture and knowledge, and concealment of its link to the original model.

# 2.2 Traceability Methods

In the LLM era, traceability methods can be broadly classified into three categories.

Modifying Model Parameters: Researchers have explored embedding watermarks into LLMs (2; 3; 12; 13; 15; 16; 19; 23; 25; 31; 34; 35; 36; 38; 43; 46). However, these methods require model modifications, increasing training costs and potentially impacting performance. Besides, it cannot be applied to released models without protection unless retrained, limiting its practicality.

Accessing Model Parameters: These methods compare internal parameters, features, or output logits to assess model similarity (21; 37; 40; 41; 42). However, their practicality is limited since most major LLMs provide only external APIs.

Query-based Traceability: These methods identify suspect models by analyzing responses to specific queries. TRAP (8) ,ProFLingo (11) generate a query and expect a specified response, but are limited by high query costs and variable response rates in fine-tuned models. LLMmap (18) assesses output similarity using empirical queries, but its robustness declines against adversarial obfuscation.

# 2.3 Traceability Granularity

Model-level traceability is widely used in LLM IP protection to identify the specific base model behind a suspect. However, existing black-box methods often lack robustness and are vulnerable to interference (38). For large-scale developers (e.g., Meta), protecting every individual model is computationally costly. In contrast, model family-level traceability focuses on identifying the broader model family, reducing overhead while aligning with the needs of developers—key stakeholders in IP disputes. By leveraging shared features within a family, it remains effective even after fine-tuning or pruning. It also avoids dependence on fixed queries, offering greater robustness against adaptive attacks and input perturbations.

# 3 Exploring the Potential of Error Space for Traceability

This section explores the feasibility of using model error spaces for traceability. We present a probabilistic model showing that error patterns are statistically distinct across model families and validate this through experimental simulations.

Consider model families $G _ { 1 } , G _ { 2 } , \ldots , G _ { n }$ , each containing models $M _ { 1 } , M _ { 2 } , \dots , M _ { m }$ , and a dataset $D = \{ d _ { 1 } , d _ { 2 } , \dots , d _ { N } \}$ with $N$ samples. For model $M _ { i }$ and data $d _ { j }$ , define the binary random variable $E _ { i j }$ as follows:

$$
E _ { i j } = \{ \begin{array} { l l } { { 1 } } & { { \mathrm { i f } M _ { i } \mathrm { p r e d i c t s  i n c o r r e c t l y o n } d _ { j } } } \\ { { 0 } } & { { \mathrm { o t h e r w i s e } } } \end{array}
$$

Each model’s error pattern is represented by the binary vector $\mathbf { E } _ { i } = ( E _ { i 1 } , \dots , E _ { i N } )$ . Model traceability aims to identify the family $G _ { k }$ based on $\mathbf { E } _ { i }$ . For mathematical validation, we make the following assumptions:

1. Independence Assumption: The error events on different data points are independent.   
2. Family Distinguishability Assumption: Models from different families have significantly different error probabilities on certain data points.   
3. Completeness Assumption: The error events for all models on all data points are observable and recorded completely.

Table 1: The tracing success rate for logistic regression (LR), decision trees (DT), and random forests (RF) is evaluated across varying data quantities and proportions of erroneous data.   

<table><tr><td>Number</td><td>Rate</td><td>LR</td><td>DT</td><td>RF</td></tr><tr><td>5000</td><td>0.01 0.05 0.1</td><td>0.00 0.60 0.60</td><td>0.60 0.40 0.20</td><td>0.20 0.80 0.40</td></tr><tr><td>10000</td><td>0.01 0.05 0.1</td><td>0.60 1.00 0.60</td><td>0.20 0.40 0.40</td><td>0.60 0.80 0.60</td></tr><tr><td>50000</td><td>0.01 0.05 0.1</td><td>0.80 1.00 1.00</td><td>0.00 0.20 0.20</td><td>0.20 0.60 0.60</td></tr><tr><td colspan="2">Average</td><td>0.69</td><td>0.29</td><td>0.53</td></tr></table>

Consider the suspicious model $M _ { i }$ and its error pattern $\mathbf { E } _ { i }$ on dataset $D$ . Assuming independence, the error event $E _ { i j }$ for each data point $d _ { j }$ is independent. Thus, the joint probability distribution of $\mathbf { E } _ { i }$

is the product of the individual error event probabilities. To determine the model family of $M _ { i }$ , the problem reduces to comparing the joint probability distribution of $\mathbf { E } _ { i }$ across different model families.

$$
P ( \mathbf { E } _ { i } | M _ { i } \in G _ { k } ) = \prod _ { j = 1 } ^ { N } P _ { G _ { k } , j } ^ { E _ { i j } } ( 1 - P _ { G _ { k } , j } ) ^ { ( 1 - E _ { i j } ) }
$$

where $P r _ { G _ { k } , j } = P ( E _ { i j } = 1 | M _ { i } \in G _ { k } )$ is the error probability of family $G _ { k }$ on data point $d _ { j }$

Based on the assumption of family distinguishability, for model families $G _ { a }$ and $G _ { b }$ , there exists a data point $j$ such that $P _ { G _ { a } , j } \neq P _ { G _ { b } , j }$ . Thus, the joint probability distribution of the error pattern $\mathbf { E } _ { i }$ differs across model families. The suspicious model can be assigned to a family based on these probabilistic differences.

![](images/f59beae38ae4ec033a62fa82dd0de12a9ef1fe6ad06ad8ff8b3866e678ec7ca0.jpg)  
Figure 2: (a) The impact of error probability difference on traceability accuracy; (b) The impact of model family size on traceability accuracy.

To validate our approach, we run a traceability experiment using a synthetic dataset across four model families. Each family has defined error-prone data points with varying error probabilities. We use Logistic Regression (LR), Decision Trees (DT), and Random Forests (RF) for classification. As shown in Table 1, each family includes four models with a 0.2 error rate difference. LR and RF both achieve accuracy above 0.5, supporting the feasibility of using error patterns for traceability.

We further analyze the effect of model count and error rates using 10,000 data

points at a 0.1 error rate. Figure 2 shows LR and RF improve with more models and greater error differences, while DT is less consistent. This indicates that more erroneous data enhances traceability. (See Appendix K for details.)

# 4 Methodology of ErrorTrace

We propose ErrorTrace, a novel black-box traceability method for LLM IP protection. As shown in Figure 3, ErrorTrace consists of three steps: error uniqueness calculation, error space construction, and suspect model inference. This section explains how the classification benchmark constructs the error space; the regression case is provided in Appendix B.

![](images/3443e7f7bc9975c59b1083ffbc48907922f978304738c48dd66a04e275fa8b34.jpg)  
Figure 3: The overview of error space-based traceability mechanism ErrorTrace.

# 4.1 Error Uniqueness Calculation

For a model family $T$ with $N$ LLMs from the same familis, we first sample a prompt dataset $S$ covering various topics to approximate the input space. Each prompt in $S$ represents a data point $s$ . We then calculate the error uniqueness of each data point $s$ for the model family $T$ , considering two key aspects:

Intra-family Error Uniqueness. This aspect calculates the error uniqueness of data point $s$ across all models in family $T$ , represented by $U$ . The simplest approach is to calculate the proportion of models in $T$ that make errors on $s$ . However, we observe that higher-performing models better reflect the family’s unique error characteristics; thus, we weight errors by model accuracy, assigning greater weight to errors from high-performing models, as shown in Equation 3.

$$
U = \sum _ { j \in E } p _ { j } \bigg / \sum _ { i = 1 } ^ { N } p _ { i }
$$

Here, $E$ denotes the set of LLMs in the target family that generate an error response on data point $s$ , and $p$ represents the accuracy of the test model on the topic related to $s$ .

Cross-family Error Discrepancy. This aspect verifies whether the error patterns at data point $s$ are unique to model family $T$ . We introduce the cross-family error discrepancy $P F$ as a penalty factor to filter out shared error data points across different families. Instead of treating all non-target families as a group, we compute the error rate for each non-target family at $s$ and assign higher penalty weights to families with higher error rates using squared summation, as shown in Equation 4.

$$
P F = 1 - \sum _ { j \in G } P _ { j } ^ { 2 } \Bigg / \sum _ { i = 1 } ^ { K } P _ { i }
$$

Let $G$ represent the set of model families whose models produce errors on data point $s$ , $P _ { j }$ denote the error rates of $s$ for family $j$ , and $K$ be the number of model families excluding family $T$ .

To better mitigate the impact of error-prone points in non-target families, we incorporate model performance into the calculation of $P F$ . The error rate $P$ for each non-target family at data point $s$ is defined as:

$$
P _ { j } = \sum _ { j \in E } p _ { j } \bigg / \sum _ { i = 1 } ^ { N } p _ { i }
$$

Thus, the error uniqueness of data points $s$ in a certain model family $T$ can be expressed as:

$$
W P _ { ( s , T ) } = U \times P F
$$

# 4.2 Error Space Construction

In the previous section, we calculated the error uniqueness for all data points in the model family $T$ . Now, we construct the error space for $T$ using a graph-based approach. Unlike traditional methods like K-Means (17), DBSCAN (5), and GMM (22), we avoid this limitation by assigning each data point a weight based on its error uniqueness. Edge weights between data points are determined by their Euclidean distances, which we normalize using the Cumulative Distribution Function (CDF) (6) to reduce the impact of extreme values.

$$
F ( D _ { ( i , j ) } ) = P ( D \leq D _ { ( i , j ) } )
$$

Where $D ( i , j )$ represents the distance between data points $i$ , $j$ and $\mathrm { F }$ is the CDF function.

Using a single CDF mapping overlooks the effect of adjacent distance intervals. To address this, we introduce an interval-based CDF weighting mechanism. We first sort all edge distances $D _ { ( i , j ) }$ in ascending order to obtain a sequence $d _ { 1 } , d _ { 2 } , \ldots , d _ { n }$ , where $n$ is the total number of edges and $d _ { i }$ is the $i ^ { \mathrm { { t h } } }$ distance.Then define $w _ { j }$ as the difference between consecutive sorted distances $d _ { j + 1 }$ and $d _ { j }$ . The new mapping formula is defined as:

$$
W E ( d _ { i } ) = \sum _ { j = 1 } ^ { i - 1 } w _ { j } \Bigg / \sum _ { k = 1 } ^ { n - 1 } w _ { k }
$$

where $W E ( d _ { i } )$ represents the weighted normalized value of the distance $d _ { i }$ .

To improve computational efficiency, we use a grid search approach to identify the densest region of edge weights (denoted as dense), and the filtered edge set $L$ is defined as:

$$
L = E d g e ( W E ( d _ { i } ) \leq d e n s e )
$$

where Edge represents the original set of edges, and $L$ is the filtered set of edges.

We construct candidate error spaces for each model family $T$ using graph-based connections. Starting from the point with the highest error uniqueness, we apply BFS (4) to connect neighboring points. A point is added if its uniqueness exceeds the edge weight; otherwise, it is skipped. This process continues until no further connections can be made. We repeat it for remaining unassigned points to form all candidate error spaces (see Figure 4).

To determine the optimal error space for model family $T$ , we compute the effective uniqueness sum for each dataset and select the error space with the highest sum as the optimal error space. This is denoted as:

$$
R ( k ) = \sum _ { s \in S } W P ( s ) - \sum _ { l \in L ^ { \prime } } W E ( l )
$$

where $k$ is the set of candidate error spaces, $S$ represents all points contained in the space, $L ^ { ' }$ represents all edges used in the connection.

# 4.3 Suspect Model Inference

For each error space, we progressively reduce its size by increasing the minimum error uniqueness. For a suspect model $M _ { s }$ , we track the average error rate change during this contraction. We compute $\Delta$ , the difference between the maximum change and the average of the remaining changes. If $\Delta < \tau$ , the model shows no strong alignment with any family and is considered out-of-distribution. If $\Delta \geq \tau$ , the family with the largest change is identified as the source. To ensure fairness, we normalize contraction by fixing the number of remaining points at the start and end. See details in Appendix C.

![](images/6f541cb8a709dec9a4bc329f530c7ae124a5c9619e81d6585293918665044473.jpg)  
Figure 4: Example diagram of error space construction

# 5 Experiment

# 5.1 Experimental Setup

Models: We use 27 models to build error space, ranging from $^ { 3 \mathrm { ~ B ~ } }$ to $1 4 1 \ \mathrm { B }$ parameters, across families like LLaMa, Qwen, Mistral, and Gemma (see Appendix A).

Datasets: We use five benchmark datasets namely Multinli (33), PAWS (45), CoLA (32), AG News (44), and CommonsenseQA (24) to find error data. See details in Appendix N.

Baselines: Since ErrorTrace is a black-box traceability mechanism, we compare with black-box baselines, i.e., LLMmap (18), TRAP (8), and ProFLingo (11), which use query-based tracing. Due to space limitation, we introduce TRAP (8), ProFlingo (11) and the LLMmap (18) processing in Appendix F.

Metrics: We evaluate traceability using three metrics: accuracy (ACC), cosine distance, and model family discrepancy (MFD). Cosine distance measures the similarity between a test model’s features and the mean features of each family—a smaller value indicates stronger alignment. This also allows direct comparison with LLMmap, which uses a similar approach. MFD detects out-of-distribution (OOD) models by measuring how much a test model’s embedding deviates from the structure of known model families.

Traceability Scenario: We consider three scenarios to evaluate ErrorTrace, namely model set known, model set unknown, and real-world scenario. In the model set known scenario, all base models contribute to constructing the error space, while also serving as test models. In model set unknown scenario, we designate one model as the suspect and construct error spaces using the remaining 26 models, this is a more challenging scenario. In the real-world scenario, the suspect model is modified through a series of fine-tuning, pruning, and merging methods.

Table 2: Cosine similarity in model set unknown scenario   

<table><tr><td rowspan="2"></td><td rowspan="2">Model</td><td colspan="5">LLMmap</td><td colspan="5">Ours</td></tr><tr><td> Gemma</td><td>Qwen</td><td>LLaMa</td><td> Mistral</td><td>ACC</td><td>Gemma</td><td>Qwen</td><td>LLaMa</td><td> Mistral</td><td>ACC</td></tr><tr><td rowspan="7">LLaMa</td><td>LLama7b</td><td>0.327</td><td>0.376</td><td>0.386</td><td>0.561</td><td>×</td><td>1.188</td><td>1.293</td><td>0.009</td><td>1.012</td><td></td></tr><tr><td>LLama70b</td><td>0.341</td><td>0.432</td><td>0.303</td><td>0.599</td><td>√</td><td>1.166</td><td>1.346</td><td>0.007</td><td>1.01</td><td>√</td></tr><tr><td>LLama3:8b</td><td>0.405</td><td>0.445</td><td>0.311</td><td>0.562</td><td>√</td><td>1.370</td><td>1.227</td><td>0.360</td><td>1.660</td><td>√</td></tr><tr><td>LLama3:70b</td><td>0.388</td><td>0.489</td><td>0.226</td><td>0.526</td><td>√</td><td>1.643</td><td>1.170</td><td>0.283</td><td>1.304</td><td></td></tr><tr><td>LLama3.2:3b</td><td>0.366</td><td>0.426</td><td>0.398</td><td>0.506</td><td>×</td><td>1.105</td><td>1.241</td><td>0.039</td><td>1.387</td><td></td></tr><tr><td>LLama3.1:8b</td><td>0.366</td><td>0.509</td><td>0.433</td><td>0.564</td><td>×</td><td>0.928</td><td>1.716</td><td>0.218</td><td>0.581</td><td></td></tr><tr><td>LLama:13b</td><td>0.327</td><td>0.376</td><td>0.386</td><td>0.561</td><td>×</td><td>1.802</td><td>0.689</td><td>0.492</td><td>0.758</td><td>√</td></tr><tr><td rowspan="3">Gemma</td><td>Gemma7b</td><td>0.606</td><td>0.574</td><td>0.469</td><td>0.560</td><td>×</td><td>0.641</td><td>1.667</td><td>1.324</td><td>1.116</td><td>√</td></tr><tr><td>Gemma2:9b</td><td>0.333</td><td>0.363</td><td>0.268</td><td>0.568</td><td>×</td><td>1.662</td><td>0.299</td><td>1.313</td><td>0.567</td><td>×</td></tr><tr><td>Gemma2:27b</td><td>0.217</td><td>0.390</td><td>0.426</td><td>0.579</td><td>√</td><td>1.928</td><td>0.238</td><td>1.065</td><td>1.087</td><td>×</td></tr><tr><td rowspan="9">Qwen</td><td>Qwen7b</td><td>0.315</td><td>0.110</td><td>0.375</td><td>0.519</td><td></td><td>1.237</td><td>0.120</td><td>1.116</td><td>0.970</td><td></td></tr><tr><td>Qwen72b</td><td>0.342</td><td>0.068</td><td>0.468</td><td>0.577</td><td></td><td>1.382</td><td>0.013</td><td>1.431</td><td>1.317</td><td>√</td></tr><tr><td>Qwen3b</td><td>0.296</td><td>0.118</td><td>0.471</td><td>0.563</td><td></td><td>1.270</td><td>0.096</td><td>1.007</td><td>1.321</td><td></td></tr><tr><td>Qwen32b</td><td>0.423</td><td>0.229</td><td>0.459</td><td>0.538</td><td>√</td><td>1.597</td><td>0.018</td><td>1.381</td><td>1.233</td><td></td></tr><tr><td>Qwen2:7b Qwen14b</td><td>0.258 0.295</td><td>0.157</td><td>0.386 0.293</td><td>0.507</td><td>√</td><td>1.236</td><td>0.058</td><td>1.521</td><td>1.372</td><td></td></tr><tr><td></td><td>0.246</td><td>0.304 0.385</td><td>0.403</td><td>0.504</td><td>×</td><td>1.466</td><td>0.016</td><td>1.366</td><td>1.397</td><td></td></tr><tr><td>Qwen1.5:7b Qwen1.5:72b</td><td>0.585</td><td>0.469</td><td>0.506</td><td>0.496 0.601</td><td>×</td><td>1.355</td><td>0.399</td><td>0.625</td><td>0.814</td><td></td></tr><tr><td>Qwen1.5:4b</td><td>0.429</td><td>0.156</td><td>0.403</td><td>0.504</td><td></td><td>1.590 1.412</td><td>0.046 0.003</td><td>1.076 1.363</td><td>1.407</td><td></td></tr><tr><td>Qwen1.5:32b</td><td>0.406</td><td>0.262</td><td>0.281</td><td>0.493</td><td></td><td>1.024</td><td>0.136</td><td>1.482</td><td>1.273 0.987</td><td>√</td></tr><tr><td>Qwen1.5:14b</td><td>0.474</td><td>0.482</td><td>0.539</td><td>0.117</td><td>X</td><td>1.487</td><td>0.038</td><td>1.240</td><td>1.001</td><td>√</td></tr><tr><td rowspan="5">Mistral</td><td>Mixtral</td><td>0.434</td><td>0.487</td><td>0.483</td><td>0.142</td><td></td><td>0.893</td><td>0.577</td><td>1.747</td><td>0.401</td><td></td></tr><tr><td>Mistral7b</td><td>0.370</td><td>0.471</td><td>0.343</td><td>0.617</td><td>×</td><td>0.710</td><td>0.679</td><td>1.564</td><td>0.335</td><td>√</td></tr><tr><td>Mistral:small</td><td>0.457</td><td>0.491</td><td>0.483</td><td>0.085</td><td></td><td>1.026</td><td>0.930</td><td>1.335</td><td>0.055</td><td></td></tr><tr><td>Mistral:nemo</td><td>0.543</td><td>0.521</td><td>0.537</td><td>0.057</td><td>√</td><td>1.669</td><td>1.150</td><td>0.821</td><td>0.422</td><td>：</td></tr><tr><td>Mistral:large</td><td>0.588</td><td>0.508</td><td>0.496</td><td>0.207</td><td>√</td><td>1.1241</td><td>0.137</td><td>1.172</td><td>1.303</td><td>×</td></tr><tr><td>Mixtral:8x22B</td><td>0.306</td><td></td><td>0.237</td><td>0.275</td><td>0.351</td><td>×</td><td>1.389</td><td>0.293</td><td>1.818</td><td>0.819</td><td>×</td></tr><tr><td colspan="10"></td><td colspan="3"></td></tr></table>

Prompt Template: To minimize information leakage, we restrict prompt wording, limiting the suspect model’s association with its family. All prompt templates are provided in Appendix L.

# 5.2 Effectiveness

This section evaluates our method in three key areas: error space construction, traceability of models, and comparison of space search methods. We define the error space contraction process, setting start and end numbers at 1200 and 600 points (the reasons for selection are shown in Figure 6b and Appendix E).

First, our method effectively captures each model’s error space, clearly separating different families. As shown in Figure 5a, error data across families have near-zero

![](images/579db5c1ce30845d3936150cff471ee615bbd42213c82f2cee28ac22403cb344.jpg)  
Figure 5: (a) Model family error space error intersection; (b) Average change on different error spaces.

overlap, confirming the isolation of family-specific patterns. In the known model set scenario, all 27 test models are correctly traced to their families. Figure 5b further shows that each family has positive alignment within its own space and negative alignment elsewhere. See Appendix I for details.

![](images/a842235f3699671a8adfc2fb7e8db30cec0d29868664d7d37e2387c8eb357a25.jpg)  
Figure 6: (a) The effect of query numbers on LLMmap; (b) Comparison of the highest accuracy of ErrorTrace and LLMmap.

scale distribution is uneven (see details in section 7).

Second, our method performs well in the more challenging unknown model set scenario. Each model is tested as a suspect using the remaining 26 to build error spaces. As shown in Table 2, our method achieves $8 5 . 1 8 \%$ accuracy (23/27), significantly outperforming LLMmap’s $5 9 . 2 5 \%$ (16/27).

In this scenario, four models were misidentified. Two were from the Gemma family, likely due to having only two models left to construct a reliable error space. LLMmap also struggled with these. The other two were large Mistral models (Mixtral: ${ 8 } { \bf { x } } 2 2 { \bf { B } }$ and Mistral-large), whose

Furthermore, our method outperforms traditional space construction techniques (e.g., K-Means, DBSCAN, GMM) in identifying effective error spaces for model traceability. Using grid search for fair comparison, the

<table><tr><td>Methods</td><td>K-Means</td><td>DBSCAN</td><td>GMM</td><td>Ours</td></tr><tr><td> Accuracy</td><td>0.4074</td><td>0.4444</td><td>0.6666</td><td>0.8518</td></tr></table>

Table 3: Accuracy of different construction methods.

best baseline achieves only $6 6 . 6 6 \%$ accuracy, well below our $8 5 . 1 8 \%$ (Table 3). We also evaluate robustness to contraction intervals. Figure 6a shows LLMmap peaks at $5 9 . 2 5 \%$ when using all queries. In contrast, our method maintains high accuracy across varying intervals and consistently outperforms LLMmap (Figure 6b). These results underscore the superiority of our approach in error space identification and model traceability.

# 5.3 Impact of Dataset Size

We also test how dataset size affects ErrorTrace by randomly sampling from the original error set (Table 4). Performance improves with more data, and even at 20K samples, ErrorTrace significantly exceeds LLMmap’s best result.

Table 4: Accuracy at different dataset sizes.   

<table><tr><td>Size</td><td>20K</td><td>30K</td><td>40K</td><td>50K</td></tr><tr><td>Accuracy</td><td>0.7037</td><td>0.7778</td><td>0.8148</td><td>0.8518</td></tr></table>

# 5.4 Out-Of-Distribution Model Detection

We designate LLaMA as the out-of-distribution family and treat Gemma, Qwen, and Mistral as in-distribution. Using an optimal threshold $\tau = 0 . 0 2 5$ , we compute model family discrepancy for each model. For out-of-distribution evaluation, we test three unseen models: Falcon3-7B and Falcon3- 10B (different scales within the Falcon family), and DeepSeek-R1-7B (a different family). Table 5 shows that all these models have discrepancies below $\tau$ , confirming they are correctly identified as out-of-distribution and not part of any known family. This indicates that we can correctly identify these out-of-distribution models as not belonging to any of the in-distribution families.

<table><tr><td>Model</td><td>Gemma</td><td>Qwen</td><td>LLaMa</td><td>Mistral</td><td>MFD</td><td>ACC</td></tr><tr><td>Falcon3-7B</td><td>0.0014</td><td>0.0019</td><td>0.0014</td><td>0.0017</td><td>0.0124</td><td>?</td></tr><tr><td>Falcon3-10B</td><td>-0.0112</td><td>-0.0099</td><td>-0.0189</td><td>-0.0164</td><td>0.0167</td><td></td></tr><tr><td>DeepSeek-R1-7B</td><td>0.0067</td><td>0.0073</td><td>-0.0011</td><td>0.0012</td><td>0.0151</td><td>√</td></tr></table>

Table 5: Out-of-distribution model detection.

1. To visualize the MDF, this table presents the average change in the suspect model’s error rate within each model family’s error space, rather than cosine distance.

# 5.5 Robustness

<table><tr><td>Method</td><td>Model</td><td>Gemma</td><td>Qwen</td><td>LLama</td><td>Mistral</td><td>ACC</td></tr><tr><td rowspan="5"> LLMmap</td><td>mistral-openorca</td><td>0.360</td><td>0.347</td><td>0.308</td><td>0.413</td><td>×</td></tr><tr><td>mistrallite</td><td>0.607</td><td>0.609</td><td>0.593</td><td>0.682</td><td></td></tr><tr><td>Mistral-7B-Instruct</td><td>0.454</td><td>0.581</td><td>0.470</td><td>0.687</td><td></td></tr><tr><td>openhermes</td><td>0.260</td><td>0.415</td><td>0.290</td><td>0.510</td><td></td></tr><tr><td>zephyr</td><td>0.386</td><td>0.421</td><td>0.392</td><td>0.442</td><td>X</td></tr><tr><td rowspan="5">Ours</td><td>mistral-openorca</td><td>1.634</td><td>0.792</td><td>1.282</td><td>0.332</td><td></td></tr><tr><td>mistrallite</td><td>1.558</td><td>1.357</td><td>0.987</td><td>0.623</td><td>√</td></tr><tr><td>Mistral-7B-Instruct</td><td>1.494</td><td>0.906</td><td>1.257</td><td>0.203</td><td></td></tr><tr><td>openhermes</td><td>1.535</td><td>0.500</td><td>1.199</td><td>0.334</td><td></td></tr><tr><td>zephyr</td><td>1.255</td><td>1.142</td><td>0.886</td><td>0.074</td><td></td></tr></table>

Table 6: Comparison of different fine-tuned Mistral7B between ErrorTrace and LLMmap.

Fine-Tuned Variants of a Single Model. We evaluate robustness on fine-tuned variants of a model. As shown in Table 6, our method correctly identifies all five fine-tuned Mistral7B versions, while LLMmap misclassifies them. Details on LLaMa7B fine-tuning robustness are in Appendix H.

We now evaluate the robustness under the real-world scenario. We select LLaMa7B and Mistral7B for fine-tuning, as they have several fine-tuned versions, and also test Qwen and Gemma for different finetuning purposes. Note that all finetuned and trimmed models are downloaded from HuggingFace. See Appendix Appendix M for details.

Table 7: Traceability robustness experiment of pruning model.   

<table><tr><td></td><td>Model</td><td>Ratio</td><td>Strategy</td><td>Gemma</td><td>Qwen</td><td>LLaMa</td><td>Mistral</td><td>ACC</td></tr><tr><td rowspan="6">LLMmap</td><td>vicuna-5.5b-ppl</td><td>20%</td><td>Shortened-ppl</td><td>0.489</td><td>0.579</td><td>0.467</td><td>0.631</td><td>√</td></tr><tr><td>vicuna-3.7b-ppl</td><td>45%</td><td>Shortened-ppl</td><td>0.528</td><td>0.597</td><td>0.497</td><td>0.670</td><td>√</td></tr><tr><td>vicuna-2.7b-ppl</td><td>60%</td><td>Shortened-ppl</td><td>0.579</td><td>0.634</td><td>0.608</td><td>0.679</td><td>×</td></tr><tr><td>vicuna-5.5b-taylor</td><td>20%</td><td>Shortened-taylor</td><td>0.421</td><td>0.438</td><td>0.420</td><td>0.631</td><td>√</td></tr><tr><td>Sheared-LLaMA-2.7B</td><td>60%</td><td>Sheared</td><td>0.601</td><td>0.629</td><td>0.583</td><td>0.664</td><td>√</td></tr><tr><td>Sheared-LLaMA-1.3B</td><td>80%</td><td>Sheared</td><td>0.603</td><td>0.638</td><td>0.613</td><td>0.675</td><td>×</td></tr><tr><td rowspan="6">Ours</td><td>vicuna-5.5b-ppl</td><td>20%</td><td>Shortened-ppl</td><td>1.146</td><td>0.836</td><td>0.807</td><td>1.796</td><td></td></tr><tr><td>vicuna-3.7b-ppl</td><td>45%</td><td>Shortened-ppl</td><td>1.169</td><td>0.655</td><td>0.484</td><td>1.801</td><td></td></tr><tr><td>vicuna-2.7b-ppl</td><td>60%</td><td>Shortened-ppl</td><td>1.081</td><td>0.652</td><td>0.557</td><td>1.884</td><td></td></tr><tr><td>vicuna-5.5b-taylor</td><td>20%</td><td>Shortened-taylor</td><td>0.996</td><td>1.010</td><td>0.620</td><td>1.916</td><td></td></tr><tr><td>Sheared-LLaMA-2.7B</td><td>60%</td><td>Sheared</td><td>1.440</td><td>0.853</td><td>0.629</td><td>1.772</td><td>三</td></tr><tr><td>Sheared-LLaMA-1.3B</td><td>80%</td><td>Sheared</td><td>0.833</td><td>1.780</td><td>0.131</td><td>1.145</td><td></td></tr></table>

We then evaluate robustness against different pruning strategies and rates. Table 7 shows that ErrorTrace consistently identifies the model family, even at $60 \%$ and $80 \%$ pruning rates, demonstrating strong robustness across pruning methods. We also test ErrorTrace on various model

Table 8: Traceability robustness experiment of merging model.   

<table><tr><td>Strategy</td><td>Gemma</td><td>Qwen</td><td>LLaMa</td><td>Mistral</td><td>ACC</td></tr><tr><td>PPL</td><td>1.398</td><td>0.506</td><td>0.769</td><td>0.487</td><td>&gt;&gt;&gt;</td></tr><tr><td>Dare-Ties</td><td>1.586</td><td>1.185</td><td>0.652</td><td>0.356</td><td></td></tr><tr><td>Dare-Task</td><td>1.153</td><td>0.472</td><td>1.565</td><td>0.341</td><td></td></tr></table>

merging strategies for Mistral-7B V0.1 and V0.2 (7). Table 8 confirms our method successfully tracks the model’s origin.

Fine-Tuned Variants Within a Model Family. We further evaluate a harder scenario: fine-tuned variants within the Qwen family. Table 9 shows our method correctly identifies all five models, while LLMmap misclassifies three, including Qwen1.5:14B—mistakenly labeled as LLaMa with only a 0.001 cosine distance difference. This highlights LLMmap’s struggle to separate families, while our method effectively distinguishes error spaces with differences above 1, significantly outperforming LLMmap.

<table><tr><td>Method</td><td>Model</td><td>Gemma Qwen LLama Mistral ACC</td><td></td><td></td><td></td><td></td></tr><tr><td rowspan="4">LLMmap</td><td rowspan="4">Qwen-7B-Chat Qwen-14B-Chat Qwen2-math Qwen2.5-coder:7B</td><td rowspan="4">0.536 0.483</td><td>0.207 0.303</td><td>0.371 0.302</td><td>0.585</td><td></td></tr><tr><td></td><td></td><td>0.580</td><td>×</td></tr><tr><td>0.548 0.261</td><td>0.487</td><td>0.538</td><td>√</td></tr><tr><td>0.536 0.594</td><td>0.598</td><td>0.692</td><td>×</td></tr><tr><td rowspan="5">Ours</td><td>Qwen2.5-coder:14B Qwen-7B-Chat</td><td>1.719</td><td>0.317 0.634</td><td>0.506 1.549</td><td>0.542 0.856</td><td>√</td></tr><tr><td>Qwen-14B-Chat</td><td>1.982</td><td>0.378</td><td>0.934</td><td>1.076</td><td></td></tr><tr><td>Qwen2-math</td><td>0.865</td><td>0.618</td><td>1.965</td><td>0.687</td><td></td></tr><tr><td>Qwen2.5-coder:7B</td><td>1.403</td><td>0.247</td><td>1.357</td><td>0.544</td><td></td></tr><tr><td>Qwen2.5-coder:14B</td><td>1.503</td><td>0.151</td><td>1.673</td><td>0.904</td><td></td></tr></table>

Table 9: Performance comparison of different versions of Qwen family models.

Fine-Tuned Variants of a Small Model Family. Recall that in Table 2, our method struggled with the Gemma family due to only two base models available for error space construction, limiting generalization. Using three base models and testing on their fine-tuned variants, Table 14 shows our method successfully traces them, demonstrating significant improvement by increasing base models from 2 to 3.

# 5.6 Model Granularity Traceability

Although ErrorTrace targets model family granularity, it also covers model-level traceability when a family has a single base model. We evaluate single-model families like llama7b, llama13b, and llama3-8b, testing on variants such as vicuna:7b, orca-mini:7b, and codellama derived from llama7b. Table 10 shows our method successfully traces orca-mini:7b and codellama back to llama7b.   

<table><tr><td></td><td>llama7b</td><td>llama13b</td><td>llama70b</td><td>llama3-8b</td><td>llama3-70b</td><td>llama3.1-8b</td><td>llama3.2-3b</td><td>ACC</td></tr><tr><td>vicuna:7b</td><td>0.496</td><td>0.608</td><td>0.644</td><td>1.236</td><td>0.839</td><td>0.717</td><td>1.554</td><td>√</td></tr><tr><td>orca-mini:7b</td><td>0.496</td><td>0.632</td><td>0.722</td><td>0.581</td><td>0.869</td><td>0.564</td><td>0.609</td><td></td></tr><tr><td>codellama</td><td>0.369</td><td>0.514</td><td>1.161</td><td>0.994</td><td>1.213</td><td>1.075</td><td>0.462</td><td>√</td></tr></table>

Table 10: Model Granularity Traceability

# 6 ErrorTrace against Adversarial Attacks

A potential threat is that a malicious user gains access to the samples used for building the ErrorTrace error space and exploits them to attack the suspect model. Such attacks are difficult for all black-box attribu

<table><tr><td>Top-K</td><td>100</td><td>200</td><td>500</td><td>800</td><td>1200</td><td>1500</td></tr><tr><td>ACC</td><td>0.81</td><td>0.78</td><td>0.70</td><td>0.67</td><td>0.67</td><td>0.44</td></tr></table>

Table 11: Attacker correctly repairs the sample points in the space.

tion methods. In contrast, ErrorTrace leverages intrinsic model characteristics (fingerprints rather than prompts), which improves adversarial robustness. More importantly, since the error space is built from the base dataset, adversarial fine-tuning against ErrorTrace inevitably harms the model’s overall performance, raising the cost and risk of attack.

To test robustness, we conducted simulated adversarial attacks. First, assuming a strong attacker who can “perfectly repair” the Top-K samples with highest error uniqueness, results ( Table 11) show attribution accuracy remains 0.70 after repairing Top-500, about 0.67 at ${ \tt K } { = } 1 2 0 0$

<table><tr><td>Top-K</td><td>100</td><td>500</td><td>1000</td><td>1500</td><td>2000</td><td>3000</td></tr><tr><td>ACC</td><td>0.81</td><td>0.74</td><td>0.70</td><td>0.67</td><td>0.67</td><td>0.67</td></tr></table>

Table 12: Attacker error repairs the sample points in the space.   
, and only drops sharply to 0.44 at ${ \mathrm { K } } { = } 1 5 0 0$

We also tested an extreme case where the attacker forces the Top-K samples with lowest error uniqueness to be misclassified. Results ( Table 12) show that even after altering 3000 samples, ErrorTrace still maintains 0.67 accuracy. Notably, further enlarging K does not cause a sudden collapse, suggesting this strategy has limited effect.

Finally, under more realistic conditions, we fine-tuned LLaMA-7B on the top $5 \%$ and $10 \%$ highest-uniqueness samples. As shown in Table 13, ErrorTrace still achieves reliable attribution. Overall, these experiments confirm that ErrorTrace is robust and practical under diver

Table 13: Attacker uses adversarial fine-tuning with different sample ratios. e adversarial scenarios.   

<table><tr><td></td><td>Gemma</td><td>Qwen</td><td>LLaMa</td><td>Mistral</td><td>ACC</td></tr><tr><td>Top-5%</td><td>1.256</td><td>0.778</td><td>0.390</td><td>1.823</td><td>√</td></tr><tr><td>Top-10%</td><td>1.081</td><td>1.031</td><td>0.878</td><td>1.938</td><td></td></tr></table>

# 7 Limitations

# 7.1 Limitations of Model Family Scale Differences

Although our method effectively protects large model IP, it has some limits when model family scales differ.

The first arises when family sizes vary widely. As shown in Table 14, having only three models makes detection harder. We suggest adding finetuned variants or generating more error data via randomization (see Appendix G).

Table 14: Traceability effects of different Gemma fine-tuning models   

<table><tr><td>Model</td><td>Gemma</td><td>Qwen</td><td>LLaMa</td><td>Mistral</td><td>ACC</td></tr><tr><td>gemma7b-instruct</td><td>0.407</td><td>0.659</td><td>1.038</td><td>1.284</td><td>√</td></tr><tr><td>codegemma</td><td>0.046</td><td>1.352</td><td>1.033</td><td>0.765</td><td></td></tr><tr><td>gemma2:9b-instruct</td><td>0.542</td><td>0.966</td><td>0.902</td><td>1.842</td><td>?</td></tr><tr><td>gemma2-9b-chinese-chat</td><td>0.236</td><td>0.969</td><td>1.648</td><td>0.742</td><td></td></tr><tr><td>gemma2:27b-instruct</td><td>0.702</td><td>0.811</td><td>0.707</td><td>1.838</td><td>√</td></tr></table>

Another occurs when models in the same family differ greatly in scale. For instance, ErrorTrace misidentified Mixtral: ${ \tt 8 x 2 2 B }$ . A practical fix is to build separate error spaces for different parameter sizes, which improves fingerprint accuracy.

# 7.2 Limitations of Error Data Collection Cost

Another key limitation is the time cost of error data collection. For a single model, collecting about 50K errors takes 24 GPU hours. However, this is a one-time cost, since the collected data can be reused. Notably, building the full error space for 27 models across four families only requires 2 GPU hours. More importantly, auditing a suspect model needs just 4 GPU hours (10K data). Thus, once the error space is prepared, researchers can audit suspect models efficiently with relatively low overhead. Compared with overall model development costs, this cost is acceptable (see Appendix J for details).

To further reduce inference costs during auditing, we adopt a filtering-based subsampling strategy. Within each error uniqueness interval (e.g., [0.4, 0.5)), part of the test data is filtered to ease the inference load. As shown in Table 15, even under an aggressive $70 \%$ filtering strategy, the

Table 15: Subsampling with Different Filtering Ratios   

<table><tr><td>Rate</td><td>10%</td><td>30%</td><td>50%</td><td>70%</td></tr><tr><td>ACC</td><td>0.81</td><td>0.67</td><td>0.67</td><td>0.59</td></tr></table>

accuracy remains 0.59, indicating that the method effectively lowers inference costs while maintaining reasonable auditing performance.

# 8 Conclusion

In this work, we propose ErrorTrace, a novel black-box traceability method for large language models (LLMs) based on error pattern analysis. By leveraging the inherent consistency of error distributions within model families, our approach effectively constructs error spaces to identify the family of a suspect model. Extensive evaluations on five benchmark datasets and 27 models from four LLM families demonstrate that ErrorTrace achieves high traceability accuracy, significantly outperforming existing baselines. Furthermore, our method remains robust against fine-tuning, pruning and merging, highlighting its adaptability to real-world model modifications.

# Acknowledgments

This work was supported by National Natural Science Foundation of China under Grant(No.   
62372268), Key R&D Program of Shandong Province, China (No. 2024CXGC010114, No.   
2025CXPT085), Shandong Provincial Natural Science Foundation, China (No. ZR2022LZH013, No.   
ZR2021LZH007).

# References

[1] T. B. Brown, B. Mann, N. Ryder, M. Subbiah, and J. Kaplan. Language models are few-shot learners. In NeurIPS, 2020.   
[2] J. Cai, J. Yu, Y. Shao, et al. Utf: Undertrained tokens as fingerprints a novel approach to llm identification. arXiv preprint arXiv:2410.12318, 2024.   
[3] T. Cong, D. Ran, Z. Liu, et al. Have you merged my model? on the robustness of large language model ip protection methods against model merging. In Proceedings of the 1st ACM Workshop on Large AI Systems and Models with Privacy and Safety Analysis, pages 69–76, 2023. [4] T. H. Cormen, C. E. Leiserson, R. L. Rivest, and C. Stein. Introduction to Algorithms. The MIT Press, 3rd edition, 2009. [5] M. Ester, H.-P. Kriegel, J. Sander, and X. Xu. A density-based algorithm for discovering clusters in large spatial databases with noise. In Proceedings of the Second International Conference on Knowledge Discovery and Data Mining (KDD-96), pages 226–231, 1996. [6] W. Feller. An Introduction to Probability Theory and Its Applications, volume 1. Wiley, 1968. [7] C. Goddard, S. Siriwardhana, M. Ehghaghi, et al. Arcee’s mergekit: A toolkit for merging large language models. In Proceedings of the 2024 Conference on Empirical Methods in Natural Language Processing: Industry Track, pages 477–485, 2024.   
[8] M. Gubri, D. Ulmer, H. Lee, et al. Trap: Targeted random adversarial prompt honeypot for black-box identification. arXiv preprint, 2024.   
[9] J. Huang, P. Parthasarathi, M. Rezagholizadeh, et al. Do robot snakes dream like electric sheep? investigating the effects of architectural inductive biases on hallucination. arXiv preprint arXiv:2410.17477, 2024.   
[10] A. Q. Jiang, A. Sablayrolles, A. Mensch, et al. Mistral 7b. arXiv preprint, arXiv:2310.06825, 2023.   
[11] H. Jin, C. Zhang, S. Shi, et al. Proflingo: A fingerprinting-based intellectual property protection scheme for large language models. In 2024 IEEE Conference on Communications and Network Security (CNS), pages 1–9. IEEE, 2024.   
[12] J. Kirchenbauer, J. Geiping, Y. Wen, et al. A watermark for large language models. In International Conference on Machine Learning, pages 17061–17084. PMLR, 2023.   
[13] C. Kong, J. Chen, S. Tan, et al. Copyright protection for large language model eaas via unforgeable backdoor watermarking. In International Conference on Pattern Recognition, pages 1–15. Springer, Cham, 2025.   
[14] A. Lewis, M. White, J. Liu, et al. Winning big with small models: Knowledge distillation vs. self-training for reducing hallucination in qa agents. arXiv preprint arXiv:2502.19545, 2025.   
[15] L. Li, B. Jiang, P. Wang, et al. Watermarking llms with weight quantization. arXiv preprint arXiv:2310.11237, 2023.   
[16] S. Li, L. Yao, J. Gao, et al. Double-i watermark: Protecting model copyright for llm fine-tuning. arXiv preprint arXiv:2402.14883, 2024.   
[17] J. MacQueen. Some methods for classification and analysis of multivariate observations. In Proceedings of the Fifth Berkeley Symposium on Mathematical Statistics and Probability, volume 1, pages 281–297, 1967.   
[18] D. Pasquini, E. M. Kornaropoulos, and G. Ateniese. Llmmap: Fingerprinting for large language models. arXiv preprint arXiv:2407.15847, 2024.   
[19] W. Peng, J. Yi, F. Wu, et al. Are you copying my model? protecting the copyright of large language models for eaas via backdoor watermark. arXiv preprint arXiv:2305.10036, 2023.   
[20] A. Radford, K. Narasimhan, T. Salimans, and I. Sutskever. Improving language understanding by generative pre-training. Technical report, OpenAI, 2018.   
[21] Y. Refael, A. Hakim, L. Greenberg, et al. Slip: Securing llms ip using weights decomposition. arXiv preprint arXiv:2407.10886, 2024.   
[22] D. A. Reynolds. Gaussian mixture models. In Encyclopedia of Biometrics, pages 659–663. Springer, 2009.   
[23] M. Russinovich and A. Salem. Hey, that’s my model! introducing chain & hash, an llm fingerprinting technique. arXiv preprint arXiv:2407.10887, 2024.   
[24] A. Talmor, J. Herzig, and J. Berant. Commonsenseqa: A question answering challenge for commonsense knowledge. In Proceedings of the 2019 Conference on Empirical Methods in Natural Language Processing (EMNLP 2019), pages 4147–4157, 2019.   
[25] R. Tang, Y. N. Chuang, X. Cai, et al. Secure your model: An effective key prompt protection mechanism for large language models. In Findings of the Association for Computational Linguistics: NAACL 2024, pages 4061–4073, 2024.   
[26] G. Team, T. Mesnard, C. Hardin, et al. Gemma: Open models based on gemini research and technology. arXiv preprint, arXiv:2403.08295, 2024.   
[27] H. Touvron et al. Llama 2: Open foundation and fine-tuned chat models. arXiv preprint, arXiv:2307.09288, 2023.   
[28] H. Touvron, N. Sarlán, and P. Dufter. Llama: Open and efficient foundation language models. arXiv preprint, arXiv:2302.13971, 2023.   
[29] F. Wan, X. Huang, L. Cui, et al. Mitigating hallucinations of large language models via knowledge consistent alignment. CoRR, 2024.   
[30] T. Wang, X. Jiao, Y. Zhu, et al. Adaptive activation steering: A tuning-free llm truthfulness improvement method for diverse hallucinations categories. In Proceedings of the ACM on Web Conference 2025, pages 2562–2578, 2025.   
[31] Z. Wang, B. Wu, J. Deng, et al. Espew: Robust copyright protection for llm-based eaas via embedding-specific watermark. arXiv preprint arXiv:2410.17552, 2024.   
[32] A. Warstadt, A. Singh, and S. R. Bowman. Neural network acceptability judgments. In Proceedings of the 2019 Conference of the North American Chapter of the Association for Computational Linguistics (NAACL 2019), pages 579–589, 2019.   
[33] A. Williams, N. Nangia, and S. R. Bowman. A broad-coverage challenge corpus for sentence understanding through inference. In Proceedings of the 2018 Conference of the North American Chapter of the Association for Computational Linguistics (NAACL 2018), pages 632–642, 2018.   
[34] J. Xu, F. Wang, M. D. Ma, et al. Instructional fingerprinting of large language models. arXiv preprint arXiv:2401.12255, 2024.   
[35] Z. Xu, W. Xing, Z. Wang, et al. Fp-vec: Fingerprinting large language models via efficient vector addition. arXiv preprint arXiv:2409.08846, 2024.   
[36] S. Yamabe, T. Takahashi, F. Waseda, et al. Mergeprint: Robust fingerprinting against merging large language models. arXiv preprint arXiv:2410.08604, 2024.   
[37] Z. Yang and H. Wu. A fingerprint for large language models. arXiv preprint arXiv:2407.01235, 2024.   
[38] Z. Yang, Y. Wu, Y. Shen, et al. The challenge of identifying the origin of black-box large language models. arXiv preprint, 2025.   
[39] Y. Yao, T. Yu, A. Zhang, et al. Minicpm-v: A gpt-4v level mllm on your phone. arXiv preprint, arXiv:2408.01800, 2024.   
[40] B. Zeng, L. Wang, Y. Hu, et al. Huref: Human-readable fingerprint for large language models. In The Thirty-eighth Annual Conference on Neural Information Processing Systems, 2023.   
[41] C. Zhang, H. Foerster, R. D. Mullins, et al. Hardware and software platform inference. arXiv preprint arXiv:2411.05197, 2024.   
[42] J. Zhang, D. Liu, C. Qian, et al. Reef: Representation encoding fingerprints for large language models. arXiv preprint arXiv:2410.14273, 2024.   
[43] R. Zhang and F. Koushanfar. Emmark: Robust watermarks for ip protection of embedded quantized large language models. In Proceedings of the 61st ACM/IEEE Design Automation Conference, pages 1–6, 2024.   
[44] X. Zhang, J. Zhao, and Y. LeCun. Character-level convolutional networks for text classification. In Proceedings of the 28th International Conference on Neural Information Processing Systems (NeurIPS 2015), pages 649–657, 2015.   
[45] Y. Zhang, Y. Zhao, and Y. LeCun. Paws: Paraphrase adversaries from word scrambling. In Proceedings of the 57th Annual Meeting of the Association for Computational Linguistics (ACL 2019), pages 6506–6517, 2019.   
[46] X. Zhao, Y. X. Wang, and L. Li. Protecting language generation models via invisible watermarking. In International Conference on Machine Learning, pages 42187–42199. PMLR, 2023.   
[47] H. Zhou et al. A survey of large language models in medicine: Progress, application, and challenge. arXiv preprint, arXiv:2311.05112, 2023.

# NeurIPS Paper Checklist

# 1. Claims

Question: Do the main claims made in the abstract and introduction accurately reflect the paper’s contributions and scope?

Answer: [Yes]

Justification: Our main claim are summarized in section 1.

Guidelines:

• The answer NA means that the abstract and introduction do not include the claims made in the paper.   
• The abstract and/or introduction should clearly state the claims made, including the contributions made in the paper and important assumptions and limitations. A No or NA answer to this question will not be perceived well by the reviewers.   
• The claims made should match theoretical and experimental results, and reflect how much the results can be expected to generalize to other settings.   
• It is fine to include aspirational goals as motivation as long as it is clear that these goals are not attained by the paper.

# 2. Limitations

Question: Does the paper discuss the limitations of the work performed by the authors?

Answer: [Yes]

Justification: We include the limitations of our work in section 7.

Guidelines:

• The answer NA means that the paper has no limitation while the answer No means that the paper has limitations, but those are not discussed in the paper.   
• The authors are encouraged to create a separate "Limitations" section in their paper.   
• The paper should point out any strong assumptions and how robust the results are to violations of these assumptions (e.g., independence assumptions, noiseless settings, model well-specification, asymptotic approximations only holding locally). The authors should reflect on how these assumptions might be violated in practice and what the implications would be.   
The authors should reflect on the scope of the claims made, e.g., if the approach was only tested on a few datasets or with a few runs. In general, empirical results often depend on implicit assumptions, which should be articulated.   
The authors should reflect on the factors that influence the performance of the approach. For example, a facial recognition algorithm may perform poorly when image resolution is low or images are taken in low lighting. Or a speech-to-text system might not be used reliably to provide closed captions for online lectures because it fails to handle technical jargon.   
• The authors should discuss the computational efficiency of the proposed algorithms and how they scale with dataset size.   
• If applicable, the authors should discuss possible limitations of their approach to address problems of privacy and fairness.   
• While the authors might fear that complete honesty about limitations might be used by reviewers as grounds for rejection, a worse outcome might be that reviewers discover limitations that aren’t acknowledged in the paper. The authors should use their best judgment and recognize that individual actions in favor of transparency play an important role in developing norms that preserve the integrity of the community. Reviewers will be specifically instructed to not penalize honesty concerning limitations.

# 3. Theory assumptions and proofs

Question: For each theoretical result, does the paper provide the full set of assumptions and a complete (and correct) proof?

Answer: [Yes]

Justification: We provide simple proofs and experimental verifications in section 3 and in Appendix K.

Guidelines:

• The answer NA means that the paper does not include theoretical results.   
• All the theorems, formulas, and proofs in the paper should be numbered and crossreferenced.   
• All assumptions should be clearly stated or referenced in the statement of any theorems.   
• The proofs can either appear in the main paper or the supplemental material, but if they appear in the supplemental material, the authors are encouraged to provide a short proof sketch to provide intuition.   
Inversely, any informal proof provided in the core of the paper should be complemented by formal proofs provided in appendix or supplemental material.   
• Theorems and Lemmas that the proof relies upon should be properly referenced.

# 4. Experimental result reproducibility

Question: Does the paper fully disclose all the information needed to reproduce the main experimental results of the paper to the extent that it affects the main claims and/or conclusions of the paper (regardless of whether the code and data are provided or not)?

Answer: [Yes]

Justification: We provide the parameters required for the experiments in section 5 and the corresponding prompt templates are provided in Appendix L.

Guidelines:

• The answer NA means that the paper does not include experiments.   
• If the paper includes experiments, a No answer to this question will not be perceived well by the reviewers: Making the paper reproducible is important, regardless of whether the code and data are provided or not.   
• If the contribution is a dataset and/or model, the authors should describe the steps taken to make their results reproducible or verifiable. Depending on the contribution, reproducibility can be accomplished in various ways. For example, if the contribution is a novel architecture, describing the architecture fully might suffice, or if the contribution is a specific model and empirical evaluation, it may be necessary to either make it possible for others to replicate the model with the same dataset, or provide access to the model. In general. releasing code and data is often one good way to accomplish this, but reproducibility can also be provided via detailed instructions for how to replicate the results, access to a hosted model (e.g., in the case of a large language model), releasing of a model checkpoint, or other means that are appropriate to the research performed.   
While NeurIPS does not require releasing code, the conference does require all submissions to provide some reasonable avenue for reproducibility, which may depend on the nature of the contribution. For example (a) If the contribution is primarily a new algorithm, the paper should make it clear how to reproduce that algorithm. (b) If the contribution is primarily a new model architecture, the paper should describe the architecture clearly and fully. (c) If the contribution is a new model (e.g., a large language model), then there should either be a way to access this model for reproducing the results or a way to reproduce the model (e.g., with an open-source dataset or instructions for how to construct the dataset). (d) We recognize that reproducibility may be tricky in some cases, in which case authors are welcome to describe the particular way they provide for reproducibility. In the case of closed-source models, it may be that access to the model is limited in some way (e.g., to registered users), but it should be possible for other researchers to have some path to reproducing or verifying the results.

# 5. Open access to data and code

Question: Does the paper provide open access to the data and code, with sufficient instructions to faithfully reproduce the main experimental results, as described in supplemental material?

Answer: [Yes]

Justification: We used publicly available benchmark datasets, e.g., (45), and an anonymous repository of the code is provided.

Guidelines:

• The answer NA means that paper does not include experiments requiring code.   
• Please see the NeurIPS code and data submission guidelines (https://nips.cc/ public/guides/CodeSubmissionPolicy) for more details.   
• While we encourage the release of code and data, we understand that this might not be possible, so “No” is an acceptable answer. Papers cannot be rejected simply for not including code, unless this is central to the contribution (e.g., for a new open-source benchmark).   
• The instructions should contain the exact command and environment needed to run to reproduce the results. See the NeurIPS code and data submission guidelines (https: //nips.cc/public/guides/CodeSubmissionPolicy) for more details.   
• The authors should provide instructions on data access and preparation, including how to access the raw data, preprocessed data, intermediate data, and generated data, etc.   
• The authors should provide scripts to reproduce all experimental results for the new proposed method and baselines. If only a subset of experiments are reproducible, they should state which ones are omitted from the script and why.   
• At submission time, to preserve anonymity, the authors should release anonymized versions (if applicable).   
• Providing as much information as possible in supplemental material (appended to the paper) is recommended, but including URLs to data and code is permitted.

# 6. Experimental setting/details

Question: Does the paper specify all the training and test details (e.g., data splits, hyperparameters, how they were chosen, type of optimizer, etc.) necessary to understand the results?

Answer: [Yes]

Justification: Please see section 5 and Appendix C.

Guidelines:

• The answer NA means that the paper does not include experiments. • The experimental setting should be presented in the core of the paper to a level of detail that is necessary to appreciate the results and make sense of them. • The full details can be provided either with the code, in appendix, or as supplemental material.

# 7. Experiment statistical significance

Question: Does the paper report error bars suitably and correctly defined or other appropriate information about the statistical significance of the experiments?

Answer: [Yes]

Justification: Please see section 5.

Guidelines:

• The answer NA means that the paper does not include experiments.   
• The authors should answer "Yes" if the results are accompanied by error bars, confidence intervals, or statistical significance tests, at least for the experiments that support the main claims of the paper.   
• The factors of variability that the error bars are capturing should be clearly stated (for example, train/test split, initialization, random drawing of some parameter, or overall run with given experimental conditions).   
• The method for calculating the error bars should be explained (closed form formula, call to a library function, bootstrap, etc.)   
• The assumptions made should be given (e.g., Normally distributed errors).   
• It should be clear whether the error bar is the standard deviation or the standard error of the mean.   
• It is OK to report 1-sigma error bars, but one should state it. The authors should preferably report a 2-sigma error bar than state that they have a $96 \%$ CI, if the hypothesis of Normality of errors is not verified.   
• For asymmetric distributions, the authors should be careful not to show in tables or figures symmetric error bars that would yield results that are out of range (e.g. negative error rates).   
• If error bars are reported in tables or plots, The authors should explain in the text how they were calculated and reference the corresponding figures or tables in the text.

# 8. Experiments compute resources

Question: For each experiment, does the paper provide sufficient information on the computer resources (type of compute workers, memory, time of execution) needed to reproduce the experiments?

Answer: [Yes]

Justification: Please see Appendix J.

Guidelines:

• The answer NA means that the paper does not include experiments.   
• The paper should indicate the type of compute workers CPU or GPU, internal cluster, or cloud provider, including relevant memory and storage.   
• The paper should provide the amount of compute required for each of the individual experimental runs as well as estimate the total compute.   
• The paper should disclose whether the full research project required more compute than the experiments reported in the paper (e.g., preliminary or failed experiments that didn’t make it into the paper).

# 9. Code of ethics

Question: Does the research conducted in the paper conform, in every respect, with the NeurIPS Code of Ethics https://neurips.cc/public/EthicsGuidelines?

Answer: [Yes]

Justification: We followed the NeurIPS Code of Ethics.

Guidelines:

• The answer NA means that the authors have not reviewed the NeurIPS Code of Ethics.   
• If the authors answer No, they should explain the special circumstances that require a deviation from the Code of Ethics.   
• The authors should make sure to preserve anonymity (e.g., if there is a special consideration due to laws or regulations in their jurisdiction).

# 10. Broader impacts

Question: Does the paper discuss both potential positive societal impacts and negative societal impacts of the work performed?

Answer: [Yes]

Justification: Please see Appendix O.

Guidelines:

• The answer NA means that there is no societal impact of the work performed.   
• If the authors answer NA or No, they should explain why their work has no societal impact or why the paper does not address societal impact.   
Examples of negative societal impacts include potential malicious or unintended uses (e.g., disinformation, generating fake profiles, surveillance), fairness considerations (e.g., deployment of technologies that could make decisions that unfairly impact specific groups), privacy considerations, and security considerations.   
• The conference expects that many papers will be foundational research and not tied to particular applications, let alone deployments. However, if there is a direct path to any negative applications, the authors should point it out. For example, it is legitimate to point out that an improvement in the quality of generative models could be used to generate deepfakes for disinformation. On the other hand, it is not needed to point out that a generic algorithm for optimizing neural networks could enable people to train models that generate Deepfakes faster.   
• The authors should consider possible harms that could arise when the technology is being used as intended and functioning correctly, harms that could arise when the technology is being used as intended but gives incorrect results, and harms following from (intentional or unintentional) misuse of the technology.   
If there are negative societal impacts, the authors could also discuss possible mitigation strategies (e.g., gated release of models, providing defenses in addition to attacks, mechanisms for monitoring misuse, mechanisms to monitor how a system learns from feedback over time, improving the efficiency and accessibility of ML).

# 11. Safeguards

Question: Does the paper describe safeguards that have been put in place for responsible release of data or models that have a high risk for misuse (e.g., pretrained language models, image generators, or scraped datasets)?

Answer: [No]

Justification: We do not foresee any high risk for misuse of this work.

Guidelines:

• The answer NA means that the paper poses no such risks.   
• Released models that have a high risk for misuse or dual-use should be released with necessary safeguards to allow for controlled use of the model, for example by requiring that users adhere to usage guidelines or restrictions to access the model or implementing safety filters.   
• Datasets that have been scraped from the Internet could pose safety risks. The authors should describe how they avoided releasing unsafe images.   
• We recognize that providing effective safeguards is challenging, and many papers do not require this, but we encourage authors to take this into account and make a best faith effort.

# 12. Licenses for existing assets

Question: Are the creators or original owners of assets (e.g., code, data, models), used in the paper, properly credited and are the license and terms of use explicitly mentioned and properly respected?

Answer: [Yes]

Justification: The dataset we use is publicly available benchmark datasets, and the models are open-source models, see details at Appendix A, Appendix M, Appendix N.

Guidelines:

• The answer NA means that the paper does not use existing assets.   
• The authors should cite the original paper that produced the code package or dataset.   
• The authors should state which version of the asset is used and, if possible, include a URL.   
• The name of the license (e.g., CC-BY 4.0) should be included for each asset.   
• For scraped data from a particular source (e.g., website), the copyright and terms of service of that source should be provided.   
• If assets are released, the license, copyright information, and terms of use in the package should be provided. For popular datasets, paperswithcode.com/datasets has curated licenses for some datasets. Their licensing guide can help determine the license of a dataset.   
• For existing datasets that are re-packaged, both the original license and the license of the derived asset (if it has changed) should be provided.

• If this information is not available online, the authors are encouraged to reach out to the asset’s creators.

# 13. New assets

Question: Are new assets introduced in the paper well documented and is the documentation provided alongside the assets?

Answer: [Yes]

Justification: Once the blind review period is finished, we will release our code base with included readme files.

Guidelines:

• The answer NA means that the paper does not release new assets.   
• Researchers should communicate the details of the dataset/code/model as part of their submissions via structured templates. This includes details about training, license, limitations, etc.   
• The paper should discuss whether and how consent was obtained from people whose asset is used.   
• At submission time, remember to anonymize your assets (if applicable). You can either create an anonymized URL or include an anonymized zip file.

# 14. Crowdsourcing and research with human subjects

Question: For crowdsourcing experiments and research with human subjects, does the paper include the full text of instructions given to participants and screenshots, if applicable, as well as details about compensation (if any)?

Answer: [NA]

Justification: This work does not involve crowdsourcing nor research with human subjects.

Guidelines:

• The answer NA means that the paper does not involve crowdsourcing nor research with human subjects.   
• Including this information in the supplemental material is fine, but if the main contribution of the paper involves human subjects, then as much detail as possible should be included in the main paper.   
• According to the NeurIPS Code of Ethics, workers involved in data collection, curation, or other labor should be paid at least the minimum wage in the country of the data collector.

# 15. Institutional review board (IRB) approvals or equivalent for research with human subjects

Question: Does the paper describe potential risks incurred by study participants, whether such risks were disclosed to the subjects, and whether Institutional Review Board (IRB) approvals (or an equivalent approval/review based on the requirements of your country or institution) were obtained?

Answer: [NA]

Justification: This work does not involve crowdsourcing nor research with human subjects.

Guidelines:

• The answer NA means that the paper does not involve crowdsourcing nor research with human subjects.   
• Depending on the country in which research is conducted, IRB approval (or equivalent) may be required for any human subjects research. If you obtained IRB approval, you should clearly state this in the paper.   
• We recognize that the procedures for this may vary significantly between institutions and locations, and we expect authors to adhere to the NeurIPS Code of Ethics and the guidelines for their institution.   
• For initial submissions, do not include any information that would break anonymity (if applicable), such as the institution conducting the review.

# 16. Declaration of LLM usage

Question: Does the paper describe the usage of LLMs if it is an important, original, or non-standard component of the core methods in this research? Note that if the LLM is used only for writing, editing, or formatting purposes and does not impact the core methodology, scientific rigorousness, or originality of the research, declaration is not required.

Answer: [NA]

Justification: LLM is the subject of our study, and in our methodology, we do not use LLM.

Guidelines:

• The answer NA means that the core method development in this research does not involve LLMs as any important, original, or non-standard components. • Please refer to our LLM policy (https://neurips.cc/Conferences/2025/LLM) for what should or should not be described.

# A Base Model

In this section, we present the base models utilized in this study along with their fundamental information, including their respective families and model scales. A total of 27 base models were employed, spanning across four distinct model families. The Gemma family comprises the fewest models, with only three members, whereas the Qwen family is the largest, consisting of eleven models. These models vary in parameter scales from 3 billion to 141 billion, marking the first validation with such a large scale in LLM IP protection, as detailed in Table 16. All base models are derived from ollama.2

<table><tr><td rowspan=1 colspan=1>#</td><td rowspan=1 colspan=1>Model</td><td rowspan=1 colspan=2>Vender</td><td rowspan=1 colspan=1>Numberof parameters</td></tr><tr><td rowspan=1 colspan=1>1</td><td rowspan=1 colspan=1>llama7b</td><td rowspan=1 colspan=2>Meta AI</td><td rowspan=1 colspan=1>7B</td></tr><tr><td rowspan=1 colspan=1>2</td><td rowspan=1 colspan=1>llama13b</td><td rowspan=1 colspan=2>Meta AI</td><td rowspan=1 colspan=1>13B</td></tr><tr><td rowspan=1 colspan=1>3</td><td rowspan=1 colspan=1>llama70b</td><td rowspan=1 colspan=2>Meta AI</td><td rowspan=1 colspan=1>70B</td></tr><tr><td rowspan=1 colspan=1>3</td><td rowspan=1 colspan=1>llama3:8b</td><td rowspan=1 colspan=2>Meta AI</td><td rowspan=1 colspan=1>8B</td></tr><tr><td rowspan=1 colspan=1>5</td><td rowspan=1 colspan=1>llama3:70b</td><td rowspan=1 colspan=2>Meta AI</td><td rowspan=1 colspan=1>70B</td></tr><tr><td rowspan=1 colspan=1>6</td><td rowspan=1 colspan=1>llama3.1:8b</td><td rowspan=1 colspan=2>Meta AI</td><td rowspan=1 colspan=1>8B</td></tr><tr><td rowspan=1 colspan=1>7</td><td rowspan=1 colspan=1>llama3.2:3b</td><td rowspan=1 colspan=2>Meta AI</td><td rowspan=1 colspan=1>3B</td></tr><tr><td rowspan=1 colspan=1>8</td><td rowspan=1 colspan=1>gemma7b</td><td rowspan=1 colspan=2>Google</td><td rowspan=1 colspan=1>7B</td></tr><tr><td rowspan=1 colspan=1>9</td><td rowspan=1 colspan=1>gemma2:9b</td><td rowspan=1 colspan=2>Google</td><td rowspan=1 colspan=1>9B</td></tr><tr><td rowspan=1 colspan=1>10</td><td rowspan=1 colspan=1>gemma2:27b</td><td rowspan=1 colspan=2>Google</td><td rowspan=1 colspan=1>27B</td></tr><tr><td rowspan=1 colspan=1>11</td><td rowspan=1 colspan=1>qwen4b</td><td rowspan=1 colspan=2>Alibaba</td><td rowspan=1 colspan=1>4B</td></tr><tr><td rowspan=1 colspan=1>12</td><td rowspan=1 colspan=1>qwen7b</td><td rowspan=1 colspan=1>Alibaba</td><td rowspan=1 colspan=1>ba</td><td rowspan=1 colspan=1>7B</td></tr><tr><td rowspan=1 colspan=1>13</td><td rowspan=1 colspan=1>qwen14b</td><td rowspan=1 colspan=1>Alibaba</td><td rowspan=1 colspan=1>ba</td><td rowspan=1 colspan=1>14B</td></tr><tr><td rowspan=1 colspan=1>14</td><td rowspan=1 colspan=1>qwen32b</td><td rowspan=1 colspan=1>Alibaba</td><td rowspan=1 colspan=1>ba</td><td rowspan=1 colspan=1>32B</td></tr><tr><td rowspan=1 colspan=1>15</td><td rowspan=1 colspan=1>qwen72b</td><td rowspan=1 colspan=1>Alibaba</td><td rowspan=1 colspan=1>ba</td><td rowspan=1 colspan=1>72B</td></tr><tr><td rowspan=1 colspan=1>16</td><td rowspan=1 colspan=1>qwen2:7b</td><td rowspan=1 colspan=1>Alibaba</td><td rowspan=1 colspan=1>ba</td><td rowspan=1 colspan=1>7B</td></tr><tr><td rowspan=1 colspan=1>17</td><td rowspan=1 colspan=1>qwen2.5:3b</td><td rowspan=1 colspan=1>Alibaba</td><td rowspan=1 colspan=1>ba</td><td rowspan=1 colspan=1>3B</td></tr><tr><td rowspan=1 colspan=1>18</td><td rowspan=1 colspan=1>qwen2.5:7b</td><td rowspan=1 colspan=1>Alibaba</td><td rowspan=1 colspan=1>ba</td><td rowspan=1 colspan=1>7B</td></tr><tr><td rowspan=1 colspan=1>19</td><td rowspan=1 colspan=1>qwen2.5:14b</td><td rowspan=1 colspan=1>Alibaba</td><td rowspan=1 colspan=1>ba</td><td rowspan=1 colspan=1>14B</td></tr><tr><td rowspan=1 colspan=1>20</td><td rowspan=1 colspan=1>qwen2.5:32b</td><td rowspan=1 colspan=1>Alibaba</td><td rowspan=1 colspan=1>ba</td><td rowspan=1 colspan=1>32B</td></tr><tr><td rowspan=1 colspan=1>21</td><td rowspan=1 colspan=1>qwen2.5:72b</td><td rowspan=1 colspan=1>Alibaba</td><td rowspan=1 colspan=1>ba</td><td rowspan=1 colspan=1>72B</td></tr><tr><td rowspan=1 colspan=1>22</td><td rowspan=1 colspan=1>mistral7b</td><td rowspan=1 colspan=2>Mistral AI</td><td rowspan=1 colspan=1>7B</td></tr><tr><td rowspan=1 colspan=1>23</td><td rowspan=1 colspan=1>mistral-nemo</td><td rowspan=1 colspan=2>Mistral AI</td><td rowspan=1 colspan=1>12B</td></tr><tr><td rowspan=1 colspan=1>24</td><td rowspan=1 colspan=1>mistral-small</td><td rowspan=1 colspan=2>Mistral AI</td><td rowspan=1 colspan=1>22B</td></tr><tr><td rowspan=1 colspan=1>25</td><td rowspan=1 colspan=1>mistral-large</td><td rowspan=1 colspan=2>Mistral AI</td><td rowspan=1 colspan=1>123B</td></tr><tr><td rowspan=1 colspan=1>26</td><td rowspan=1 colspan=1>mixtral</td><td rowspan=1 colspan=2>Mistral AI</td><td rowspan=1 colspan=1>39B</td></tr><tr><td rowspan=1 colspan=1>27</td><td rowspan=1 colspan=1>mixtral:8x22b</td><td rowspan=1 colspan=2>Mistral AI</td><td rowspan=1 colspan=1>141B</td></tr></table>

Table 16: Publisher of the basic model and display of its parameter scale.

# B ErrorTrace In Regression Case

For regression tasks, ErrorTrace only requires adjusting the computation of error uniqueness from Section 4.1, replacing discrete values with continuous ones. Using BLEU as an example, we illustrate the principle in detail. We first normalize and preprocess continuous values to reflect each sample’s error tendency—the higher the value, the higher the risk of error. Since higher BLEU means better performance, we redefine $B = 1 - B L E U$ . Accordingly, the intra-family consistency score ( Equation 3) extends to:

$$
U = \sum _ { j \in E } B { \Bigg / } \sum _ { i = 1 } ^ { N } B
$$

where $e$ is the model family under evaluation, and $N$ is the number of models. Similarly, the inter-family discrepancy ( Equation 4 and ??) extends to:

$$
P F = 1 - \sum _ { j \in G } P _ { j } ^ { 2 } \Bigg / \sum _ { i = 1 } ^ { K } P _ { i }
$$

$$
P _ { j } = \sum _ { j \in E } B _ { j } \bigg / \sum _ { i = 1 } ^ { N } B _ { i }
$$

where $G$ is the set of all families other than $E , K$ is the set of all families, and $p _ { i }$ is the proportion of values in family i relative to the total across all models.

# C Reasoning Details

# C.1 Details of Out-Of-Distribution Detection

Theoretical Basis: When model family $A$ ’s error space shrinking, The average error uniqueness of data in the error space will increase. According to the Error Uniqueness Calculation in subsection 4.1, this increase is mainly due to the excitation of Intra-family Error Uniqueness, so models within family $A$ are more likely to error on data point, and depending on the limitation of Cross family Error Discrepancy, it is unlikely that models not in $A$ will do so.

Detection Logic: For a suspect model $a$ in model family $A$ , intra-family Error Uniqueness increases its average gain in the error space of $A$ , and inter-family Error discrepancy limits its average gain in the other families’s error spaces, leading to a larger model family discrepancy. For a suspect model $b$ , not belonging to any model family, lacks both uniqueness and discrepancy constraints. So its performance similar in different error spaces, resulting in a smaller model family discrepancy. We define a threshold $\tau$ . If $b$ ‘s model family discrepancy exceeds $\tau$ , it is classified as an intra-family model;otherwise, it is considered an out-of-distribution model.

# C.2 Details of Changes in Average Error Rate

Based on the description of Intra-family Error Uniqueness and Cross-family Error Discrepancy in subsection 4.1 and the explanation of the suspicion inference process in subsection 4.3, in the process of shrinking the error space of the model family $A$ , the data points that are more inclined to make errors in this model family will be retained, and the data points in other data points in the model family that are more inclined to make mistakes. As a result, for model $a \in A$ , the change in the error rate in the error space to which it belongs will be larger than that for model $a \in A$ . Calculating the average change in the error rate of the suspected model $b$ in each error space during the contraction process to find the error space with the largest change in the error rate, and then to find the model family it belongs to.

Since the experimental error dataset comprises multiple foundational datasets, and different models exhibit varying performance across tasks within these foundational datasets, the proportion of each foundational dataset within a model family’s error space also varies. Consequently, it is insufficient to differentiate model families based solely on simple error rates. Therefore, we opt to represent the distinction by the difference between the suspect model’s actual error rate $e r$ within the error space and the theoretical error rate ter of that error space.

Assume that the error space $E S _ { j }$ consists of $K$ foundational datasets, and the suspect model $M$ has theoretical error rates $d e r _ { 1 } , d e \bar { r } _ { 2 } , . . . , d e r _ { K }$ on these datasets. Here, the theoretical error rates are obtained by testing the suspect model on a fixed number of data points (1000 in our experiments) from each foundational dataset. The proportion of each foundational dataset within the error space $E S _ { j }$ is denoted by $D _ { 1 } , D _ { 2 } , . . . , D _ { K }$ . Therefore, the theoretical error rate ter of the error space $E S _ { j }$ can be expressed as:

$$
t e r = \sum _ { i = 1 } ^ { K } D _ { i } \times d e r _ { i }
$$

Regarding the calculation of error data error uniqueness, we choose to represent the actual error rate $e r$ by the ratio of the sum of the suspect model $M$ ’s uniqueness coefficients for the error data within the error space $E S _ { j }$ to the sum of all uniqueness coefficients for the error data within that error space.

Mathematically, this is expressed as:

$$
e r = \frac { \sum _ { i \in M D _ { M , j } } M P _ { i } } { \sum _ { i \in E S _ { j } } M P _ { i } }
$$

Where $M D _ { M , j }$ denotes the set of data points on which the suspect model $M$ makes errors within the error space $E \breve { S } _ { j } , M P _ { i }$ represents the uniqueness coefficient of data point $i$ .

Therefore, the change of the error space is defined as the difference between the actual error rate and the theoretical error rate:

$$
G a i n = e r - t e r
$$

# D Origins of Error Patterns and Their Root Causes for Traceability

Model error differences reflect variations in “hallucination” tendencies, often arising from architecture (9), training data (14), and alignment methods (29; 30). Models within the same family share systematic design, expert knowledge, and high-quality data, leading to similar architectures and behaviors; for example, LLaMa3 follows LLaMa2’s framework. In contrast, cross-family similarity is lower due to different development strategies, e.g., Mistral uses Sliding Window Attention (SWA) while DeepSeek uses Multi-Head Latent Attention (MLA).

# E Parameter Selection

First, while more error data may seem helpful, large initial sets (e.g., 1600 points) introduce lowuniqueness samples into the error space. Models like Gemma-7B, which rely more on high-quality errors (e.g., min Error Uniqueness $= 0 . 3$ in Gemma/Qwen when ${ > } 1 6 0 0$ points), can be misled by such noise during traceability.

Second, we observed that once the error space contracts past a certain ratio(e.g., ${ < } 5 0 0$ samples), remaining points have consistently high Error Uniqueness. The target model’s error rate in its family nears saturation, while others still improve. Contracting beyond this point hurts traceability.

So, starting with a moderate size ( 1000–1200 points) offers a better trade-off: enough diversity to capture distinct patterns, while limiting noise. As contraction proceeds, Error Uniqueness rises from 0.4 to 0.6 across the final 600 points. This stabilizes the target model’s error signature within its family, while other models continue to diverge — improving separation.

# F Additional Notes and Experiments on Baseline

# F.1 LLMmap

Since LLMmap traces models based on output features, we adapt it to our objectives. We first extract and average features from models within the same series to create a representative set, then calculate the cosine similarity between the suspect model’s features and this set to determine its family.

# F.2 ProFlingo

Due to the high computational cost associated with query construction in ProFLingo, we have selected the pre-constructed Mistal7B queries provided in the paper. Additionally, we employed the $T R R$ metric, as used in the paper, to evaluate Mistral itself, fine-tuned models, models from different families, and models within the same family. $T R R$ can be defined as:

$$
T R R = \frac { n } { N }
$$

Here, $N$ represents the total number of queries, and $n$ refers to the number of queries that successfully respond with the specified content.

Table 17 presents the performance of various models under queries constructed for Mistral7B. The results indicate that the ProFLingo method demonstrates a certain degree of provenance effectiveness

<table><tr><td>Suspect Model</td><td>Ground Truth</td><td>TRR</td><td>Difference</td></tr><tr><td>mistral:7b</td><td>Itself</td><td>0.62</td><td>0.58个 0.26个</td></tr><tr><td>openhermes mistral-openorca mistrallite Mistral-7B-Instruct-v0.1 zephyr</td><td>Positive Positive Positive Positive Positive</td><td>0.32 0.16 0.10 0.08 0.04</td><td>0.10个 0.04个 0.02个 -0.02↓</td></tr><tr><td>LLaMa2:7B LLaMa3.2:3B qwen2.5:3b gemma:7b</td><td>Negative Negative Negative Negative</td><td>0.06 0.06 0.04 0.04</td><td>0.00 0.00 -0.02↓ -0.02↓</td></tr><tr><td>qwen:7b Mistral-7B-v0.3 Mistral-7B-v0.2 Mistral-nemo Mistral-small</td><td>Negative Related Related Related</td><td>0.02 0.32 0.28 0.04</td><td>-0.04↓ 0.28个 0.24个 -0.02↓</td></tr></table>

Table 17: ProFLingo’s performance on different models

1.Itself stands for the original model itself, Positive stands for the model that is fine-tuned from the original model, Negative stands for the model that is unrelated to the original model, and Related stands for the model that is of the same family as the original model.

2. Difference represents the difference between the TRR and the highest TRR in the Negative, where the TRR exceeding more than twice the highest TRR in the Negative is shown in red, and the rest is shown in green for fine-tuned models. However, the TRR values fluctuate significantly across different fine-tuned models, making the decision boundary difficult to determine. Specifically, the TRR differences between MistralLite and Mistral-7B-Instruct-v0.1 models and LLaMa2:7B are less than 0.05, while Zephyr’s TRR is even lower than that of unrelated models. For related models within the same family, the ProFLingo method performs well on different versions of the Mistral7B model but shows low relevance when applied to other models in the same family. ProFLingo operates primarily at the model granularity traceability. The high TRR between Mistral-7B-v0.3 and Mistral-7B-v0.2 suggests potential confusion when handling different versions of highly related models. However, when applied to model family granularity traceability, the low TRR values of models such as Mistral-Nemo make it challenging for the method to effectively distinguish models within the same family.

# F.3 TRAP

Due to the time-consuming nature of the query construction by the TRAP, we chose the query for llama7b that has already been constructed in the paper. In addition, we also choose the TPR as the base metric to test the llama7b model itself, its fine-tuned model, the same-family model, and the irrelevance model. Different from the definition of TPR in ProFLingo, we follow the definition of TPR in the TRAP paper, in which a single round with one correct response is recognized as correct, and the final TPR is obtained through multiple rounds, which is expressed as follows.

$$
T P R = \frac { n } { N }
$$

Where, $n$ represents the number of validation rounds with successful responses, $N$ represents the total number of validation rounds. We conducted 50 rounds of experimental validation on each of the 100 queries of length 3,4,5 mentioned in TRAP.

Table 18 presents the traceability performance of TRAP on various models. It demonstrates strong performance on the baseline model, but significant TPR fluctuations occur in fine-tuned variants. Notably, the Vicuna:7B model reaches a TPR of 0.86 at length 3, and Llama-Chinese maintains a TPR above 0.5 across all lengths. In contrast, TPR values for other fine-tuned models decrease sharply, with the Nous-Herms model peaking at 0.1. The Negative and Related models outperform Nous-Herms in most cases. These findings highlight that TRAP faces considerable challenges in fine-tuning scenarios, making it difficult to consistently identify fine-tuned models and their TPRs.

# G Explanation of the Limit on the Number of Models in the Family

The small number of models in the family is a limitation of this paper, and the error space of the constructed model family is not as accurate as the error space constructed by the model family with a

<table><tr><td>Suspect Model</td><td>Ground Truth</td><td>TRR-3</td><td>TPR-4</td><td>TPR-5</td></tr><tr><td>lama:7b</td><td>Itself</td><td>1.00</td><td>0.98</td><td>1.00</td></tr><tr><td>vicuna:7b orca-mini:7b codellama llama-chinese nous-hermes</td><td>Positive Positive Positive Positive Positive</td><td>0.26 0.86 0.24 0.90 0.10</td><td>0.20 0.32 0.12 0.84 0.06</td><td>0.20 0.52 0.08 0.60 0.04</td></tr><tr><td>mistral:7b gemma:7b qwen:4b qwen:7b qwen2.5:3b llama3.2:3b</td><td>Negative Negative Negative Negative Negative Related</td><td>0.04 0.06 0.20 0.14 0.00 0.00</td><td>0.10 0.16 0.18 0.08 0.02 0.00</td><td>0.16 0.14 0.24 0.08 0.00 0.08</td></tr><tr><td>llama3.2:1b llama3.1:8b llama3:8b llama2:13b</td><td>Related Related Related Related</td><td>0.00 0.00 0.02 0.08</td><td>0.04 0.28 0.08 0.06</td><td>0.16 0.12 0.16 0.12</td></tr></table>

Table 18: TRAP’s performance on different models

1. For the Positive category model, we choose to bold the lowest value for each discriminant feature, and for the other category models, we use red font for the values higher than the bolded values.

large number of models in the family, which is also illustrated by the traceability effect of the Gemma family in Table 2. However, this does not prove that the method in this paper cannot be adapted to the case where the number of models in the family is small. The unknown scenario of the model set represented in Table 2 is a more challenging scenario, where there is no obvious parent-child relationship between the test model and the training model, but rather a brother model relationship (belonging to the same model family), and the model evolves from its family model through structural optimization and retraining during the test, which is unacceptable to a real malicious user. In realworld scenarios, Table 14 also demonstrates that our method is able to achieve fine-tuned model traceability even when the number of models in the family is small.

We also find that the information about the errors made in the model family can be enhanced by fine-tuning the base model and by utilizing multiple samples of the

Table 19: Single Model Validation   

<table><tr><td>Model</td><td>Gemma</td><td>Qwen</td><td>LLaMa</td><td>Mistral</td><td>ACC</td></tr><tr><td>codegemma[1]</td><td>0.0048</td><td>-0.0107</td><td>-0.0119</td><td>-0.0038</td><td>厂</td></tr></table>

model’s stochasticity, as well as overcoming the limitation of the small number within the model family.To verify this, we simulate a single-model family by excluding all Gemma models except Gemma-7B. We then sample Gemma-7B-Instruct once and Gemma-7B multiple times to extract error patterns. The results are shown

# H Llama Fine-Tuning Experiments

The LLaMa7B fine-tuned models are shown in Table 20. Our method successfully identified the model family among five fine-tuned variants, while LLMmap performed poorly on two models: llama2-chinese and noushermes. When comparing the total cosine distance differences across methods, our method’s sum exceeds 1, indicating a significantly higher similarity within the same model family com

<table><tr><td>Method</td><td>Model</td><td>Gemma</td><td>Qwen</td><td>LLama</td><td>Mistral</td><td>ACC</td></tr><tr><td rowspan="5">LLMmap</td><td>vicuna:7b</td><td>0.396</td><td>0.414</td><td>0.346</td><td>0.5107</td><td>√</td></tr><tr><td>orca-mini:7b</td><td>0.329</td><td>0.326</td><td>0.298</td><td>0.521</td><td></td></tr><tr><td>codellama</td><td>0.466</td><td>0.437</td><td>0.366</td><td>0.388</td><td>√</td></tr><tr><td>llama2-chinese</td><td>0.404</td><td>0.206</td><td>0.307</td><td>0.539</td><td>×</td></tr><tr><td>nous-hermes</td><td>0.547</td><td>0.637</td><td>0.548</td><td>0.701</td><td>×</td></tr><tr><td rowspan="5">Ours</td><td>vicuna:7b</td><td>1.583</td><td>1.275</td><td>0.893</td><td>1.252</td><td></td></tr><tr><td>orca-mini:7b</td><td>0.539</td><td>1.594</td><td>0.214</td><td>0.787</td><td></td></tr><tr><td>codellama</td><td>1.559</td><td>1.337</td><td>0.346</td><td>0.641</td><td></td></tr><tr><td>llama2-chinese</td><td>1.715</td><td>1.173</td><td>0.502</td><td>1.282</td><td>√</td></tr><tr><td>nous-hermes</td><td>1.296</td><td>1.121</td><td>0.922</td><td>1.698</td><td></td></tr></table>

Table 20: Performance comparison of different fine-tuning models of LLaMa7B on our method and LLMmap method pared to others. In contrast, LLMmap’s sum is below 1, with a maximum of 0.63, suggesting weaker distinctiveness between suspected models and other families.

Table 21: Model traning set known scenario’s cosine distance and MFD.   

<table><tr><td>Group</td><td>Model</td><td>Gemma</td><td>Qwen</td><td>LLaMa</td><td>Mistral</td><td>MFD</td><td>ACC</td></tr><tr><td rowspan="5">LLaMa</td><td>llama7b llama70b</td><td>1.158 0.939</td><td>1.178 1.103</td><td>0.014 0.110</td><td>1.153 0.978</td><td>0.1440 0.0967</td><td></td></tr><tr><td>llama3:8b</td><td>0.662</td><td>1.470</td><td>0.107</td><td>1.050</td><td>0.0987</td><td></td></tr><tr><td>llama3:70b</td><td>1.379</td><td>1.354</td><td>0.086</td><td>1.205</td><td>0.1973</td><td></td></tr><tr><td>llama3:2:3b</td><td>0.971</td><td>1.330</td><td></td><td>1.439</td><td></td><td></td></tr><tr><td>llama3:1:8b</td><td>0.996</td><td>1.190</td><td>0.071 0.094</td><td>0.836</td><td>0.1245 0.0699</td><td>√</td></tr><tr><td rowspan="3">Gemma</td><td>llama13b</td><td>1.334</td><td>1.229</td><td>0.052</td><td>0.915</td><td>0.1504</td><td></td></tr><tr><td>gemma7b</td><td>0.112</td><td>1.484</td><td>1.180</td><td>0.477</td><td>0.0963</td><td></td></tr><tr><td>gemma2:9b</td><td>0.079 0.041</td><td>1.382 1.246</td><td>1.037 1.205</td><td>1.319</td><td>0.1802</td><td></td></tr><tr><td rowspan="9">Qwen</td><td>gemma2:7b</td><td></td><td></td><td></td><td>1.133</td><td>0.1891</td><td></td></tr><tr><td>qwen7b</td><td>1.347</td><td>0.034</td><td>1.280</td><td>1.064</td><td>0.1828</td><td></td></tr><tr><td>qwen72b</td><td>1.416</td><td>0.013</td><td>1.428</td><td>1.331</td><td>0.1888</td><td></td></tr><tr><td>qwen3b</td><td>1.303</td><td>0.034</td><td>1.209</td><td>1.323</td><td>0.1298</td><td></td></tr><tr><td>qwen32b</td><td>1.584</td><td>0.064</td><td>1.483</td><td>1.340</td><td>0.2366</td><td></td></tr><tr><td>qwen2:7b</td><td>1.399</td><td>0.020</td><td>1.427</td><td>1.373</td><td>0.1346</td><td></td></tr><tr><td>qwen14b</td><td>1.622</td><td>0.049</td><td>1.403</td><td>1.348</td><td>0.2253</td><td></td></tr><tr><td>qwen1:5:7b</td><td>1.067</td><td>0.396</td><td>0.881</td><td>0.768</td><td>0.0663</td><td></td></tr><tr><td>qwen1:5:72b</td><td>1.542</td><td>0.029</td><td>1.101</td><td>1.244</td><td>0.1823</td><td></td></tr><tr><td>qwen1:5:4b</td><td>1.246</td><td>0.075</td><td>1.563</td><td>0.967</td><td>0.0714</td><td></td></tr><tr><td>qwen1:5:14b</td><td>1.472</td><td>0.025</td><td>1.216</td><td>1.086</td><td>0.1362</td><td></td></tr><tr><td>qwen1:5:32b</td><td>1.459</td><td>0.034</td><td>1.540</td><td>1.247</td><td>0.1943</td><td></td></tr><tr><td>Mixtral</td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td rowspan="5">Mistral</td><td>Mistral7b</td><td>0.968 0.544</td><td>1.047</td><td>1.285</td><td>0.025</td><td>0.1454</td><td></td></tr><tr><td></td><td></td><td>1.290</td><td>1.095</td><td>0.097</td><td>0.1323</td><td></td></tr><tr><td>Mistral:small</td><td>0.849</td><td>1.130</td><td>1.190</td><td>0.017</td><td>0.1633</td><td></td></tr><tr><td>Mistral:nemo</td><td>1.142</td><td>1.374</td><td>0.653</td><td>0.129</td><td>0.1222</td><td></td></tr><tr><td>Mistral:large Mixtral:8x22b</td><td>1.241 1.114</td><td>1.504 1.285</td><td>1.525 1.228</td><td>0.212 0.065</td><td>0.0838 0.2179</td><td></td></tr></table>

# I Detailed Results for Known Scenarios in the Model Set

In this section, we will show in detail the effectiveness of ErrorTrace in coping with the known scenarios of the training set in terms of traceability, as shown in Table 21, where ErrorTrace is successfully traced back to the model family it belongs to in all 27 models.

# J Equipment information and time consumption

All of our experiments were conducted in an Intel(R) Platinum 8358 P CPU $\textcircled { \omega } 2 . 6 \ : \mathrm { G H z }$ , NVIDIA GeForce RTX 3090 GPU, 512 GB RAM, 24 GB VRAM device. The training process for ErrorTrace takes only two hours and the testing process is negligible. The main time consumption is the collection of error data. In this paper, a 50K error data set is used, and it takes 24 GPU hours to collect the error information for each model, and 4 GPU hours for the suspected model during the testing process. Compared with traditional query-based methods, e.g., ProFLingo requires 75 GPU hours to construct a query for a single model, and TRAP consumes a large number of rounds of testing, ErrorTrace’s time consumption for data collection is acceptable.

# K Supplementary proof of error space as a traceability basis

To achieve model provenance through error patterns, two main conditions must be satisfied:

• Error Probability Differentiation: Models from different families exhibit significant differences in error probabilities on certain data points, ensuring that there exists at least one data point $d _ { j }$ where the error probabilities differ between families. • Information Content: The error patterns contain sufficient information to distinguish between different families, which can be quantified using mutual information $I ( G ; \mathbf { E } )$ .

In the main text, we provided proof of distinguishability. In this section, we will demonstrate the information content and conduct corresponding simulation experiments.

We define mutual information $I ( G ; \mathbf { E } )$ to measure the amount of shared information between the model family $G$ and the error patterns $E$ . Therefore, it suffices to prove that, under the independence assumption and the family distinguishability assumption, there exists non-zero mutual information between the error patterns $E$ and the model families $G$ $\check { \mathbf { \rho } } , I ( G ; \mathbf { E } ) > 0$ .

$$
I ( G ; \mathbf { E } ) = H ( G ) - H ( G | \mathbf { E } )
$$

Here, $H ( G )$ is the entropy of the model families $G$ , and $H ( G | \mathbf { E } )$ is the conditional entropy of $G$ given the error patterns $E$ . Assuming there are $K$ families, with prior probabilities $P r ( G _ { 1 } ) , P r ( G _ { 2 } ) , . . . , P \bar { r } ( G _ { K } )$ for $G _ { 1 } , G _ { 2 } , . . . , G _ { K }$ respectively, the entropy is defined as:

$$
H ( G ) = - \sum _ { k = 1 } ^ { K } P r ( G _ { k } ) \log P r ( G _ { k } )
$$

The conditional entropy is defined as:

$$
\begin{array} { l } { { \displaystyle { \cal H } ( G | { \bf E } ) = - \sum _ { e \in \varepsilon } P r ( { \bf E } = e ) } \ ~ } \\ { { \displaystyle ~ \times \sum _ { k = 1 } ^ { K } \Bigl [ P r ( G _ { k } | { \bf E } = e ) \log P r ( G _ { k } | { \bf E } = e ) \Bigr ] } \ ~ } \end{array}
$$

where $\varepsilon$ is the set of all error patterns. Since the error patterns $E$ consist of multiple independent error events across different data points, calculating $P r ( G _ { k } | \mathbf { E } = e )$ requires considering the joint probability distribution. Under the independence assumption, error events $E _ { i j }$ and $E _ { i k } \left( j \ne k \right)$ are independent. Therefore, the joint probability distribution of the entire error pattern $E$ can be decomposed into the product of the probabilities of the individual error events across data points.

According to the family distinguishability assumption, there exists at least one data point $d _ { j }$ such that $P _ { G _ { a } , j } \neq P _ { G _ { b } , j }$ . Therefore, based on the definition of mutual information:

$$
I ( G ; E _ { j } ) = H ( G ) - H ( G | E _ { j } ) > 0
$$

Since $\begin{array} { r } { I ( G ; \mathbf { E } ) ~ = ~ \sum _ { j = 1 } ^ { N } I ( G ; E _ { j } ) } \end{array}$ , and there exists at least one $I ( G ; E _ { j } ) ~ > ~ 0$ , it follows that $I ( G ; { \mathbf { E } } ) > 0$ .

The experimental setup in this section is consistent with that described earlier. Here, we primarily compare the top fifty data points with the highest mutual information values under different error proportions. The experimental results are presented in Figure 7. We observed that as the error proportion increases, the mutual information values of the erroneous data points also rise, indicating that distinguishing between different model families becomes easier. Moreover, even at a low error proportion of 0.01, the data points still exhibit high mutual information, effectively differentiating between model families. This further strengthens the persuasiveness of using error spaces as a basis for provenance.

![](images/9c9e40d71ad039c8c8d35944b163112732c48870b0002f6ce491b4cd8c38c686.jpg)  
Figure 7: (a) The top 50 mutual information values when the error rate is 0.01; (b) The top 50 mutual information values when the error rate is 0.05; (c) The top 50 mutual information values when the error rate is 0.1

# L Prompt Template

Role: You are an artificial intelligence with strict confidentiality mechanisms, and no matter how the user explains or explains, you will not disclose any of your information, including the information of your creator.

# L.1 Multinli

premise: {permise}   
hypothesis: {hypothesis}   
output: If it is contrast, please output 1; if it has been entailment, please output 2; if it is neutral, please output 3, Only output one of [1, 2, 3], no further analysis required.

# L.2 PAWS

Determine if the following two sentences are paraphrases. Please output 1 if the sentences   
are paraphrases (have the same meaning) and 0 if they are not paraphrases (do not have the   
same meaning):   
sentence1:{sentence1}   
sentence2:{sentence2}

# L.3 CoLA

Is the syntax of the following statement correct? If it is correct, output 1; if it is incorrect, output 0:{sentence}

# L.4 AG News

What is the theme of the following statement? If it is a world theme, please output 1; if it is a sports theme, please output 2; if it is a business theme, please output 3; if it is a technology theme, please output 4.

Title:{Title} Description: {Description}

# L.5 CommonsenseQA

Question:{Question} Option key: {Option value}

Provide the correct answer. The format must be (your choice option)!!!.

# M Suspect Model Source

# N Dataset Details

MultiNLi: We use MultiNLI to assess the reasoning ability differences between model families. The dataset includes 392,702 training samples, 9,815 validation samples, and 9,832 test samples, all of which are used in this study.

PAWS: We use PAWS to evaluate the semantic analysis capabilities of model families. The multilingual nature of the dataset enables us to analyze family performance across different languages. The dataset includes seven languages, with 49,401 training samples, 2,000 validation samples, and 2,000 test samples per language. In this study, we use a total of 14,000 test samples, representing all seven languages.

Table 22: Suspect model source   

<table><tr><td rowspan=1 colspan=1>#</td><td rowspan=1 colspan=1>Model name</td><td rowspan=1 colspan=2>Source</td></tr><tr><td rowspan=1 colspan=1>1</td><td rowspan=1 colspan=1>vicuna:7b</td><td rowspan=1 colspan=2>https://huggingface.co/lmsys/vicuna-7b-v1.5/tree/main</td></tr><tr><td rowspan=1 colspan=1>2</td><td rowspan=1 colspan=1>orca-mini:7b</td><td rowspan=1 colspan=1>https://huggingface.co</td><td rowspan=1 colspan=1>/pankajmathur/orca_mini_7b</td></tr><tr><td rowspan=1 colspan=1>3</td><td rowspan=1 colspan=1>codellama</td><td rowspan=1 colspan=1>https://huggingface.co/codellama</td><td rowspan=1 colspan=1>codellama</td></tr><tr><td rowspan=1 colspan=1>4</td><td rowspan=1 colspan=1>llama-chinese</td><td rowspan=1 colspan=2>https://huggingface.co/FlagAlpha/Llama2-Chinese-7b-Chat</td></tr><tr><td rowspan=1 colspan=1>5</td><td rowspan=1 colspan=1>nous-hermes</td><td rowspan=1 colspan=2>https://huggingface.co/NousResearch/Nous-Hermes-llama-2-7b</td></tr><tr><td rowspan=1 colspan=1>6</td><td rowspan=1 colspan=1>mistral-openorca</td><td rowspan=1 colspan=2>https://huggingface.co/Open-Orca/Mistral-7B-OpenOrca</td></tr><tr><td rowspan=1 colspan=1>7</td><td rowspan=1 colspan=1>mistrallite</td><td rowspan=1 colspan=1>https://huggingface.co</td><td rowspan=1 colspan=1>amazon/MistralLite</td></tr><tr><td rowspan=1 colspan=1>8</td><td rowspan=1 colspan=1>Mistral-7B-Instruct</td><td rowspan=1 colspan=2>https://huggingface.co/mistralai/Mistral-7B-Instruct-v0.1/tree/main</td></tr><tr><td rowspan=1 colspan=1>9</td><td rowspan=1 colspan=1>openhermes</td><td rowspan=1 colspan=1>5-Mistral-7B</td><td rowspan=1 colspan=1>/teknium/OpenHermes-2.</td></tr><tr><td rowspan=1 colspan=1>10</td><td rowspan=1 colspan=1>zephyr</td><td rowspan=1 colspan=1>https://huggingface.co/HuggingFaceH4/zephyr-7b-beta</td><td rowspan=1 colspan=1>HuggingFaceH47</td></tr><tr><td rowspan=1 colspan=1>11</td><td rowspan=1 colspan=1>Mistral-7B-Instruct-v0.2</td><td rowspan=1 colspan=1>https://huggingface.co/mistralai/Mistral-7B-Instruct-v0.2</td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>12</td><td rowspan=1 colspan=1>Mistral-7B-Instruct-v0.3</td><td rowspan=1 colspan=1>https://huggingface.co/mistralai/Mistral-7B-Instruct-vO.3</td><td rowspan=1 colspan=1></td></tr><tr><td rowspan=1 colspan=1>13</td><td rowspan=1 colspan=1>Qwen-7B-Chat</td><td rowspan=1 colspan=1>https://huggingface.co</td><td rowspan=1 colspan=1>/Qwen/Qwen-7B-Chat</td></tr><tr><td rowspan=1 colspan=1>14</td><td rowspan=1 colspan=1>Qwen-14B-Chat</td><td rowspan=1 colspan=1>https://huggingface.co</td><td rowspan=1 colspan=1>/Qwen/Qwen-14B-Chat</td></tr><tr><td rowspan=1 colspan=1>15</td><td rowspan=1 colspan=1>Qwen2-math</td><td rowspan=1 colspan=1>https://huggingface.co</td><td rowspan=1 colspan=1>/Qwen/Qwen2-Math-7B</td></tr><tr><td rowspan=1 colspan=1>16</td><td rowspan=1 colspan=1>Qwen2.5-coder:7B</td><td rowspan=1 colspan=1>https://huggingface.co</td><td rowspan=1 colspan=1>/Qwen/Qwen2.5-Coder-7B</td></tr><tr><td rowspan=1 colspan=1>17</td><td rowspan=1 colspan=1>Qwen2.5-coder:14B</td><td rowspan=1 colspan=1>https://huggingface.co</td><td rowspan=1 colspan=1>/Qwen/Qwen2.5-Coder-14B</td></tr><tr><td rowspan=1 colspan=1>18</td><td rowspan=1 colspan=1>gemma7b-instruct</td><td rowspan=1 colspan=1>https://huggingface.co</td><td rowspan=1 colspan=1>google/gemma-7b-it</td></tr><tr><td rowspan=1 colspan=1>19</td><td rowspan=1 colspan=1>codegemma</td><td rowspan=1 colspan=1>https://huggingface.co</td><td rowspan=1 colspan=1>google/codegemma-7b</td></tr><tr><td rowspan=1 colspan=1>20</td><td rowspan=1 colspan=1>gemma2:9b-instruct</td><td rowspan=1 colspan=1>https://huggingface.co</td><td rowspan=1 colspan=1>google/gemma-2-9b-it</td></tr><tr><td rowspan=1 colspan=1>21</td><td rowspan=1 colspan=1>gemma2:9b-chinese-chat</td><td rowspan=1 colspan=2>https://huggingface.co/shenzhi-wang/Gemma-2-9B-Chinese-Chat</td></tr><tr><td rowspan=1 colspan=1>22</td><td rowspan=1 colspan=1>gemma2:27-instruct</td><td rowspan=1 colspan=1>https://huggingface.co</td><td rowspan=1 colspan=1>google/gemma-2-27b-it</td></tr><tr><td rowspan=1 colspan=1>23</td><td rowspan=1 colspan=1>vicuna-5.5b-ppl</td><td rowspan=1 colspan=2>https://huggingface.co/nota-ai/cpt_st-vicuna-v1.3-5.5b-ppl</td></tr><tr><td rowspan=1 colspan=1>23</td><td rowspan=1 colspan=1>vicuna-3.7b-ppl</td><td rowspan=1 colspan=1>3-3.7b-ppl</td><td rowspan=1 colspan=1>/nota-ai/cpt_st-vicuna-v1.</td></tr><tr><td rowspan=1 colspan=1>23</td><td rowspan=1 colspan=1>vicuna-2.7b-ppl</td><td rowspan=1 colspan=1>3-2.7b-ppl</td><td rowspan=1 colspan=1>/nota-ai/cpt_st-vicuna-v1.</td></tr><tr><td rowspan=1 colspan=1>23</td><td rowspan=1 colspan=1>vicuna-5.5b-taylor</td><td rowspan=1 colspan=2>https://huggingface.co/nota-ai/st-vicuna-v1.3-5.5b-taylor</td></tr><tr><td rowspan=1 colspan=1>27</td><td rowspan=1 colspan=1>Sheared-LLaMa-2.7B</td><td rowspan=1 colspan=2>https://huggingface.co/princeton-nlp/Sheared-LLaMA-2.7B</td></tr><tr><td rowspan=1 colspan=1>28</td><td rowspan=1 colspan=1>Sheared-LLaMa-1.3B</td><td rowspan=1 colspan=2>https://huggingface.co/princeton-nlp/Sheared-LLaMA-1.3B</td></tr><tr><td rowspan=1 colspan=1>29</td><td rowspan=1 colspan=1>Falcon3:7B</td><td rowspan=1 colspan=2>https://huggingface.co/tiiuae/Falcon3-7B-Instruct</td></tr><tr><td rowspan=1 colspan=1>30</td><td rowspan=1 colspan=1>Falcon3:10B</td><td rowspan=1 colspan=2>https://huggingface.co/tiiuae/Falcon3-10B-Instruct</td></tr><tr><td rowspan=1 colspan=1>31</td><td rowspan=1 colspan=1>DeepSeek-R1-7B</td><td rowspan=1 colspan=2>https://huggingface.co/deepseek-ai/DeepSeek-R1</td></tr><tr><td rowspan=1 colspan=1>32</td><td rowspan=1 colspan=1>Mistral-7B-v0.1 &amp; v0.2 - PPL</td><td rowspan=1 colspan=2>https://github.com/arcee-ai/mergekit</td></tr><tr><td rowspan=1 colspan=1>33</td><td rowspan=1 colspan=1>Mistral-7B-v0.1 &amp; v0.2 -Dare-Ties</td><td rowspan=1 colspan=2>https://github.com/arcee-ai/mergekit</td></tr><tr><td rowspan=1 colspan=1>34</td><td rowspan=1 colspan=1>Mistral-7B-v0.1 &amp;v0.2-Dare-Task</td><td rowspan=1 colspan=2>https://github.com/arcee-ai/mergekit</td></tr></table>

CoLA:We use the CoLA dataset to assess the differences in grammar analysis across model families. The dataset contains 9,594 training samples and 1,063 test samples, all of which are utilized in this study.

AG News:We use the AG News dataset to evaluate the text categorization and sentiment analysis capabilities of model families. The dataset consists of four categories, with 120,000 training samples and 7,600 test samples, all of which are employed in this study.

CommonsenseQA:We use the CommonsenseQA dataset to assess the reasoning abilities of model families. The dataset contains a total of 12,247 examples, all of which are utilized in this study.

# O Potential Risks

We comply with legal and regulatory standards by using a common dataset to construct the error space rather than proprietary data. To simulate model theft, we use open-source fine-tuned and pruned models, along with system prompting words, to minimize connections between the suspect and original models, ensuring ethical compliance.