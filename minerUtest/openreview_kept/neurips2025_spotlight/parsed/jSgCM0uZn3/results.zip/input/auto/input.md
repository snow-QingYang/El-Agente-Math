# AceSearcher: Bootstrapping Reasoning and Search for LLMs via Reinforced Self-Play

Ran Xu1 Yuchen Zhuang2 Zihan Dong3 Jonathan Wang1 Yue Yu2   
Joyce C. Ho1 Linjun Zhang3 Haoyu Wang4 Wenqi Shi5 Carl Yang1

1Emory University 2Georgia Institute of Technology 3Rutgers University 4SUNY Albany 5UT Southwestern Medical Center Dataset/Model: https://huggingface.co/AceSearcher Code: https://github.com/ritaranx/AceSearcher/

# Abstract

Search-augmented LLMs often struggle with complex reasoning tasks due to ineffective multi-hop retrieval and limited reasoning ability. We propose AceSearcher, a cooperative self-play framework that trains a single large language model (LLM) to alternate between two roles: a decomposer that breaks down complex queries and a solver that integrates retrieved contexts for answer generation. AceSearcher couples supervised fine-tuning on a diverse mixture of search, reasoning, and decomposition tasks with reinforcement fine-tuning optimized for final answer accuracy, eliminating the need for intermediate annotations. Extensive experiments on three reasoning-intensive tasks across 10 datasets show that AceSearcher outperforms state-of-the-art baselines, achieving an average exact match improvement of $7 . 6 \%$ . Remarkably, on document-level finance reasoning tasks, AceSearcher-32B matches the performance of the giant DeepSeek-V3 model using less than $5 \%$ of its parameters. Even at smaller scales (1.5B and 8B), AceSearcher often surpasses existing search-augmented LLMs with up to $9 \times$ more parameters, highlighting its exceptional efficiency and effectiveness in tackling complex reasoning tasks.

# 1 Introduction

Large language models (LLMs) have demonstrated remarkable performance in areas such as natural language generation [65, 80, 17] and complex reasoning [26, 20]. However, they often fall short when handling long-tailed or dynamically evolving knowledge [48]. To address these limitations, a growing body of work has explored augmenting LLMs with external search tools that retrieve relevant information at inference time. Search-augmented LLMs not only improve factual accuracy [2, 58], but also facilitate efficient adaptation to new tasks and domains without costly parameter updates [78].

Despite notable advances in retrieval-augmented generation (RAG) [2, 39, 45, 86, 50], most existing approaches are restricted to relatively simple questions [33, 48] solvable through single-turn retrieval. However, real-world applications often demand more complex reasoning, requiring (i) multi-hop retrieval to gather relevant evidence from large corpora due to the low recall of direct single-step retrieval [83], and $( i i )$ reasoning capability to integrate multiple pieces of information beyond span extraction for response generation [9]. To address these challenges, prior works propose multi-step search via iterative prompting [68, 31, 36, 42, 88], often relying on powerful, closed-source LLMs with strong reasoning abilities. Alternatively, tree-search algorithms have been explored to improve retrieval and reasoning at inference time [27, 72, 77], but at the expense of increased latency. Recent efforts employing reinforcement learning (RL) frameworks allow LLMs to interact with search engines [30, 92, 62, 4, 63]. While promising, these methods are often memory-intensive and thus less practical for deployment in resource-constrained environments. Additionally, their exclusive reliance on QA datasets for supervision limits the broader potential of LLMs to integrate search with complex, multi-step reasoning across a wider range of tasks.

Motivated by these challenges, we aim to develop an efficient, data-centric training recipe to enhance the capabilities of LLMs for reasoning-intensive search scenarios. Inspired by human problemsolving strategies – where complex tasks are decomposed into simpler subproblems [93, 31, 59], we propose AceSearcher that trains LLMs to act as two roles: decomposer and solver. The decomposer breaks down the original question into subquestions to guide retrieval, while the solver generates intermediate and final answers by integrating subquestions, their answers, and context.

We then introduce a two-stage fine-tuning framework to train both the decomposer and solver modules. In the first stage, we perform supervised fine-tuning (SFT) by extending existing open-domain QA datasets with open-source reasoning data. This covers task decomposition and problem-solving in both text and code. This simultaneously boosts the model’s ability to extract relevant information from context as well as strengthens its general reasoning capabilities. In the second stage, we apply reinforcement fine-tuning on targeted reasoning and QA tasks, using rewards derived solely from final outputs. To overcome the lack of intermediate annotations, we hypothesize that better decompositions lead to more accurate answers. The solver is reinforced to produce correct answers based on decompositions and context, while the decomposer is optimized to maximize the solver’s accuracy. This framework promotes joint structured reasoning across both roles with one unified model, while eliminating dependence on supervision from proprietary frontier models. Notably, AceSearcher achieves strong performance using iterative preference optimization, without relying on memory-intensive online RL training or costly inference-time scaling.

Our contributions can be summarized as follows:

• We introduce AceSearcher, a cooperative self-play framework designed to jointly enhance LLM’s capabilities in both search and reasoning. By introducing two roles, namely the decomposer and solver, AceSearcher equips a single LLM with joint skills of task decomposition and task solving, providing an efficient and flexible solution for complex reasoning in search-augmented settings. • We propose a two-stage fine-tuning framework that first applies SFT on a mixture of retrieval, reasoning, and decomposition datasets, followed by reinforcement fine-tuning using rewards solely from the final answer to train the decomposer and solver without intermediate supervision. This approach can be readily applied to LLMs with varying sizes $1 . 5 \mathrm { B } \cdot 3 2 \mathrm { B }$ as shown in our study) to enhance the multi-step reasoning ability of search-augmented LLMs. • We conduct extensive evaluations of AceSearcher covering three tasks across ten public datasets. Compared to strong baselines, including recent reasoning models and RL-enhanced search LLMs, AceSearcher demonstrates strong empirical performance with $7 . 6 \%$ gain on average. Moreover, AceSearcher demonstrates high parameter efficiency: the 1.5B variant matches the performance of models $1 0 \times$ larger on QA tasks, highlighting its suitability for low-resource settings.

# 2 Related Works

Reasoning-intensive Search/Retrieval. Standard RAG pipelines often consider single-step retrieval only and cannot handle complex questions well [34, 58, 18]. To incorporate reasoning into RAG pipelines, earlier research [68, 70, 71, 36, 88] design multi-turn prompting techniques for complex QA. Besides, several works [2, 75] leverage SFT on high-quality chain-of-thoughts to improve the reasoning skills of LLMs, but without explicit task decomposition. Additionally, [27, 77] design reward-guided search during inference time, [22, 79] trains the query refinement model based on the feedback of generator LLMs, and [6, 37] leverage multi-agent fine-tuning to further enhance reasoning performance, but at the cost of serving multiple LLMs in deployment.

Self-play Finetuning for LLMs. Self-play [60] is an effective technique that enables LLMs to learn through self-interaction, promoting diverse experience trajectories and prompt coverage. Recent studies have applied self-play to alignment [8, 76, 84], instruction following [13], theorem proving [15], and reasoning [10, 89]. Unlike these works, we consider collaborative self-play for complex problem solving, and tailor LLM self-play frameworks specifically for reasoning-intensive RAG applications.

![](images/c0637694bb398a34463725e87de67a4d40509d0d6a5be78ee40ed5544999e25a.jpg)  
Figure 1: Overview of AceSearcher. AceSearcher contains a two-stage training process to teach LLM for joint precise question decomposition and answer generation with cooperative self-play.

RL for Search-augmented LLMs. Very recently (concurrent to us), multiple studies [4, 62, 30, 92, 29] attempted to leverage the RL pipeline for RAG by viewing the search as an external tool and using open-domain QA datasets (e.g. NQ [33], HotpotQA [83]) to create verification rewards. In contrast to these approaches, we propose a data-centric pipeline that enhances LLM retrieval and reasoning capabilities through a unified self-play fine-tuning framework. Our method demonstrates strong generalization across a broad range of reasoning-intensive RAG tasks beyond multi-hop QA.

# 3 Overview of AceSearcher

In this section, we first define the problem setup and present an overview of AceSearcher. Then, we introduce the training and inference pipeline for AceSearcher.

# 3.1 Problem Formulation

In our setting, let $\mathcal { Q }$ denote the space of questions and $\mathcal { A }$ the space of all possible answers. Given a question $q \in \mathcal { Q }$ and corpus $\mathcal { C }$ (e.g. Wikipedia) that provides background knowledge, the retriever (often embedding models) first find a small set of relevant passages $\mathcal { D } = \{ d _ { 1 } , . . . d _ { k } \}$ , then the LLM $f _ { \theta }$ generates the output $a ^ { \prime } \in { \mathcal { A } }$ conditioned on both $q$ and $\mathcal { D }$ as $a ^ { \prime } \sim p _ { \theta } ( \cdot \mid q , \mathcal { D } )$ . Note that $a ^ { \prime }$ can be a short- or long-form response, depending on the type of task. In reasoning-intensive scenarios, the question $q$ may require multi-step reasoning beyond simple retrieval to produce accurate answers.

# 3.2 AceSearcher: A Cooperative Self-Play Framework

Our AceSearcher model, shown in Figure 1, tightly couples reasoning and search by enabling a single LLM to act as two roles (controlled by different input and prompt templates):

$\diamond \mathbf { A }$ decomposer $\rho$ that converts the original question $q$ into a sequence of subquestion templates1 $z = ( z _ { 1 } , z _ { 2 } , \ldots , z _ { n } )$ , where the number of subquestions is $n$ and $z _ { i }$ may depend on answers to earlier subquestions. These templates are sampled from $z \sim p _ { \theta } ( \cdot \mid q )$ .

$\diamond \mathbf { A }$ solver $\pi$ that generates intermediate answers $w = ( w _ { 1 } , w _ { 2 } , \ldots , w _ { n } )$ and final answer $a ^ { \prime }$ in a stepwise manner: For each subquestion $z _ { i } \in z$ , the solver produces the intermediate answer as $w _ { i } \sim$ $p _ { \theta } \bar { ( } \cdot \mid z _ { i } , w _ { < i } , \mathcal { D } _ { i } )$ , where $w _ { < i }$ denotes the answers to previous subquestions, ${ \mathcal { D } } _ { i } = \{ d _ { i , 1 } , \ldots , d _ { i , k } \}$ is the set of retrieved passages for $z _ { i }$ . After solving subquestions, the solver predicts the final answer $a ^ { \prime } \sim p _ { \theta } ( \cdot \mid q , z , w , \mathcal { D } )$ based on the original question, intermediate answers and context passages.

Joint Learning Objective. Given the question $q$ , we train $\theta$ to maximize the probability of the LLM for generating the final answer $a$ . In our framework, the learning objective can be written as

$$
p _ { \theta } ( a \mid q ) = \sum _ { z } p _ { \theta } ( z \mid q ) \left( \sum _ { w } p _ { \theta } ( a \mid q , z , w ) p _ { \theta } ( w \mid q , z ) \right)
$$

In practice, marginalizing over all possible decompositions $z$ and intermediate answers $w$ is intractable. To approximate it during training, we sample a small set of candidate $( z , w )$ paths and

identify the most promising ones to encouraging the decomposer to help the solver generate the correct answer. At inference time, given a question $q$ , the decomposer $\rho$ generates a subquestion sequence $z$ , and the solver $\pi$ reasons over the intermediate answer to derive the final answer $a ^ { \prime }$ .

# 4 Two-Stage Finetuning for AceSearcher

To enable the LLM to perform both roles effectively, we first apply SFT on publicly available datasets to establish its foundational capabilities. Subsequently, we perform reinforcement fine-tuning to further improve LLM’s capabilities, using only final answers as supervision.

# 4.1 Stage I: Supervised Finetuning (SFT)

Although recent studies have introduced data mixing strategies for search-augmented LLMs [39, 45, 86, 37], they focus on enhancing the LLM’s ability to extract answers from provided contexts. In contrast, our setting presents a greater challenge – requiring the LLM to automatically decompose and solve complex questions across a diverse range of tasks that requires reasoning. Towards this goal, we extend the SFT data mixture $\mathcal { D } _ { \mathrm { s f t } }$ for the following tasks:

• Context-rich QA Data. We follow [45, 39, 86, 37] to leverage multiple QA datasets to enhance the LLM’s capability of using context for generation. Specifically, we consider the following datasets: NQ [33], SQuAD [56], DROP [16], NarrativeQA [32], Quoref [12], ROPES [38], FEVER [66], TAT-QA [94], which contains a question, context passages, and an answer. • Question Decomposition Data. To improve the LLM’s ability to decompose complex questions into simpler subproblems, we incorporate GSM8K [11], ConvFinQA [9], and StrategyQA [19]. These datasets require generating a sequence of subquestions for solving the original problem. • Chain-of-thought Data. To enhance multi-step reasoning, we leverage chain-of-thought datasets including GSM8K [11], TabMWP [46], and IfQA [85]. Inspired by studies showing that combining Chain-of-Thought (CoT) [74] and Program-of-Thought (PoT) [5] rationales can boost reasoning capabilities, we incorporate MathInstruct [87], which contains CoT and PoT style prompts.

Detailed descriptions of datasets, prompt formats, and the number of training examples are provided in Appendix E, F. In total, we curate 180K training examples in the SFT stage. The LLM is fine-tuned using the standard next-token prediction objective.

# 4.2 Stage II: Preference-based Reinforcement Finetuning (RFT)

While SFT equips the LLM with basic capabilities for question decomposition and answer generation, it relies on richly annotated prompts with intermediate question decomposition and chain-of-thought annotations – resources that are limited in practice. To overcome this scarcity, we further fine-tune the LLM on prompts $\mathcal { D } = \{ ( q , a ) \}$ covering RAG and context-reasoning scenarios that contain only the final answer $a ^ { * }$ given the question $q$ . We frame this setting as an interactive environment, where the LLM learn to actively decompose the question and generate intermediate reasoning steps with external context. This motivates the use of reinforcement learning to optimize the reasoning trajectory in the absence of explicit intermediate supervision.

$\diamond$ Environment for RAG. We collect labeled pairs from multi-hop QA and fact verification datasets, including HotpotQA [83], 2WikiMHQA [21] and HOVER [28], which require the usage of retrieval to generate accurate answers. To formulate the RAG framework as an environment, the query decomposer $\rho$ first generates a sequence of candidate sub-questions $z = ( z _ { 1 } , \ldots , z _ { n } ) \in \mathcal { Q } ^ { n }$ . For each sub-question $q _ { i }$ , $k$ relevant documents are retrieved, denoted by $\mathcal { D } _ { i }$ . The solver $p _ { \theta }$ then produces intermediate solutions by generating $w _ { i } \sim p _ { \theta } \left( \cdot \mid z _ { i } , w _ { < i } , \mathcal { D } _ { i } \right)$ , conditioned on the current subquestion, previously generated answers, and retrieved context. Finally, the solver predicts the final answer as $\begin{array} { r } { a ^ { \prime } \sim p _ { \theta } ( \cdot \vert \mathbf { \bar { \bigcup } } _ { i = 1 } ^ { n } z _ { i } , \bigcup _ { i = 1 } ^ { n } w _ { i } , \bigcup _ { i = 1 } ^ { n } \mathcal { D } _ { i } ) } \end{array}$ .

$\diamond$ Environment for Context-Rich Reasoning. Beyond RAG-specific tasks, we also focus on improving the LLM’s reasoning abilities. To this end, we incorporate three datasets from the SFT stage, including GSM8K [11], TabMWP [46], and ConvFinQA [9], which involve reasoning over contexts $\mathcal { C }$ such as tables, passages, or problem conditions. Under this setting, $\rho$ is used to generate subquestions $z = ( z _ { 1 } , \ldots , z _ { n } ) \in \mathcal { Q } ^ { n }$ , and the solver $p _ { \theta }$ produces intermediate solutions by generating

$w _ { i } \sim p _ { \theta } \left( \cdot \mid z _ { i } , w _ { < i } , \mathcal { C } \right)$ , conditioned on the current subquestion, previous answers, and contexts.   
Finally, the solver predicts the final answer as $a ^ { \prime } \sim p _ { \theta } ( \cdot \mid \bar { \bigcup } _ { i = 1 } ^ { n } z _ { i } , \bar { \bigcup } _ { i = 1 } ^ { n } w _ { i } , \mathcal { C } )$ .

$\diamond$ Reward Design. For both scenarios, the complete trajectory $( q , z _ { 1 } , w _ { 1 } , \dots , z _ { n } , w _ { n } , a )$ is evaluated using a reward signal derived from the final answer. Specifically, the reward function is defined as:

$$
r ( \boldsymbol { q } , \boldsymbol { a } ^ { \prime } , \boldsymbol { a } ) = \mathrm { E M } ( \boldsymbol { a } ^ { \prime } , \boldsymbol { a } ) \times \mathbb { I } ( \boldsymbol { f } ( \boldsymbol { q } , \boldsymbol { a } ^ { \prime } ) = 1 ) ,
$$

where EM denotes the exact match between the model-generated $a ^ { \prime }$ and ground-truth answer $a$ . The function $f ( \boldsymbol { q } , \boldsymbol { a } ^ { \prime } )$ represents a format-based binary reward, verifying whether the model generates sub-questions, intermediate answers, and reasoning steps in the correct structure.

Optimization $\pi _ { \theta }$ and $\rho _ { \theta }$ . During the RL phase, we use the reward function defined above as the feedback to update both $\pi _ { \theta }$ and $\rho _ { \theta }$ . Denote $\bar { u } _ { \theta } ( a , z , w | q ) = p _ { \theta } ( z | q ) p _ { \theta } ( w , a | q , z )$ . Following existing works [52], the overall optimization objective is formulated as

$$
\begin{array} { r } { \underset { \theta } { \mathop { \operatorname* { m a x } } } \mathbb { E } _ { q } [ \mathbb { E } _ { z \sim \rho _ { \theta } , ( w , a ^ { \prime } ) \sim \pi _ { \theta } } [ r ( q , a ^ { \prime } , a ) ] - \beta \mathbb { D } _ { \mathrm { K L } } [ u _ { \theta } ( a ^ { \prime } , z , w \mid q ) ] \| u _ { \mathrm { r e f } } ( a ^ { \prime } , z , w \mid q ) ] ] , } \end{array}
$$

where $\beta$ is the parameter for controlling deviation from the reference policy. We further decompose the KL divergence between $u _ { \theta }$ and $u _ { \mathrm { r e f } }$ as

$$
\begin{array} { r l } & { \mathbb { D } _ { \mathrm { K L } } ( u _ { \theta } \| u _ { \mathrm { r e f } } ) = \displaystyle \sum _ { a ^ { \prime } , z , w } u _ { \theta } ( a ^ { \prime } , z , w | q ) \left[ \log p _ { \theta } ( z ) + \log p _ { \theta } ( w , a ^ { \prime } | z , q ) - \log p _ { \mathrm { r e f } } ( z ) - \log p _ { \mathrm { r e f } } ( w , a ^ { \prime } | z , q ) \right] } \\ & { \quad \quad = \underbrace { \displaystyle \sum _ { z } p _ { \theta } ( z | q ) \left[ \log \frac { p _ { \theta } ( z | q ) } { p _ { \mathrm { r e f } } ( z | q ) } \right] } _ { \mathbb { D } _ { \mathrm { K L } } ( \rho _ { \theta } | | \rho _ { \mathrm { e f } } ) } + \displaystyle \sum _ { z } p _ { \theta } ( z | q ) \underbrace { \sum _ { w , a ^ { \prime } } p _ { \theta } ( w , a ^ { \prime } | z , q ) \left[ \log \frac { p _ { \theta } ( w , a ^ { \prime } | z , q ) } { p _ { \mathrm { r e f } } ( w , a ^ { \prime } | z , q ) } \right] } _ { \mathbb { D } _ { \mathrm { K L } } ( \pi _ { \theta } | | \pi _ { \mathrm { r e f } } ) } . } \end{array}
$$

Then, the optimization objective can be rewritten as

$$
\begin{array} { r } { \underset { \ b { a } } { \mathrm { m a x } } \mathcal { I } _ { \ b { \theta } } = \mathbb { E } _ { \ b { q } } \left[ \mathbb { E } _ { z \sim \rho _ { \theta } , ( \boldsymbol { w } , \boldsymbol { a } ^ { \prime } ) \sim \pi _ { \theta } } [ r ( \boldsymbol { q } , \boldsymbol { a } ^ { \prime } , \boldsymbol { a } ) ] - \beta \mathbb { D } _ { \mathbf { K L } } ( \rho _ { \theta } \| \rho _ { \mathrm { r e f } } ) - \beta \mathbb { E } _ { z \sim \rho _ { \theta } } [ \mathbb { D } _ { \mathbf { K L } } ( \pi _ { \theta } \| \pi _ { \mathrm { r e f } } ) ] \right] . } \end{array}
$$

The above optimization problem have the closed-form solution (details in Appendix B) [55] as

$$
\begin{array} { r l } & { \quad p ^ { * } ( z \mid q ) \propto p _ { \mathrm { r e f } } ( z \mid q ) \mathbb { E } _ { ( w , a ^ { \prime } ) \sim p _ { \mathrm { r e f } } ( \cdot \mid q , z ) } \left[ \exp \left( \displaystyle \frac { 1 } { \beta } r ( q , a ^ { \prime } , a ) \right) \right] , } \\ & { \quad p ^ { * } ( w , a ^ { \prime } \mid q , z ) \propto p _ { \mathrm { r e f } } ( w , a ^ { \prime } \mid q , z ) \exp \left( \displaystyle \frac { 1 } { \beta } r ( q , a ^ { \prime } , a ) \right) . } \end{array}
$$

What does the form of $\pi ^ { * }$ and $\rho ^ { * }$ imply? The closed-form policies $\rho ^ { * }$ (i.e. $p ^ { * } ( z \mid q ) )$ and $\pi ^ { * }$ (i.e. $p ^ { * } ( w , a ^ { \prime } \mid q , z ) )$ align with our intuitions: an effective decomposition policy $\rho$ promotes higher overall expected reward by enabling better intermediate reasoning steps, while an improved solver $\pi$ directly enhances the reward, regardless of the quality of the decomposition.

Practical Implementation for Optimization. In practice, direct optimization under sparse reward signals from single-trajectory rollouts is often ineffective due to high variance and limited feedback. We employ a rollout strategy to address this challenge and enrich the learning signal. For each question $q$ , we first generate $m$ candidate decompositions by sampling from the decomposer policy, i.e., $z ^ { ( i ) } \sim \rho _ { \theta } ( \cdot \mid q )$ for $i = 1 , \ldots , m$ . Then, for each decomposition $z ^ { ( i ) }$ , we subsequently sample $m ^ { \prime }$ candidate solutions by drawing from the solver policy as $a _ { j } \sim \pi _ { \theta } ( \cdot ( \textit { \textbf { q } } , z ^ { ( i ) } )$ for $j = 1 , \dots , m ^ { \prime }$ . To construct preference datasets for RFT, we first identify the best and worst decompositions for each question $q$ based on the expected reward over their corresponding solutions as $\bar { r } ( q , z ^ { ( i ) } ) = \mathbb { E } _ { ( w , a ^ { \prime } ) \sim \pi ( \cdot \vert q , z ^ { ( i ) } ) } r ( q , a ^ { \prime } , a )$ . This results in the following preference pair dataset:

$$
\mathcal { D } _ { \mathrm { d e c o m p o s e } } = \{ ( q , z ^ { ( i + ) } , z ^ { ( i - ) } ) | ( q , a ) \in \mathcal { D } \} , \mathrm { ~ w h e r e ~ } \left\{ \begin{array} { l l } { z ^ { ( i + ) } = z ^ { ( j ) } , j = \arg \operatorname* { m a x } _ { i } \bar { r } ( q , z ^ { ( i ) } ) , } \\ { z ^ { ( i - ) } = z ^ { ( j ^ { \prime } ) } , j ^ { \prime } = \arg \operatorname* { m i n } _ { i } \bar { r } ( q , z ^ { ( i ) } ) . } \end{array} \right.
$$

Constructing preference pairs to optimize the answer generation policy $\pi$ (with fixed subquestions $z$ ) is more challenging due to the presence of multiple intermediate answers along the reasoning trajectory. Denote the trajectory $\bar { \mathcal { T } } ^ { ( i ) } = ( q , z _ { 1 } , w _ { 1 } ^ { ( i ) } , \dotsc , z _ { n } , w _ { n } ^ { ( i ) } , a ^ { \prime ( i ) } )$ with $a ^ { \prime ( i ) }$ being the final prediction, we create preference pairs for intermediate $\mathcal { D } _ { \mathrm { s u b q } }$ and final question answering $\mathcal { D } _ { \mathrm { f i n a l } }$ as

$$
\begin{array} { r l } & { \mathcal { D } _ { \mathrm { s u b q } } = \cup _ { i = 1 } ^ { n } \left\{ \left( z _ { i } , w _ { i } ^ { + } , w _ { i } ^ { - } \right) \mid w _ { i } ^ { + } \neq w _ { i } ^ { - } , ( q , a ) \in \mathcal { D } , ( z _ { i } , w _ { i } ^ { + } ) \in \mathcal { T } ^ { + } , ( z _ { i } , w _ { i } ^ { - } ) \in \mathcal { T } ^ { - } \right\} , } \\ & { \mathcal { D } _ { \mathrm { f i n a l } } = \left\{ \left( [ q , z _ { 1 } , w _ { 1 } ^ { + } , \ldots , z _ { n } , w _ { n } ^ { + } ] , a ^ { \prime + } , a ^ { \prime - } \right) \mid ( q , a ) \in \mathcal { D } \right\} . } \end{array}
$$

where the best and worst trajectories are selected as:

$$
\begin{array} { r l } & { \mathcal { T } ^ { + } = ( \boldsymbol { q } , \boldsymbol { z } _ { 1 } , \boldsymbol { w } _ { 1 } ^ { + } , \ldots , \boldsymbol { z } _ { n } , \boldsymbol { w } _ { n } ^ { + } , \boldsymbol { a } ^ { \prime + } ) , \quad \mathrm { ~ w h e r e ~ } \boldsymbol { a } ^ { \prime + } = \arg \operatorname* { m a x } _ { i } r ( \boldsymbol { q } , \boldsymbol { a } ^ { \prime ( i ) } , \boldsymbol { a } ) , } \\ & { \mathcal { T } ^ { - } = ( \boldsymbol { q } , \boldsymbol { z } _ { 1 } , \boldsymbol { w } _ { 1 } ^ { - } , \ldots , \boldsymbol { z } _ { n } , \boldsymbol { w } _ { n } ^ { - } , \boldsymbol { a } ^ { \prime - } ) , \quad \mathrm { ~ w h e r e ~ } \boldsymbol { a } ^ { \prime - } = \arg \operatorname* { m i n } _ { i } r ( \boldsymbol { q } , \boldsymbol { a } ^ { \prime ( i ) } , \boldsymbol { a } ) . } \end{array}
$$

To jointly optimize both the decomposer $\rho$ and the solver $\pi$ , we construct a unified preference dataset by combining three sources of pairs: $\mathcal { D } _ { \mathrm { p r e f } } = \mathcal { D } _ { \mathrm { d e c o m p o s e } } \cup \mathcal { D } _ { \mathrm { s u b q } } \cup \mathcal { D } _ { \mathrm { f i n a l } }$ . For notational consistency, we represent each example as $( x , g ^ { + } , g ^ { - } )$ , where $x$ is the input, and $g ^ { + } , g ^ { - }$ are the chosen and rejected responses. Following [55], we optimize the policy with the following preference loss:

$$
\mathcal { L } _ { \mathrm { D P O } } : = - \mathbb { E } _ { ( x , g ^ { + } , g ^ { - } ) \sim \mathcal { D } _ { \mathrm { p r e f } } } \log \sigma \left( \beta \left[ \log \frac { p _ { \theta } \left( g ^ { + } \mid x \right) } { p _ { \mathrm { r e f } } \left( g ^ { + } \mid x \right) } - \log \frac { p _ { \theta } \left( g ^ { - } \mid x \right) } { p _ { \mathrm { r e f } } \left( g ^ { - } \mid x \right) } \right] \right) .
$$

Multi-turn DPO for Online Optimization. Motivated by the benefits of on-policy data sampling in RL, we adopt an iterative DPO framework for improved optimization. Specifically, in the $t$ -th iteration, we use the LLM policy model2 $f _ { \theta } ^ { ( t ) }$ to act as $\pi _ { \theta }$ and $\rho _ { \theta }$ to sample preference pairs to create the dataset D(t)pref . Then, we use $\mathcal { D } _ { \mathrm { p r e f } } ^ { ( t ) }$ to update the policy model for the next iterati on f (t+1)θ a s

$$
\mathcal { L } _ { \mathrm { m D P O } } : = - \mathbb { E } _ { ( x , g ^ { + } , g ^ { - } ) \sim \mathcal { D } _ { \mathrm { p e f } } ^ { ( t ) } } \log \sigma \left( \beta \left[ \log \frac { p _ { \theta } ^ { ( t + 1 ) } ( g ^ { + } \mid x ) } { p _ { \theta } ^ { ( t ) } ( g ^ { + } \mid x ) } - \log \frac { p _ { \theta } ^ { ( t + 1 ) } ( g ^ { - } \mid x ) } { p _ { \theta } ^ { ( t ) } ( g ^ { - } \mid x ) } \right] \right) .
$$

Remark. To balance effectiveness and efficiency in practice, we adopt the following strategy: the model $\pi _ { \theta }$ directly generates answers for intermediate questions, while producing a full rationale only for the final answer. To prevent overly long input contexts during final answer generation, we set the total number of documents to $N$ $N = 1 5$ in this study), and allocate up to $\lfloor N / n \rfloor$ top-ranked documents for each of $n$ subquestions produced by $\pi _ { \theta }$ . We discard preference pairs if the reward for the best and the worst response is the same.

Theorem 4.1 (Informal). Under regularity conditions, with high probability, the minimizer of the loss (Eq. (4.5)) at step $t$ is close to the minimizer of the loss (Eq. (4.2)). Furthermore, as $t$ increases, the minimizer converges to the true parameter $\theta ^ { * }$ .

The proof for the theorem is deferred to Appendix C due to the space limit. This theorem implies that our optimization algorithm is equivalent to maximizing the reward in Eq. (4.2). Furthermore, it guarantees convergence of our algorithm, which we also empirically validate in Section 5.4.

# 5 Experiments

In this section, we conduct experiments on various tasks to verify the effectiveness of AceSearcher.

# 5.1 Experiment Setups

Tasks and Dataset Information. We consider the following 3 types of tasks: (i) Multi-hop QA, which includes 2WikiMHQA [21], HotpotQA [83], Bamboogle [53] and MusiQue [67]. (ii) Multi-hop Fact Verification, namely HOVER [28] and Exfever [47]. (iii) Document-level Reasoning, where we use the DocMath-Eval benchmark [91] with several financial reasoning datasets such as TAT-QA [94], FinQA [7], MultiHiertt [90], and TAT-HQA [35]. Note that some of datasets have very long contexts that make retrieval necessary. The detailed information for these datasets is in Appendix D.

Baselines. For Multihop QA and Fact Verification tasks, we compare against the following categories of baselines: (i) Instruction-tuned LLMs with Single-turn RAG: we consider Llama-3.1-it [17], DeepSeek-R1-Distill [20], Qwen-3 $[ 8 0 ] ^ { 3 }$ , Llama-4-Maverick [1], GPT-4o [25], and GPT-4.1 [51]. (ii) Prompt-based Multi-step Retrieval: we include IRCOT [68], Plan-RAG [70], Search-o1 [36], IterDRAG [88]. (iii) Finetuned LLMs with Search: we compare with InstructRAG [75], RAGStar [27], ReARTeR [64], CORAG [72] and Iter-RetGen [57]. (iv) LLMs with Search Trained via Reinforcement Learning: Recent agentic search-augmented works such as Search-R1 [30], R1- Searcher [62], DeepResearcher [92], MMOA-RAG [6], and ReSearch [4] are also included for comprehensive evaluation. For document-level reasoning, we follow DocMath-Eval [91] to compare against general instruction-tuned LLMs [51, 25, 65, 40, 41, 17], reasoning LLMs [26, 20, 80], Code LLMs [96, 24], Math LLMs [43, 82] and specialized finance reasoning LLMs [44, 95].

Table 1: Comparison of AceSearcher and baselines on Multi-hop QA and Fact Verification datasets. “–” stands for results that are not publicly available. †: This model often does not follow instructions and generates long answers. ‡: Concurrent works (preprint appears online after 2025/03/01).   

<table><tr><td rowspan="2">Baselines</td><td colspan="2">2WikiMHQA</td><td colspan="2"></td><td colspan="2">HotpotQA</td><td colspan="2">Bamboogle</td><td colspan="2">MusiQue</td><td></td><td>Hover</td><td>ExFever</td><td>Avg. QA Avg. All</td><td></td></tr><tr><td>Acc EM</td><td></td><td>F1</td><td>Acc EM</td><td>F1</td><td>Acc</td><td>EM</td><td>F1 1</td><td>Acc</td><td>EM</td><td>F1</td><td>EM</td><td>EM</td><td>Acc /EM</td><td>EM</td></tr><tr><td colspan="10">Base Size:&lt;10B parameters</td><td colspan="7"></td></tr><tr><td>Llama-3.1-it RAG 8B[17]</td><td>43.0</td><td>16.0</td><td>26.5</td><td>46.2 24.4</td><td>34.5</td><td>24.8</td><td>5.6</td><td>15.1</td><td>19.8</td><td>7.2</td><td>12.5</td><td>66.3</td><td>45.0</td><td>33.5/13.3</td><td>27.4</td></tr><tr><td>R1-Distill RAG 8B[20]</td><td>50.8</td><td>30.0</td><td>42.8</td><td>45.2</td><td>25.2 36.2</td><td>39.2</td><td>25.6</td><td>37.3</td><td>21.6</td><td>12.4</td><td>21.4</td><td>63.0</td><td>48.2</td><td>39.2/23.3</td><td>34.1</td></tr><tr><td>Qwen-3 RAG 8B [80]</td><td>54.2</td><td>35.4</td><td>46.4</td><td>56.0</td><td>42.0 55.1</td><td>50.4</td><td>33.6</td><td>46.1</td><td>26.2</td><td>15.2</td><td>23.8</td><td>65.7</td><td>68.8</td><td>46.7/31.6</td><td>43.5</td></tr><tr><td>Plan-RAG 8B [70]</td><td>47.8</td><td>36.6</td><td>46.0</td><td>47.6 35.2</td><td>45.1</td><td>31.0</td><td>23.4</td><td>32.2</td><td>20.4</td><td>12.2</td><td>21.2</td><td>57.9</td><td>62.5</td><td>36.7/26.9</td><td>38.0</td></tr><tr><td>Search-R17B‡ [30]</td><td></td><td>38.2</td><td>一</td><td>43.3</td><td></td><td></td><td>43.2</td><td></td><td></td><td>19.6</td><td></td><td></td><td>一</td><td>-/36.1</td><td>1</td></tr><tr><td>R1-Searcher 7B‡ [62]</td><td>63.6</td><td></td><td></td><td>65.4</td><td></td><td>52.8</td><td></td><td></td><td>28.2</td><td></td><td></td><td></td><td></td><td>52.5/-</td><td></td></tr><tr><td>DeepResearcher 7B[92]</td><td>66.6</td><td></td><td>59.7</td><td>64.3</td><td>52.8</td><td>72.8</td><td></td><td>71.0</td><td>29.3</td><td></td><td>27.1</td><td></td><td></td><td></td><td></td></tr><tr><td>InstructRAG 8B[75]</td><td>58.6</td><td>43.2</td><td>49.5</td><td>54.6 44.0</td><td>54.4</td><td>35.2</td><td>24.8</td><td>35.5</td><td>21.2</td><td>14.8</td><td>22.8</td><td>65.3</td><td>58.0</td><td>42.4/31.7</td><td>41.7</td></tr><tr><td>MMOA-RAG 8B [6]</td><td>42.8</td><td>41.4</td><td>46.4</td><td>39.2 36.2</td><td>48.3</td><td></td><td></td><td>一</td><td>一</td><td></td><td></td><td>1</td><td>1</td><td>一</td><td>1</td></tr><tr><td>CORAG 8B(Greedy)[72]</td><td></td><td>56.5</td><td>62.3 77.3</td><td>50.1</td><td>63.2</td><td></td><td></td><td>37.651.4</td><td></td><td>18.6</td><td>29.3</td><td>一</td><td>1</td><td>-/40.7</td><td>1</td></tr><tr><td>CORAG 8B (Inference Scaling) [72] AceSearcher1.5B</td><td></td><td>72.5 60.6</td><td>68.5</td><td>56.3</td><td>69.8</td><td></td><td>544</td><td>68.3</td><td></td><td>30.9</td><td>42.4</td><td></td><td></td><td>-153.5</td><td></td></tr><tr><td>AceSearcher 8B</td><td>69.8 80.6</td><td>66.0</td><td>76.7</td><td>60.6 50.4 68.2 58.8</td><td>59.8 69.2</td><td>38.4 60.8</td><td>33.6 55.2</td><td>41.7 63.5</td><td>37.2 46.8</td><td>26.8 35.4</td><td>37.0</td><td>60.7 68.3</td><td>64.2 73.8</td><td>51.5/42.9 64.1/53.9</td><td>4</td></tr><tr><td colspan="10">LargeSize:10-30B parameters</td><td>47.7</td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>Qwen-2.5-it RAG 14B[81]</td><td>44.4</td><td>17.8</td><td>29.1</td><td>50.4</td><td>35.6</td><td>48.1</td><td>40.8</td><td>35.4</td><td>21.8</td><td>9.8</td><td>18.2</td><td>65.7</td><td>42.9</td><td></td><td></td><td>32.4</td></tr><tr><td>R1-Distill RAG 14B† [20]</td><td>31.8</td><td>8.4</td><td>11.4</td><td>45.6</td><td>11.2</td><td>14.6</td><td>34.8</td><td>22.4 12.1</td><td>20.8</td><td>1.8</td><td>5.2</td><td>68.3</td><td></td><td></td><td>39.4 /21.4 33.3/7.4</td><td>26.7</td></tr><tr><td>Qwen-3RAG14B [80]</td><td>59.2</td><td>42.0</td><td>49.1</td><td>63.8</td><td>44.6</td><td>55.1</td><td>50.4</td><td>8.0</td><td></td><td></td><td></td><td></td><td></td><td>62.5</td><td>51.5/34.6</td><td>46.1</td></tr><tr><td>Plan-RAG 14B [70]</td><td>61.6</td><td>510</td><td>60.8</td><td>60.0</td><td>48.2</td><td>59.5</td><td>51.2</td><td>36.8 41.4</td><td>46.7</td><td>32.4</td><td>15.0 23.4</td><td>25.6</td><td>67.5</td><td>70.5 63.6</td><td>51.8/41.0</td><td></td></tr><tr><td>Search-R114B‡ [30]</td><td></td><td>47.0</td><td></td><td></td><td>46.8</td><td></td><td></td><td></td><td>53.2</td><td>34.2</td><td>24.1</td><td>32.4</td><td>52.5</td><td></td><td></td><td>46.7</td></tr><tr><td>InstructRAG 14B [75]</td><td>63.2</td><td>50.4</td><td>58.1</td><td>58.2</td><td>46.6</td><td>58.0</td><td>37.6</td><td>52.8</td><td></td><td></td><td></td><td>25.5</td><td>67.5</td><td>65.3</td><td>-142.7</td><td></td></tr><tr><td>AceSearcher14B</td><td>81.2</td><td>65.6</td><td>76.6</td><td>70.8</td><td>61.2</td><td>71.8</td><td>60.0</td><td>31.2 53.6</td><td>41.4 65.6</td><td>24.6 48.6</td><td>16.2</td><td>69.3</td><td></td><td>75.0</td><td>45.9/36.1 65.2/54.2</td><td>46.2 60.1</td></tr><tr><td colspan="10"></td><td colspan="7">47.4</td></tr><tr><td colspan="10">XL Size: &gt;30B parameters</td><td colspan="7">36.2</td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>Qwen-2.5-it RAG 32B</td><td>51.4</td><td>31.6</td><td>40.6 51.2</td><td>58.0</td><td>38.5</td><td>50.4</td><td>59.2</td><td>51.2</td><td>65.2</td><td>22.2</td><td>10.4</td><td>19.8</td><td>70.3</td><td>69.6</td><td>47.7/32.9</td><td>45.2</td></tr><tr><td>R1-Distill RAG 32B</td><td>57.2 61.0</td><td>39.4 39.8</td><td>51.5</td><td>63.2 65.4</td><td>49.0 49.0</td><td>62.7 62.4</td><td>56.4 56.8</td><td>46.4 40.8</td><td>58.9 53.6</td><td>30.4 32.6</td><td>18.6 19.0</td><td>30.7 30.7</td><td>72.3 70.5</td><td>67.0 65.3</td><td>51.8/38.4 54.0/37.2</td><td>48.8 47.4</td></tr><tr><td>Qwen-3 RAG 32B‡ [80] Search-ol 32B [36]</td></table>

Implementation Details. We consider four different backbones for AceSearcher with varying sizes including Qwen-2.5-Instruct-1.5B/14B/32B [81] and Llama-3.1-8B-Instruct [17]. For AceSearcher-32B, we apply LoRA fine-tuning [23] with $r = 8 , \alpha = 1 6$ , while other models use full fine-tuning. All models are trained with a batch size of 64 and maximum token of 2048 for 1 epoch on both SFT and RFT stages, with RFT run for 2 total iterations. For HotpotQA, 2WikiMHQA, MusiQue, we use the corpora provided by their respective sources. For Bamboogle, Hover, ExFever, we use the Wikipedia from Dec. 2018 as the corpus. During inference, we set the temperature $t = 0 . 0$ , the number of retrieved passages to $k = 1 0$ . For QA and fact verification tasks, we adopt E5 [73] as the retriever, while for document-level reasoning, we follow [91] and use OpenAI’s Embedding-3-Large as the retriever. Detailed implementation settings for AceSearcher and baselines are in Appendix G.

Evaluation. For QA, we report Exact Match (EM), Accuracy, and F1 score. For fact verification, we use EM as the metric. For document-level reasoning, we use Accuracy computed via the official evaluation script, and report the better performance between CoT and PoT prompting [54].

# 5.2 Evaluation on QA and Fact Verification

The main results comparing AceSearcher with baseline methods are presented in Table 1. From the results, we have the following key observations: (i) AceSearcher achieves strong performance over baselines. Notably, AceSearcher-32B achieves the highest overall score (60.7), outperforming both proprietary and open-source baselines by up to $7 . 6 \%$ . (ii) Compared to reasoning models, AceSearcher better adapt to RAG tasks. Qwen-3 and Deepseek-R1-distill are trained with extensive knowledge distillation, we observe that their gains are limited. This suggests that long thinking does not fully address the inherent challenge of multi-hop retrieval, while AceSearcher tackles this more effectively. (iii) AceSearcher has strong parameter efficiency. AceSearcher-1.5B matches or exceeds 8B baselines, while AceSearcher-8B outperforms baseline models with 70B parameters.

Table 3: Ablation results on QA and DocMath-Eval using Llama-3.1-8B. We report EM for QA and fact verification due to space constraints. For w/o $\rho$ and $w / o \pi$ , we replace the respective components with Llama-3.1-8B-Instruct. w/o Search excludes CQA, StrategyQA, and IfQA from SFT; w/o Reasoning removes GSM8K, TabMWP, ConvFinQA, and MathInstruct. $w / C Q A$ follows [45] and finetune solely on context-aware QA tasks.   

<table><tr><td>Model Name</td><td>2WikiMHQA</td><td>HotpotQA</td><td>Bamboogle</td><td>MusiQue</td><td>Hover</td><td>ExFever</td><td>Avg.</td><td>DMss</td><td>DMCs</td><td>DMSL</td><td>DMCL</td><td>|Avg.</td></tr><tr><td colspan="9">Ablation Study for Different Components of AceSearcher</td><td colspan="5"></td></tr><tr><td>AceSearcher</td><td>66.0</td><td>58.8</td><td>55.2</td><td>35.4</td><td>68.3</td><td>73.8</td><td>59.6</td><td>83.0</td><td>80.5</td><td>48.0</td><td>32.3</td><td>59.0</td></tr><tr><td>AceSearcher w/o RFT</td><td>61.8</td><td>53.8</td><td>52.0</td><td>34.8</td><td>64.1</td><td>71.4</td><td>56.2</td><td>71.5</td><td>73.0</td><td>49.0</td><td>26.7</td><td>52.3</td></tr><tr><td>AceSearcher w/o SFT</td><td>40.0</td><td></td><td>38.4</td><td>18.2</td><td>74.7</td><td>76.8</td><td>47.6</td><td>71.0</td><td>51.5</td><td>46.0</td><td>31.0</td><td>48.0</td></tr><tr><td>AceSearcher w/o p</td><td>57.8</td><td>3</td><td>53.6</td><td>32.4</td><td>65.0</td><td>70.5</td><td>55.3</td><td>81.5</td><td>78.0</td><td>45.0</td><td>29.6</td><td>56.6</td></tr><tr><td>AceSearcher W/oπ</td><td>41.4</td><td>32.0</td><td>20.8</td><td>12.2</td><td>63.7</td><td>75.0</td><td>40.9</td><td>73.5</td><td>72.0</td><td>45.0</td><td>27.7</td><td>52.4</td></tr><tr><td colspan="9">AblationStudy for SFTData Mixture</td><td colspan="5"></td></tr><tr><td>AceSearcher w/o Search</td><td>52.6</td><td>53.0</td><td>51.2</td><td>23.4</td><td>56.5</td><td>58.9</td><td>49.3</td><td>79.5</td><td>83.0</td><td>42.0</td><td>28.7</td><td>56.6</td></tr><tr><td>AceSearcher w/o Reasoning</td><td>62.4</td><td>55.8</td><td>44.8</td><td>36.6</td><td>57.7</td><td>71.4</td><td>548</td><td>76.5</td><td>74.0</td><td>38.0</td><td>29.7</td><td>53.5</td></tr><tr><td>AceSearcher w/CQA[45]</td><td>35.8</td><td>40.0</td><td>22.4</td><td>12.2</td><td>61.6</td><td>45.7</td><td>36.3</td><td>53.0</td><td>52.0</td><td>38.0</td><td>20.3</td><td>38.6</td></tr><tr><td colspan="9">Ablation Study forRLAlgorithms†</td><td colspan="5"></td></tr><tr><td>RAFT[14]</td><td>63.6</td><td>55.6</td><td>50.4</td><td>32.8</td><td>66.7</td><td>69.6</td><td>56.5</td><td>73.0</td><td>69.5</td><td>43.0</td><td>27.3</td><td>51.2</td></tr><tr><td>RESTEM[61]</td><td>65.4</td><td>57.6</td><td>51.2</td><td>32.8</td><td>67.5</td><td>68.7</td><td>57.2</td><td>77.5</td><td>81.0</td><td>48.0</td><td>28.0</td><td>56.1</td></tr><tr><td>Offline DPO [55]</td><td>64.6</td><td>57.8</td><td>53.6</td><td>35.2</td><td>64.6</td><td>73.2</td><td>58.2</td><td>73.5</td><td>83.5</td><td>49.0</td><td>30.0</td><td>56.6</td></tr><tr><td>(Iterative) SimPO [49]</td><td>67.2</td><td>57.2</td><td>46.8</td><td>34.6</td><td>69.3</td><td>70.5</td><td>57.6</td><td>75.5</td><td>78.0</td><td>44.0</td><td>32.0</td><td>55.9</td></tr></table>

# 5.3 Evaluation on Document-level Reasoning

We evaluate AceSearcher on DocMath-Eval (Table 2) against large-scale LLMs, demonstrating notable improvements over similarly-sized baselines, including both reasoning and domain-specific models. For instance, AceSearcher-32B and AceSearcher-8B outperform size-comparable baselines by $6 . 2 \%$ and $9 . 0 \%$ , respectively. Furthermore, AceSearcher achieves performance comparable to significantly larger models: AceSearcher32B matches the accuracy of DeepSeek-V3 using less than $5 \%$ of its parameters, while AceSearcher14B exceeds baselines up to 72B $( 5 \times )$ in size. These results highlight AceSearcher’s strong generalization capabilities beyond factual QA, particularly in complex reasoning scenarios involving long documents and tables.

# 5.4 Additional Studies

Ablation Study. Table 3 reports the results of AceSearcher. The top rows show that both SFT and RFT contribute to overall performance gains. Besides, AceSearcher improves both question decomposition $( \rho )$ and answer generation $( \pi )$ , as replacing each component with the frozen Llama-8b-it hurts the performance. This verifies the complementary roles of these two components.

Table 2: Results on DocMath-Eval [91], sorted by average performance. SS, CS, SL and CL stands for SimpShort, CompShort, SimpLong and CompLong, respectively.   

<table><tr><td>Datasets</td><td>DMss</td><td>DMcs</td><td>DMSL</td><td>DMCL</td><td>Avg.</td></tr><tr><td>Proprietary Models</td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>GPT-o3-mini</td><td>86.0</td><td>87.5</td><td>59.0</td><td>35.0</td><td>63.9</td></tr><tr><td>Gemini-1.5-Pro</td><td>85.5</td><td>80.0</td><td>58.0</td><td>40.3</td><td>63.7</td></tr><tr><td>GPT-4.1</td><td>85.5</td><td>75.0</td><td>62.0</td><td>39.3</td><td>62.6</td></tr><tr><td>GPT-40</td><td>86.0</td><td>76.5</td><td>64.0</td><td>36.7</td><td>62.4</td></tr><tr><td>Claude-3.5-Sonnet</td><td>78.0</td><td>76.0</td><td>54.0</td><td>44.0</td><td>61.8</td></tr><tr><td>Open-Sourced Models</td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>DeepSeek-V3 685B</td><td>89.5</td><td>86.0</td><td>53.0</td><td>42.3</td><td>66.4</td></tr><tr><td>AceSearcher 32B</td><td>89.5</td><td>84.0</td><td>53.0</td><td>43.0</td><td>66.1</td></tr><tr><td>DeepSeek-V2 236B</td><td>87.0</td><td>75.5</td><td>61.0</td><td>43.0</td><td>64.4</td></tr><tr><td>DeepSeek-R1 685B</td><td>89.0</td><td>83.5</td><td>53.0</td><td>38.7</td><td>64.3</td></tr><tr><td>DeepSeek-Coder-V2 236B</td><td>85.0</td><td>78.0</td><td>56.0</td><td>41.0</td><td>63.1</td></tr><tr><td>Mistral-Large 122B</td><td>85.0</td><td>76.5</td><td>56.0</td><td>41.0</td><td>62.8</td></tr><tr><td>AceSearcher 14B</td><td>84.0</td><td>82.0</td><td>49.0</td><td>39.3</td><td>62.4</td></tr><tr><td>AceMath 72B</td><td>77.5</td><td>77.0</td><td>59.0</td><td>39.7</td><td>60.9</td></tr><tr><td>Qwen-2.5-Math 72B</td><td>78.0</td><td>73.0</td><td>58.0</td><td>41.0</td><td>60.4</td></tr><tr><td>DianJin-R1 32B‡</td><td>76.0</td><td>77.0</td><td>46.0</td><td>42.3</td><td>59.9</td></tr><tr><td>AceSearcher 8B</td><td>83.0</td><td>80.5</td><td>48.0</td><td>32.3</td><td>59.0</td></tr><tr><td>Qwen-2.5-Coder 32B</td><td>81.0</td><td>79.0</td><td>57.0</td><td>30.0</td><td>58.4</td></tr><tr><td>DeepSeek-R1-Distill 70B</td><td>77.5</td><td>76.0</td><td>53.0</td><td>34.7</td><td>58.0</td></tr><tr><td>Qwen-2.5 72B</td><td>81.5</td><td>81.0</td><td>64.0</td><td>24.7</td><td>57.9</td></tr><tr><td>DeepSeek-R1-Distill 32B</td><td>74.0</td><td>71.0</td><td>50.0</td><td>40.3</td><td>57.6</td></tr><tr><td>Llama-3.3 70B</td><td>79.5</td><td>74.5</td><td>54.0</td><td>31.7</td><td>57.1</td></tr><tr><td>Qwen3 32B</td><td>80.0</td><td>78.0</td><td>44.0</td><td>25.3</td><td>54.5</td></tr><tr><td>Qwen3 14B</td><td>75.0</td><td>78.5</td><td>41.0</td><td>26.7</td><td>53.5</td></tr><tr><td>DianJin-R17B</td><td>67.0</td><td>68.5</td><td>41.0</td><td>29.3</td><td>50.0</td></tr><tr><td>AceMath 7B</td><td>65.5</td><td>62.0</td><td>47.0</td><td>26.7</td><td>47.8</td></tr><tr><td>AceSearcher 1.5B</td><td>66.5</td><td>77.5</td><td>39.0</td><td>18.0</td><td>47.6</td></tr><tr><td>Qwen3 8B‡</td><td>76.0</td><td>76.5</td><td>32.0</td><td>11.7</td><td>46.5</td></tr><tr><td>Fin-R17B</td><td>66.5</td><td>51.5</td><td>40.0</td><td>21.3</td><td>42.5</td></tr><tr><td>DeepSeek-Coder-V2 16B</td><td>67.5</td><td>53.5</td><td>30.0</td><td>20.3</td><td>41.6</td></tr><tr><td>Llama-3.18B</td><td>62.0</td><td>44.0</td><td>32.0</td><td>19.0</td><td>37.6</td></tr><tr><td>Qwen-2.5-Math 7B</td><td>52.0</td><td>49.0</td><td>36.0</td><td>16.7</td><td>36.0</td></tr></table>

Ablation Study For SFT Data. The middle rows in Table 3 show SFT performance under different data compositions. Removing either the Reasoning or Search data leads to performance drops across both knowledge-intensive tasks (QA and Fact Verification) and document-level reasoning, indicating that both components are jointly beneficial for building a capable LLM with search.

Ablation Study For RFT. In the bottom rows of Table 3, we compare our reinforcement finetuning algorithm with other alternatives and find AceSearcher achieves the best performance. This highlights the importance of using both positive and negative trajectories, and shows that online methods outperform their offline counterparts. Figure 2 shows results across RFT iterations of

![](images/5b38df436d81076216ac1cf119781f85b3479e763ba516202ec3477848a00078.jpg)  
Figure 2: Performance of AceSearcher over different stages.

![](images/0af6fe69875dd19b71dece0e513f8342e255292d8a4682ebfab0ac577adb02d0.jpg)  
Figure 3: Efficiency Studies of AceSearcher with Llama-3.1-8B-Instruct as the backbone.

![](images/6e1a1a37643596eff23c922e373cf748afcefb2297ece5f7fa94289321efa90b.jpg)  
Figure 4: Parameter Study

![](images/6ff4682346807f986a96cb939077d630a934e63f8280462c413dad18a07b24d6.jpg)  
Figure 5: Quality Analysis for AceSearcher

AceSearcher-8B. We observe significant gains in the first two iterations, with diminishing returns in the third. We set the number of iterations to 2 to balance between performance and efficiency.

# 5.5 Efficiency Studies

Data Efficiency. Figure 3(a) and 3(b) show the accuracy of AceSearcher under varying amounts of data. For SFT, we evaluate the performance with varying SFT subset sizes and its improvement after subsequent RFT. For RFT experiments, we fix the full SFT dataset to isolate the effect of RFT. With just 2K SFT examples $( \sim 1 \% )$ , AceSearcher matches strong baselines like Search-R1 and Search-O1 (with up to $4 \times$ more parameters), and surpasses them after RFT. In the RFT stage, the use of only 5K prompts leads to a $1 \%$ gain in QA and fact verification and a $2 \%$ gain on document-level reasoning, justifying the data efficiency of AceSearcher with a diverse set of prompts.

Inference Efficiency. Figure 3(c) shows the inference time of AceSearcher and baseline models on QA and fact verification tasks. Unless noted, all models are 8B or similar in size. While AceSearcher incurs higher latency than standard RAG due to question decomposition and multi-step reasoning, it achieves substantial performance gains – even outperforming 32B models with comparable inference time. Besides, AceSearcher outperforms reasoning models and inference-time scaling methods costs $1 . 5 \times$ to $2 . 8 \times$ more time. These results justify AceSearcher balances between efficiency and efficacy.

# 5.6 Parameter Studies

We study the effect of varying $k , m$ , and $m ^ { \prime }$ on AceSearcher. As shown in Figure 4(a), performance improves with more retrieved contexts, with gains plateauing at $k = 1 0$ , which we adopt in our experiments. In Figure 4(b) shows that increasing the number of sampled decompositions $( m )$ and final answers $( m ^ { \prime } )$ generally improves performance as it will generate more valid preference pairs, but increases trajectory collection time. The study on the effect of $\beta$ and retrievers is in Appendix H.

# 5.7 Quality Analysis of Question Decomposition Module

As question decomposition is a key component of AceSearcher, we analyze the quality of the generated subquestions. Figure 5(a) shows the average human evaluation scores (on a 1–5 scale) for 40 randomly sampled subquestions per task. We observe that both SFT and RFT significantly enhance subquestion quality across different model sizes. To quantify the impact of decomposition on end-task performance, we evaluate passage-level answer recall on HotpotQA after applying question decomposition. As shown in Figure 5(b), AceSearcher achieves up to a $2 5 \%$ improvement in recall $@ 1 0$ over standard retrieval and surpasses strong passage reranking model4. The details for human studies as well as more cases studies are given in the Appendix I.

# 6 Conclusion

We present AceSearcher, a cooperative self-play framework specifically designed for RAG and document-level reasoning tasks. By training a single LLM to act as both decomposer and solver, AceSearcher addresses complex multi-hop retrieval and reasoning effectively. Our two-stage finetuning framework combines SFT on diverse reasoning tasks with preference-based RFT guided by final answer accuracy, achieving strong performance without relying on expensive intermediate supervision. Evaluated on ten benchmarks, AceSearcher outperforms state-of-the-art models by $7 . 6 \%$ on multi-hop QA and fact verification, and matches Deepseek-V3 on document reasoning with under $5 \%$ of its parameters. Even with smaller models (1.5B, 8B), AceSearcher delivers competitive or superior performance, offering an efficient and generalizable solution for advanced reasoning under resource constraints.

# Acknowledgment

RX and CY were partially supported by the US National Science Foundation under Award Numbers 2319449, 2312502, and 2442172, as well as the US National Institute of Diabetes and Digestive and Kidney Diseases of the US National Institutes of Health under Award Number K25DK135913. JH was partially supported by the US National Science Foundation (NSF) grant IIS-2145411. WS was partially supported by the Texas Advanced Computing Center (TACC) and the NVIDIA Academic Grant Program. LZ was partially supported by the NSF CAREER DMS-2340241 and AI for Math Fund from Renaissance Philanthropy.

# References

[1] AI@Meta. The llama 4 herd: The beginning of a new era of natively multimodal ai innovation, 2025.   
[2] A. Asai, Z. Wu, Y. Wang, A. Sil, and H. Hajishirzi. Self-RAG: Learning to retrieve, generate, and critique through self-reflection. In ICLR, 2024.   
[3] S. Balakrishnan, M. J. Wainwright, and B. Yu. Statistical guarantees for the em algorithm: From population to sample-based analysis. The Annals of Statistics, 45(1):77, 2017.   
[4] M. Chen, T. Li, H. Sun, Y. Zhou, C. Zhu, F. Yang, Z. Zhou, W. Chen, H. Wang, J. Z. Pan, et al. Learning to reason with search for llms via reinforcement learning. arXiv preprint arXiv:2503.19470, 2025.   
[5] W. Chen, X. Ma, X. Wang, and W. W. Cohen. Program of thoughts prompting: Disentangling computation from reasoning for numerical reasoning tasks. TMLR, 2023.   
[6] Y. Chen, L. Yan, W. Sun, X. Ma, Y. Zhang, S. Wang, D. Yin, Y. Yang, and J. Mao. Improving retrieval-augmented generation through multi-agent reinforcement learning. arXiv preprint arXiv:2501.15228, 2025.   
[7] Z. Chen, W. Chen, C. Smiley, S. Shah, I. Borova, D. Langdon, R. Moussa, M. Beane, T.-H. Huang, B. R. Routledge, et al. Finqa: A dataset of numerical reasoning over financial data. In EMNLP, pages 3697–3711, 2021.   
[8] Z. Chen, Y. Deng, H. Yuan, K. Ji, and Q. Gu. Self-play fine-tuning converts weak language models to strong language models. In ICML, pages 6621–6642, 2024.   
[9] Z. Chen, S. Li, C. Smiley, Z. Ma, S. Shah, and W. Y. Wang. Convfinqa: Exploring the chain of numerical reasoning in conversational finance question answering. In EMNLP, 2022.   
[10] P. Cheng, T. Hu, H. Xu, Z. Zhang, Y. Dai, L. Han, N. Du, and X. Li. Self-playing adversarial language game enhances LLM reasoning. In NeurIPS, 2024.   
[11] K. Cobbe, V. Kosaraju, M. Bavarian, M. Chen, H. Jun, L. Kaiser, M. Plappert, J. Tworek, J. Hilton, R. Nakano, et al. Training verifiers to solve math word problems. arXiv preprint arXiv:2110.14168, 2021.   
[12] P. Dasigi, N. F. Liu, A. Marasovic, N. A. Smith, and M. Gardner. Quoref: A reading compre- ´ hension dataset with questions requiring coreferential reasoning. In EMNLP, 2019.   
[13] G. Dong, K. Lu, C. Li, T. Xia, B. Yu, C. Zhou, and J. Zhou. Self-play with execution feedback: Improving instruction-following capabilities of large language models. In ICLR, 2025.   
[14] H. Dong, W. Xiong, D. Goyal, Y. Zhang, W. Chow, R. Pan, S. Diao, J. Zhang, K. Shum, and T. Zhang. RAFT: Reward ranked finetuning for generative foundation model alignment. Transactions on Machine Learning Research, 2023.   
[15] K. Dong and T. Ma. Beyond limited data: Self-play llm theorem provers with iterative conjecturing and proving. arXiv preprint arXiv:2502.00212, 2025.   
[16] D. Dua, Y. Wang, P. Dasigi, G. Stanovsky, S. Singh, and M. Gardner. Drop: A reading comprehension benchmark requiring discrete reasoning over paragraphs. In NAACL, 2019.   
[17] A. Dubey, A. Jauhri, A. Pandey, A. Kadian, A. Al-Dahle, A. Letman, A. Mathur, A. Schelten, A. Yang, A. Fan, et al. The llama 3 herd of models. arXiv preprint arXiv:2407.21783, 2024.   
[18] Y. Gao, Y. Xiong, Y. Zhong, Y. Bi, M. Xue, and H. Wang. Synergizing rag and reasoning: A systematic review. arXiv preprint arXiv:2504.15909, 2025.   
[19] M. Geva, D. Khashabi, E. Segal, T. Khot, D. Roth, and J. Berant. Did aristotle use a laptop? a question answering benchmark with implicit reasoning strategies. TACL, 9:346–361, 2021.   
[20] D. Guo, D. Yang, H. Zhang, J. Song, R. Zhang, R. Xu, Q. Zhu, S. Ma, P. Wang, X. Bi, et al. Deepseek-r1: Incentivizing reasoning capability in llms via reinforcement learning. arXiv preprint arXiv:2501.12948, 2025.   
[21] X. Ho, A.-K. D. Nguyen, S. Sugawara, and A. Aizawa. Constructing a multi-hop qa dataset for comprehensive evaluation of reasoning steps. In COLING, 2020.   
[22] S. Hsu, O. Khattab, C. Finn, and A. Sharma. Grounding by trying: LLMs with reinforcement learning-enhanced retrieval. In ICLR, 2025.   
[23] E. J. Hu, Y. Shen, P. Wallis, Z. Allen-Zhu, Y. Li, S. Wang, L. Wang, and W. Chen. Lora: Low-rank adaptation of large language models. In ICLR, 2022.   
[24] B. Hui, J. Yang, Z. Cui, J. Yang, D. Liu, L. Zhang, T. Liu, J. Zhang, B. Yu, K. Lu, et al. Qwen2. 5-coder technical report. arXiv preprint arXiv:2409.12186, 2024.   
[25] A. Hurst, A. Lerer, A. P. Goucher, A. Perelman, A. Ramesh, A. Clark, A. Ostrow, A. Welihinda, A. Hayes, A. Radford, et al. Gpt-4o system card. arXiv preprint arXiv:2410.21276, 2024.   
[26] A. Jaech, A. Kalai, A. Lerer, A. Richardson, A. El-Kishky, A. Low, A. Helyar, A. Madry, A. Beutel, A. Carney, et al. Openai o1 system card. arXiv preprint arXiv:2412.16720, 2024.   
[27] J. Jiang, J. Chen, J. Li, R. Ren, S. Wang, W. X. Zhao, Y. Song, and T. Zhang. Rag-star: Enhancing deliberative reasoning with retrieval augmented verification and refinement. arXiv preprint arXiv:2412.12881, 2024.   
[28] Y. Jiang, S. Bordia, Z. Zhong, C. Dognin, M. Singh, and M. Bansal. Hover: A dataset for many-hop fact extraction and claim verification. In Findings of EMNLP, pages 3441–3460, 2020.   
[29] B. Jin, J. Yoon, P. Kargupta, S. O. Arik, and J. Han. An empirical study on reinforcement learning for reasoning-search interleaved llm agents. arXiv preprint arXiv:2505.15117, 2025.   
[30] B. Jin, H. Zeng, Z. Yue, J. Yoon, S. Arik, D. Wang, H. Zamani, and J. Han. Search-r1: Training llms to reason and leverage search engines with reinforcement learning. arXiv preprint arXiv:2503.09516, 2025.   
[31] O. Khattab, K. Santhanam, X. L. Li, D. Hall, P. Liang, C. Potts, and M. Zaharia. Demonstratesearch-predict: Composing retrieval and language models for knowledge-intensive nlp. arXiv preprint arXiv:2212.14024, 2022.   
[32] T. Kocisk ˇ y, J. Schwarz, P. Blunsom, C. Dyer, K. M. Hermann, G. Melis, and E. Grefenstette. \` The narrativeqa reading comprehension challenge. TACL, 2018.   
[33] T. Kwiatkowski, J. Palomaki, O. Redfield, M. Collins, A. Parikh, C. Alberti, D. Epstein, I. Polosukhin, J. Devlin, K. Lee, et al. Natural questions: a benchmark for question answering research. TACL, 2019.   
[34] P. Lewis, E. Perez, A. Piktus, F. Petroni, V. Karpukhin, N. Goyal, H. Küttler, M. Lewis, W.-t. Yih, T. Rocktäschel, et al. Retrieval-augmented generation for knowledge-intensive nlp tasks. NeurIPS, 33, 2020.   
[35] M. Li, F. Feng, H. Zhang, X. He, F. Zhu, and T.-S. Chua. Learning to imagine: Integrating counterfactual thinking in neural discrete reasoning. In ACL, pages 57–69, 2022.   
[36] X. Li, G. Dong, J. Jin, Y. Zhang, Y. Zhou, Y. Zhu, P. Zhang, and Z. Dou. Search-o1: Agentic search-enhanced large reasoning models. arXiv preprint arXiv:2501.05366, 2025.   
[37] X. Li, S. Mei, Z. Liu, Y. Yan, S. Wang, S. Yu, Z. Zeng, H. Chen, G. Yu, Z. Liu, M. Sun, and C. Xiong. RAG-DDR: Optimizing retrieval-augmented generation using differentiable data rewards. In ICLR, 2025.   
[38] K. Lin, O. Tafjord, P. Clark, and M. Gardner. Reasoning over paragraph effects in situations. In Workshop on Machine Reading for Question Answering, 2019.   
[39] X. V. Lin, X. Chen, M. Chen, W. Shi, M. Lomeli, R. James, P. Rodriguez, J. Kahn, G. Szilvasy, M. Lewis, L. Zettlemoyer, and W. tau Yih. RA-DIT: Retrieval-augmented dual instruction tuning. In ICLR, 2024.   
[40] A. Liu, B. Feng, B. Wang, B. Wang, B. Liu, C. Zhao, C. Dengr, C. Ruan, D. Dai, D. Guo, et al. Deepseek-v2: A strong, economical, and efficient mixture-of-experts language model. arXiv preprint arXiv:2405.04434, 2024.   
[41] A. Liu, B. Feng, B. Xue, B. Wang, B. Wu, C. Lu, C. Zhao, C. Deng, C. Zhang, C. Ruan, et al. Deepseek-v3 technical report. arXiv preprint arXiv:2412.19437, 2024.   
[42] T. Liu, H. Jiang, T. Wang, R. Xu, Y. Yu, L. Zhang, T. Zhao, and H. Wang. Roserag: Robust retrieval-augmented generation with small-scale llms via margin-aware preference optimization. arXiv preprint arXiv:2502.10993, 2025.   
[43] Z. Liu, Y. Chen, M. Shoeybi, B. Catanzaro, and W. Ping. Acemath: Advancing frontier math reasoning with post-training and reward modeling. arXiv preprint arXiv:2412.15084, 2024.   
[44] Z. Liu, X. Guo, F. Lou, L. Zeng, J. Niu, Z. Wang, J. Xu, W. Cai, Z. Yang, X. Zhao, et al. Fin-r1: A large language model for financial reasoning through reinforcement learning. arXiv preprint arXiv:2503.16252, 2025.   
[45] Z. Liu, W. Ping, R. Roy, P. Xu, C. Lee, M. Shoeybi, and B. Catanzaro. Chatqa: Surpassing gpt-4 on conversational qa and rag. In NeurIPS, pages 15416–15459, 2024.   
[46] P. Lu, L. Qiu, K.-W. Chang, Y. N. Wu, S.-C. Zhu, T. Rajpurohit, P. Clark, and A. Kalyan. Dynamic prompt learning via policy gradient for semi-structured mathematical reasoning. In ICLR, 2023.   
[47] H. Ma, W. Xu, Y. Wei, L. Chen, L. Wang, Q. Liu, and S. Wu. Ex-fever: A dataset for multi-hop explainable fact verification. In Findings of ACL, pages 9340–9353, 2024.   
[48] A. Mallen, A. Asai, V. Zhong, R. Das, D. Khashabi, and H. Hajishirzi. When not to trust language models: Investigating effectiveness of parametric and non-parametric memories. In ACL, 2023.   
[49] Y. Meng, M. Xia, and D. Chen. SimPO: Simple preference optimization with a reference-free reward. In NeurIPS, 2024.   
[50] N. Muennighoff, H. Su, L. Wang, N. Yang, F. Wei, T. Yu, A. Singh, and D. Kiela. Generative representational instruction tuning. In ICLR, 2025.   
[51] OpenAI. Introducing gpt-4.1 in the api, 2025.   
[52] L. Ouyang, J. Wu, X. Jiang, D. Almeida, C. Wainwright, P. Mishkin, C. Zhang, S. Agarwal, K. Slama, A. Ray, et al. Training language models to follow instructions with human feedback. NeurIPS, 35, 2022.   
[53] O. Press, M. Zhang, S. Min, L. Schmidt, N. A. Smith, and M. Lewis. Measuring and narrowing the compositionality gap in language models. In Findings of EMNLP, pages 5687–5711, 2023.   
[54] L. Qian, W. Zhou, Y. Wang, X. Peng, H. Yi, J. Huang, Q. Xie, and J. Nie. Fino1: On the transferability of reasoning enhanced llms to finance. arXiv preprint arXiv:2502.08127, 2025.   
[55] R. Rafailov, A. Sharma, E. Mitchell, C. D. Manning, S. Ermon, and C. Finn. Direct preference optimization: Your language model is secretly a reward model. In NeurIPS, 2023.   
[56] P. Rajpurkar, J. Zhang, K. Lopyrev, and P. Liang. Squad: $^ { 1 0 0 , 0 0 0 + }$ questions for machine comprehension of text. In EMNLP, 2016.   
[57] Z. Shao, Y. Gong, Y. Shen, M. Huang, N. Duan, and W. Chen. Enhancing retrieval-augmented large language models with iterative retrieval-generation synergy. In Findings of EMNLP, 2023.   
[58] W. Shi, S. Min, M. Yasunaga, M. Seo, R. James, M. Lewis, L. Zettlemoyer, and W.-t. Yih. REPLUG: Retrieval-augmented black-box language models. In NAACL, 2024.   
[59] W. Shi, R. Xu, Y. Zhuang, Y. Yu, J. Zhang, H. Wu, Y. Zhu, J. Ho, C. Yang, and M. D. Wang. Ehragent: Code empowers large language models for few-shot complex tabular reasoning on electronic health records. In EMNLP, pages 22315–22339, 2024.   
[60] D. Silver, A. Huang, C. J. Maddison, A. Guez, L. Sifre, G. Van Den Driessche, J. Schrittwieser, I. Antonoglou, V. Panneershelvam, M. Lanctot, et al. Mastering the game of go with deep neural networks and tree search. nature, 529(7587):484–489, 2016.   
[61] A. Singh, J. D. Co-Reyes, R. Agarwal, A. Anand, P. Patil, X. Garcia, P. J. Liu, J. Harrison, J. Lee, K. Xu, A. T. Parisi, A. Kumar, et al. Beyond human data: Scaling self-training for problem-solving with language models. TMLR, 2024.   
[62] H. Song, J. Jiang, Y. Min, J. Chen, Z. Chen, W. X. Zhao, L. Fang, and J.-R. Wen. R1- searcher: Incentivizing the search capability in llms via reinforcement learning. arXiv preprint arXiv:2503.05592, 2025.   
[63] H. Sun, Z. Qiao, J. Guo, X. Fan, Y. Hou, Y. Jiang, P. Xie, F. Huang, and Y. Zhang. Zerosearch: Incentivize the search capability of llms without searching. arXiv preprint arXiv:2505.04588, 2025.   
[64] Z. Sun, Q. Wang, W. Yu, X. Zang, K. Zheng, J. Xu, X. Zhang, S. Yang, and H. Li. Rearter: Retrieval-augmented reasoning with trustworthy process rewarding. arXiv preprint arXiv:2501.07861, 2025.   
[65] G. Team, P. Georgiev, V. I. Lei, R. Burnell, L. Bai, A. Gulati, G. Tanzer, D. Vincent, Z. Pan, S. Wang, et al. Gemini 1.5: Unlocking multimodal understanding across millions of tokens of context. arXiv preprint arXiv:2403.05530, 2024.   
[66] J. Thorne, A. Vlachos, C. Christodoulopoulos, and A. Mittal. Fever: A large-scale dataset for fact extraction and verification. In NAACL, 2018.   
[67] H. Trivedi, N. Balasubramanian, T. Khot, and A. Sabharwal. Musique: Multihop questions via single-hop question composition. TACL, 10:539–554, 2022.   
[68] H. Trivedi, N. Balasubramanian, T. Khot, and A. Sabharwal. Interleaving retrieval with chainof-thought reasoning for knowledge-intensive multi-step questions. In ACL, 2023.   
[69] A. W. Van der Vaart. Asymptotic statistics, volume 3. Cambridge university press, 2000.   
[70] P. Verma, S. P. Midigeshi, G. Sinha, A. Solin, N. Natarajan, and A. Sharma. Plan-RAG: Planning-guided retrieval augmented generation, 2025.   
[71] H. Wang, R. Li, H. Jiang, J. Tian, Z. Wang, C. Luo, X. Tang, M. Cheng, T. Zhao, and J. Gao. Blendfilter: Advancing retrieval-augmented large language models via query generation blending and knowledge filtering. In EMNLP, pages 1009–1025, 2024.   
[72] L. Wang, H. Chen, N. Yang, X. Huang, Z. Dou, and F. Wei. Chain-of-retrieval augmented generation. arXiv preprint arXiv:2501.14342, 2025.   
[73] L. Wang, N. Yang, X. Huang, B. Jiao, L. Yang, D. Jiang, R. Majumder, and F. Wei. Text embeddings by weakly-supervised contrastive pre-training. arXiv preprint arXiv:2212.03533, 2022.   
[74] J. Wei, X. Wang, D. Schuurmans, M. Bosma, F. Xia, E. Chi, Q. V. Le, D. Zhou, et al. Chain-ofthought prompting elicits reasoning in large language models. NeurIPS, 2022.   
[75] Z. Wei, W.-L. Chen, and Y. Meng. InstructRAG: Instructing retrieval-augmented generation via self-synthesized rationales. In ICLR, 2025.   
[76] Y. Wu, Z. Sun, H. Yuan, K. Ji, Y. Yang, and Q. Gu. Self-play preference optimization for language model alignment. In ICLR, 2025.   
[77] G. Xiong, Q. Jin, X. Wang, Y. Fang, H. Liu, Y. Yang, F. Chen, Z. Song, D. Wang, M. Zhang, et al. Rag-gym: Optimizing reasoning and search agents with process supervision. arXiv preprint arXiv:2502.13957, 2025.   
[78] R. Xu, H. Liu, S. Nag, Z. Dai, Y. Xie, X. Tang, C. Luo, Y. Li, J. C. Ho, C. Yang, and Q. He. SimRAG: Self-improving retrieval-augmented generation for adapting large language models to specialized domains. In NAACL, pages 11534–11550, 2025.   
[79] R. Xu, W. Shi, Y. Zhuang, Y. Yu, J. C. Ho, H. Wang, and C. Yang. Collab-rag: Boosting retrieval-augmented generation for complex question answering via white-box and black-box llm collaboration. arXiv preprint arXiv:2504.04915, 2025.   
[80] A. Yang, A. Li, B. Yang, B. Zhang, B. Hui, B. Zheng, B. Yu, C. Gao, C. Huang, C. Lv, et al. Qwen3 technical report. arXiv preprint arXiv:2505.09388, 2025.   
[81] A. Yang, B. Yang, B. Zhang, B. Hui, B. Zheng, B. Yu, C. Li, D. Liu, F. Huang, H. Wei, et al. Qwen2. 5 technical report. arXiv preprint arXiv:2412.15115, 2024.   
[82] A. Yang, B. Zhang, B. Hui, B. Gao, B. Yu, C. Li, D. Liu, J. Tu, J. Zhou, J. Lin, et al. Qwen2. 5-math technical report: Toward mathematical expert model via self-improvement. arXiv preprint arXiv:2409.12122, 2024.   
[83] Z. Yang, P. Qi, S. Zhang, Y. Bengio, W. W. Cohen, R. Salakhutdinov, and C. D. Manning. HotpotQA: A dataset for diverse, explainable multi-hop question answering. In EMNLP, 2018.   
[84] Z. Ye, R. Agarwal, T. Liu, R. Joshi, S. Velury, Q. V. Le, Q. Tan, and Y. Liu. Evolving alignment via asymmetric self-play. arXiv preprint arXiv:2411.00062, 2024.   
[85] W. Yu, M. Jiang, P. Clark, and A. Sabharwal. Ifqa: A dataset for open-domain question answering under counterfactual presuppositions. In EMNLP, pages 8276–8288, 2023.   
[86] Y. Yu, W. Ping, Z. Liu, B. Wang, J. You, C. Zhang, M. Shoeybi, and B. Catanzaro. Rankrag: Unifying context ranking with retrieval-augmented generation in llms. In NeurIPS, pages 121156–121184, 2024.   
[87] X. Yue, X. Qu, G. Zhang, Y. Fu, W. Huang, H. Sun, Y. Su, and W. Chen. MAmmoTH: Building math generalist models through hybrid instruction tuning. In ICLR, 2024.   
[88] Z. Yue, H. Zhuang, A. Bai, K. Hui, R. Jagerman, H. Zeng, Z. Qin, D. Wang, X. Wang, and M. Bendersky. Inference scaling for long-context retrieval augmented generation. In ICLR, 2025.   
[89] A. Zhao, Y. Wu, Y. Yue, T. Wu, Q. Xu, M. Lin, S. Wang, Q. Wu, Z. Zheng, and G. Huang. Absolute zero: Reinforced self-play reasoning with zero data. arXiv preprint arXiv:2505.03335, 2025.   
[90] Y. Zhao, Y. Li, C. Li, and R. Zhang. Multihiertt: Numerical reasoning over multi hierarchical tabular and textual data. In ACL, pages 6588–6600, 2022.   
[91] Y. Zhao, Y. Long, H. Liu, R. Kamoi, L. Nan, L. Chen, Y. Liu, X. Tang, R. Zhang, and A. Cohan. Docmath-eval: Evaluating math reasoning capabilities of llms in understanding long and specialized documents. In ACL, pages 16103–16120, 2024.   
[92] Y. Zheng, D. Fu, X. Hu, X. Cai, L. Ye, P. Lu, and P. Liu. Deepresearcher: Scaling deep research via reinforcement learning in real-world environments. arXiv preprint arXiv:2504.03160, 2025.   
[93] D. Zhou, N. Schärli, L. Hou, J. Wei, N. Scales, X. Wang, D. Schuurmans, C. Cui, O. Bousquet, Q. V. Le, and E. H. Chi. Least-to-most prompting enables complex reasoning in large language models. In ICLR, 2023.   
[94] F. Zhu, W. Lei, Y. Huang, C. Wang, S. Zhang, J. Lv, F. Feng, and T.-S. Chua. Tat-qa: A question answering benchmark on a hybrid of tabular and textual content in finance. In ACL, 2021.   
[95] J. Zhu, Q. Chen, H. Dou, J. Li, L. Guo, F. Chen, and C. Zhang. Dianjin-r1: Evaluating and enhancing financial reasoning in large language models. arXiv preprint arXiv:2504.15716, 2025.   
[96] Q. Zhu, D. Guo, Z. Shao, D. Yang, P. Wang, R. Xu, Y. Wu, Y. Li, H. Gao, S. Ma, et al. Deepseek-coder-v2: Breaking the barrier of closed-source models in code intelligence. arXiv preprint arXiv:2406.11931, 2024.

# NeurIPS Paper Checklist

The checklist is designed to encourage best practices for responsible machine learning research, addressing issues of reproducibility, transparency, research ethics, and societal impact. Do not remove the checklist: The papers not including the checklist will be desk rejected. The checklist should follow the references and follow the (optional) supplemental material. The checklist does NOT count towards the page limit.

Please read the checklist guidelines carefully for information on how to answer these questions. For each question in the checklist:

• You should answer [Yes] , [No] , or [NA] .   
• [NA] means either that the question is Not Applicable for that particular paper or the relevant information is Not Available.   
• Please provide a short (1–2 sentence) justification right after your answer (even for NA).

The checklist answers are an integral part of your paper submission. They are visible to the reviewers, area chairs, senior area chairs, and ethics reviewers. You will be asked to also include it (after eventual revisions) with the final version of your paper, and its final version will be published with the paper.

The reviewers of your paper will be asked to use the checklist as one of the factors in their evaluation. While "[Yes] " is generally preferable to "[No] ", it is perfectly acceptable to answer "[No] " provided a proper justification is given (e.g., "error bars are not reported because it would be too computationally expensive" or "we were unable to find the license for the dataset we used"). In general, answering "[No] " or "[NA] " is not grounds for rejection. While the questions are phrased in a binary way, we acknowledge that the true answer is often more nuanced, so please just use your best judgment and write a justification to elaborate. All supporting evidence can appear either in the main paper or the supplemental material, provided in appendix. If you answer [Yes] to a question, in the justification please point to the section(s) where related material for the question can be found.

IMPORTANT, please:

• Delete this instruction block, but keep the section heading “NeurIPS paper checklist", • Keep the checklist subsection headings, questions/answers and guidelines below. • Do not modify the questions and only use the provided macros for your answers.

# 1. Claims

Question: Do the main claims made in the abstract and introduction accurately reflect the paper’s contributions and scope?

Answer: [Yes]

Justification: The claim made in the abstract is supported by the experiments in Section 5.

Guidelines:

• The answer NA means that the abstract and introduction do not include the claims made in the paper.   
• The abstract and/or introduction should clearly state the claims made, including the contributions made in the paper and important assumptions and limitations. A No or NA answer to this question will not be perceived well by the reviewers.   
• The claims made should match theoretical and experimental results, and reflect how much the results can be expected to generalize to other settings.   
• It is fine to include aspirational goals as motivation as long as it is clear that these goals are not attained by the paper.

# 2. Limitations

Question: Does the paper discuss the limitations of the work performed by the authors?

Answer: [Yes]

Justification: We discuss the limitation in Appendix A.

# Guidelines:

• The answer NA means that the paper has no limitation while the answer No means that the paper has limitations, but those are not discussed in the paper.   
• The authors are encouraged to create a separate "Limitations" section in their paper.   
• The paper should point out any strong assumptions and how robust the results are to violations of these assumptions (e.g., independence assumptions, noiseless settings, model well-specification, asymptotic approximations only holding locally). The authors should reflect on how these assumptions might be violated in practice and what the implications would be.   
• The authors should reflect on the scope of the claims made, e.g., if the approach was only tested on a few datasets or with a few runs. In general, empirical results often depend on implicit assumptions, which should be articulated.   
The authors should reflect on the factors that influence the performance of the approach. For example, a facial recognition algorithm may perform poorly when image resolution is low or images are taken in low lighting. Or a speech-to-text system might not be used reliably to provide closed captions for online lectures because it fails to handle technical jargon.   
• The authors should discuss the computational efficiency of the proposed algorithms and how they scale with dataset size.   
• If applicable, the authors should discuss possible limitations of their approach to address problems of privacy and fairness.   
• While the authors might fear that complete honesty about limitations might be used by reviewers as grounds for rejection, a worse outcome might be that reviewers discover limitations that aren’t acknowledged in the paper. The authors should use their best judgment and recognize that individual actions in favor of transparency play an important role in developing norms that preserve the integrity of the community. Reviewers will be specifically instructed to not penalize honesty concerning limitations.

# 3. Theory Assumptions and Proofs

Question: For each theoretical result, does the paper provide the full set of assumptions and a complete (and correct) proof?

Answer: [Yes]

Justification: The proof are shown in Appendix B and C.

Guidelines:

• The answer NA means that the paper does not include theoretical results.   
• All the theorems, formulas, and proofs in the paper should be numbered and crossreferenced.   
• All assumptions should be clearly stated or referenced in the statement of any theorems.   
• The proofs can either appear in the main paper or the supplemental material, but if they appear in the supplemental material, the authors are encouraged to provide a short proof sketch to provide intuition.   
• Inversely, any informal proof provided in the core of the paper should be complemented by formal proofs provided in appendix or supplemental material.   
• Theorems and Lemmas that the proof relies upon should be properly referenced.

# 4. Experimental Result Reproducibility

Question: Does the paper fully disclose all the information needed to reproduce the main experimental results of the paper to the extent that it affects the main claims and/or conclusions of the paper (regardless of whether the code and data are provided or not)?

Answer: [Yes]

Justification: We provide all the details of the data collection for training and evaluations in Section 5, Appendix E - G.

Guidelines:

• The answer NA means that the paper does not include experiments.

• If the paper includes experiments, a No answer to this question will not be perceived well by the reviewers: Making the paper reproducible is important, regardless of whether the code and data are provided or not.   
• If the contribution is a dataset and/or model, the authors should describe the steps taken to make their results reproducible or verifiable.   
Depending on the contribution, reproducibility can be accomplished in various ways. For example, if the contribution is a novel architecture, describing the architecture fully might suffice, or if the contribution is a specific model and empirical evaluation, it may be necessary to either make it possible for others to replicate the model with the same dataset, or provide access to the model. In general. releasing code and data is often one good way to accomplish this, but reproducibility can also be provided via detailed instructions for how to replicate the results, access to a hosted model (e.g., in the case of a large language model), releasing of a model checkpoint, or other means that are appropriate to the research performed.   
• While NeurIPS does not require releasing code, the conference does require all submissions to provide some reasonable avenue for reproducibility, which may depend on the nature of the contribution. For example (a) If the contribution is primarily a new algorithm, the paper should make it clear how to reproduce that algorithm. (b) If the contribution is primarily a new model architecture, the paper should describe the architecture clearly and fully. (c) If the contribution is a new model (e.g., a large language model), then there should either be a way to access this model for reproducing the results or a way to reproduce the model (e.g., with an open-source dataset or instructions for how to construct the dataset). (d) We recognize that reproducibility may be tricky in some cases, in which case authors are welcome to describe the particular way they provide for reproducibility. In the case of closed-source models, it may be that access to the model is limited in some way (e.g., to registered users), but it should be possible for other researchers to have some path to reproducing or verifying the results.

# 5. Open access to data and code

Question: Does the paper provide open access to the data and code, with sufficient instructions to faithfully reproduce the main experimental results, as described in supplemental material?

Answer: [Yes]

Justification: For training data, they are all public available data with open access in https: //huggingface.co/AceSearcher/datasets. We open-source code for reproducing our results in https://github.com/ritaranx/AceSearcher.

Guidelines:

• The answer NA means that paper does not include experiments requiring code.   
• Please see the NeurIPS code and data submission guidelines (https://nips.cc/ public/guides/CodeSubmissionPolicy) for more details.   
• While we encourage the release of code and data, we understand that this might not be possible, so “No” is an acceptable answer. Papers cannot be rejected simply for not including code, unless this is central to the contribution (e.g., for a new open-source benchmark).   
• The instructions should contain the exact command and environment needed to run to reproduce the results. See the NeurIPS code and data submission guidelines (https: //nips.cc/public/guides/CodeSubmissionPolicy) for more details.   
• The authors should provide instructions on data access and preparation, including how to access the raw data, preprocessed data, intermediate data, and generated data, etc.   
• The authors should provide scripts to reproduce all experimental results for the new proposed method and baselines. If only a subset of experiments are reproducible, they should state which ones are omitted from the script and why.   
• At submission time, to preserve anonymity, the authors should release anonymized versions (if applicable).

• Providing as much information as possible in supplemental material (appended to the paper) is recommended, but including URLs to data and code is permitted.

# 6. Experimental Setting/Details

Question: Does the paper specify all the training and test details (e.g., data splits, hyperparameters, how they were chosen, type of optimizer, etc.) necessary to understand the results?

Answer: [Yes]

Justification: Experimental details can be found in section 5 and Appendix G.

Guidelines:

• The answer NA means that the paper does not include experiments. • The experimental setting should be presented in the core of the paper to a level of detail that is necessary to appreciate the results and make sense of them. • The full details can be provided either with the code, in appendix, or as supplemental material.

# 7. Experiment Statistical Significance

Question: Does the paper report error bars suitably and correctly defined or other appropriate information about the statistical significance of the experiments?

Answer: [No]

Justification: We conduct evaluation in a zero-shot manner using greedy sampling, all results of AceSearcher are deterministic.

Guidelines:

• The answer NA means that the paper does not include experiments.   
• The authors should answer "Yes" if the results are accompanied by error bars, confidence intervals, or statistical significance tests, at least for the experiments that support the main claims of the paper. The factors of variability that the error bars are capturing should be clearly stated (for example, train/test split, initialization, random drawing of some parameter, or overall run with given experimental conditions).   
• The method for calculating the error bars should be explained (closed form formula, call to a library function, bootstrap, etc.)   
• The assumptions made should be given (e.g., Normally distributed errors).   
• It should be clear whether the error bar is the standard deviation or the standard error of the mean.   
• It is OK to report 1-sigma error bars, but one should state it. The authors should preferably report a 2-sigma error bar than state that they have a $96 \%$ CI, if the hypothesis of Normality of errors is not verified.   
• For asymmetric distributions, the authors should be careful not to show in tables or figures symmetric error bars that would yield results that are out of range (e.g. negative error rates).   
• If error bars are reported in tables or plots, The authors should explain in the text how they were calculated and reference the corresponding figures or tables in the text.

# 8. Experiments Compute Resources

Question: For each experiment, does the paper provide sufficient information on the computer resources (type of compute workers, memory, time of execution) needed to reproduce the experiments?

Answer: [Yes]

Justification: We provide such information in Appendix G.

Guidelines:

• The answer NA means that the paper does not include experiments. • The paper should indicate the type of compute workers CPU or GPU, internal cluster, or cloud provider, including relevant memory and storage.

• The paper should provide the amount of compute required for each of the individual experimental runs as well as estimate the total compute.   
• The paper should disclose whether the full research project required more compute than the experiments reported in the paper (e.g., preliminary or failed experiments that didn’t make it into the paper).

# 9. Code Of Ethics

Question: Does the research conducted in the paper conform, in every respect, with the NeurIPS Code of Ethics https://neurips.cc/public/EthicsGuidelines?

Answer: [Yes]

Justification: The work conducted in this paper conforms with the NeurIPS Code of Ethics.

Guidelines:

• The answer NA means that the authors have not reviewed the NeurIPS Code of Ethics.   
• If the authors answer No, they should explain the special circumstances that require a deviation from the Code of Ethics.   
• The authors should make sure to preserve anonymity (e.g., if there is a special consideration due to laws or regulations in their jurisdiction).

# 10. Broader Impacts

Question: Does the paper discuss both potential positive societal impacts and negative societal impacts of the work performed?

Answer: [Yes]

Justification: We discuss both potential societal impacts and negative impacts in Appendix A.

Guidelines:

• The answer NA means that there is no societal impact of the work performed.   
• If the authors answer NA or No, they should explain why their work has no societal impact or why the paper does not address societal impact.   
Examples of negative societal impacts include potential malicious or unintended uses (e.g., disinformation, generating fake profiles, surveillance), fairness considerations (e.g., deployment of technologies that could make decisions that unfairly impact specific groups), privacy considerations, and security considerations.   
• The conference expects that many papers will be foundational research and not tied to particular applications, let alone deployments. However, if there is a direct path to any negative applications, the authors should point it out. For example, it is legitimate to point out that an improvement in the quality of generative models could be used to generate deepfakes for disinformation. On the other hand, it is not needed to point out that a generic algorithm for optimizing neural networks could enable people to train models that generate Deepfakes faster.   
The authors should consider possible harms that could arise when the technology is being used as intended and functioning correctly, harms that could arise when the technology is being used as intended but gives incorrect results, and harms following from (intentional or unintentional) misuse of the technology.   
If there are negative societal impacts, the authors could also discuss possible mitigation strategies (e.g., gated release of models, providing defenses in addition to attacks, mechanisms for monitoring misuse, mechanisms to monitor how a system learns from feedback over time, improving the efficiency and accessibility of ML).

# 11. Safeguards

Question: Does the paper describe safeguards that have been put in place for responsible release of data or models that have a high risk for misuse (e.g., pretrained language models, image generators, or scraped datasets)?

Answer: [NA]

Justification: The paper poses no such risks.

Guidelines:

• The answer NA means that the paper poses no such risks.   
• Released models that have a high risk for misuse or dual-use should be released with necessary safeguards to allow for controlled use of the model, for example by requiring that users adhere to usage guidelines or restrictions to access the model or implementing safety filters.   
• Datasets that have been scraped from the Internet could pose safety risks. The authors should describe how they avoided releasing unsafe images.   
• We recognize that providing effective safeguards is challenging, and many papers do not require this, but we encourage authors to take this into account and make a best faith effort.

# 12. Licenses for existing assets

Question: Are the creators or original owners of assets (e.g., code, data, models), used in the paper, properly credited and are the license and terms of use explicitly mentioned and properly respected?

Answer: [Yes]

Justification: We provide citations to all datasets and models used in the paper.

Guidelines:

• The answer NA means that the paper does not use existing assets.   
• The authors should cite the original paper that produced the code package or dataset.   
• The authors should state which version of the asset is used and, if possible, include a URL.   
• The name of the license (e.g., CC-BY 4.0) should be included for each asset.   
• For scraped data from a particular source (e.g., website), the copyright and terms of service of that source should be provided.   
• If assets are released, the license, copyright information, and terms of use in the package should be provided. For popular datasets, paperswithcode.com/datasets has curated licenses for some datasets. Their licensing guide can help determine the license of a dataset.   
• For existing datasets that are re-packaged, both the original license and the license of the derived asset (if it has changed) should be provided.   
• If this information is not available online, the authors are encouraged to reach out to the asset’s creators.

# 13. New Assets

Question: Are new assets introduced in the paper well documented and is the documentation provided alongside the assets?

Answer: [NA]

Justification: The paper does not release new datasets.

Guidelines:

• The answer NA means that the paper does not release new assets.   
• Researchers should communicate the details of the dataset/code/model as part of their submissions via structured templates. This includes details about training, license, limitations, etc.   
• The paper should discuss whether and how consent was obtained from people whose asset is used.   
• At submission time, remember to anonymize your assets (if applicable). You can either create an anonymized URL or include an anonymized zip file.

# 14. Crowdsourcing and Research with Human Subjects

Question: For crowdsourcing experiments and research with human subjects, does the paper include the full text of instructions given to participants and screenshots, if applicable, as well as details about compensation (if any)?

Answer: [Yes]

Justification: We provide details in Appendix I.

Guidelines:

• The answer NA means that the paper does not involve crowdsourcing nor research with human subjects.   
• Including this information in the supplemental material is fine, but if the main contribution of the paper involves human subjects, then as much detail as possible should be included in the main paper.   
• According to the NeurIPS Code of Ethics, workers involved in data collection, curation, or other labor should be paid at least the minimum wage in the country of the data collector.

# 15. Institutional Review Board (IRB) Approvals or Equivalent for Research with Human Subjects

Question: Does the paper describe potential risks incurred by study participants, whether such risks were disclosed to the subjects, and whether Institutional Review Board (IRB) approvals (or an equivalent approval/review based on the requirements of your country or institution) were obtained?

Answer: [Yes]

Justification: Our human study has obtained IRB approval and we mentioned this in Appendix I.

Guidelines:

• The answer NA means that the paper does not involve crowdsourcing nor research with human subjects.   
• Depending on the country in which research is conducted, IRB approval (or equivalent) may be required for any human subjects research. If you obtained IRB approval, you should clearly state this in the paper.   
• We recognize that the procedures for this may vary significantly between institutions and locations, and we expect authors to adhere to the NeurIPS Code of Ethics and the guidelines for their institution.   
• For initial submissions, do not include any information that would break anonymity (if applicable), such as the institution conducting the review.

# 16. Declaration of LLM usage

Question: Does the paper describe the usage of LLMs if it is an important, original, or non-standard component of the core methods in this research? Note that if the LLM is used only for writing, editing, or formatting purposes and does not impact the core methodology, scientific rigorousness, or originality of the research, declaration is not required.

Answer: [Yes]

Justification: We describe our experimental setup in Section 5.1.

Guidelines:

• The answer NA means that the core method development in this research does not involve LLMs as any important, original, or non-standard components. • Please refer to our LLM policy (https://neurips.cc/Conferences/2025/LLM) for what should or should not be described.

# A Limitations and Impact Statement

Limitations. While AceSearcher demonstrates strong empirical performance across a wide range of RAG and document-level reasoning benchmarks, several limitations remain. First, our framework is evaluated primarily on complex QA, fact verification, and document-level reasoning tasks; its applicability to other tasks such as open-ended generation, dialogue, or use of real-time tools remains to be explored, though our scope is comparable (or even broader) compared to concurrent works [62, 30, 92]. Second, AceSearcher relies on a fixed retriever during training and inference. Joint optimization of retrieval and reasoning could offer further gains but is left for future work. Third, our decomposition-based pipeline introduces inference overhead, which may limit applicability in latency-sensitive settings. Nonetheless, as shown in Figure 3(c), AceSearcher achieves favorable tradeoffs, and many strong baselines [70, 36, 72] also adopt multi-turn retrieval. Finally, due to resource constraints, we adopt iterative preference optimization (Online DPO) as a practical and efficient alternative to fully online reinforcement learning. While this approach achieves strong results in our setting, exploring more expressive RL formulations may offer further improvements.

Impact Statement. This work advances the development of search-augmented LLMs capable of complex reasoning. By enabling smaller open-source LLMs to search and reason more effectively, AceSearcher reduces reliance on proprietary or extremely large models, which may have high computational or financial barriers. This can promote democratization of advanced AI capabilities in low-resource or domain-specific applications, such as finance, scientific discovery, and healthcare.

# B Derivation Step for Optimal Policy $\pi ^ { * }$ and $\rho ^ { * }$

We aim to maximize the following objective:

$$
\begin{array} { r } { \mathcal { I } _ { \theta } = \mathbb { E } _ { q } \Big [ \mathbb { E } _ { z \sim \rho _ { \theta } ( \cdot | q ) , \ a \sim \pi _ { \theta } ( \cdot | q , z ) } [ r ( q , a ^ { \prime } , a ) ] - \beta \mathcal { D } _ { \mathrm { K L } } \left( \rho _ { \theta } \| \rho _ { \mathrm { r e f } } \right) - \beta \mathbb { E } _ { z \sim \rho _ { \theta } ( \cdot | q ) } \left[ \mathcal { D } _ { \mathrm { K L } } \left( \pi _ { \theta } \| \pi _ { \mathrm { r e f } } \right) \right] \Big ] . } \end{array}
$$

Since $\rho$ and $\pi$ appear in separate terms, we can optimize them independently.

1. Optimal $\pi$ for each $z$ . For fixed $z$ , consider the Lagrangian

$$
\begin{array} { r l } & { \mathcal { L } _ { z } ( \pi , \lambda _ { z } ) = \displaystyle \sum _ { w , a ^ { \prime } } \pi ( w , a ^ { \prime } | q , z ) r ( q , a ^ { \prime } , a ) - \beta \displaystyle \sum _ { w , a ^ { \prime } } \pi ( w , a ^ { \prime } | q , z ) \ln \frac { \pi ( w , a ^ { \prime } | q , z ) } { \pi _ { \mathrm { r e f } } ( w , a ^ { \prime } | q , z ) } } \\ & { \qquad + \lambda _ { z } \Big ( \displaystyle \sum _ { w , a ^ { \prime } } \pi ( w , a ^ { \prime } | q , z ) - 1 \Big ) . } \end{array}
$$

Taking the functional derivative with respect to $\pi ( w , a ^ { \prime } | q , z )$ and setting to zero gives

$$
r ( q , a ^ { \prime } , a ) - \beta \Bigl ( \ln \pi ( w , a ^ { \prime } \mid q , z ) - \ln \pi _ { \mathrm { r e f } } ( w , a ^ { \prime } \mid q , z ) + 1 \Bigr ) + \lambda _ { z } = 0 .
$$

Rearranging yields

$$
\ln \pi ( w , a ^ { \prime } | q , z ) = \ln \pi _ { \mathrm { r e f } } ( w , a ^ { \prime } | q , z ) + \frac { 1 } { \beta } r ( q , a ^ { \prime } , a ) + \underbrace { \left( \frac { \lambda _ { z } } { \beta } - 1 \right) } _ { \mathrm { c o n s t a n t i n } w , a ^ { \prime } } .
$$

Hence, the optimal policy is:

$$
\pi ^ { * } ( w , a \mid q , z ) = { \frac { 1 } { Z _ { \pi } ( q , z ) } } \pi _ { \mathrm { r e f } } ( w , a \mid q , z ) \exp \left( { \frac { 1 } { \beta } } r ( q , a ^ { \prime } , a ) \right)
$$

where

$$
Z _ { \pi } ( q , z ) = \sum _ { w , a } \pi _ { \mathrm { r e f } } ( w , a \mid q , z ) \exp \left( { \frac { 1 } { \beta } } r ( q , a ^ { \prime } , a ) \right)
$$

Now compute $G \left( \pi ^ { * } \right)$

$$
\log \frac { \pi ^ { * } ( w , a \mid q , z ) } { \pi _ { \mathrm { r e f } } ( w , a \mid q , z ) } = \frac { 1 } { \beta } r ( q , a ^ { \prime } , a ) - \log Z _ { \pi } ( q , z )
$$

$$
r ( q , a ) - \beta \log \frac { \pi ^ { * } ( a \mid q , z ) } { \pi _ { \mathrm { r e f } } ( a \mid q , z ) } = \beta \log Z _ { \pi } ( q , z )
$$

Therefore,

$$
G \left( \pi ^ { * } \right) = \mathbb { E } _ { w , a \sim \pi ^ { * } } \left[ \beta \log Z _ { \pi } ( q , z ) \right] = \beta \log Z _ { \pi } ( q , z )
$$

2. Optimal $\rho$ . Substitute $\pi ^ { * }$ back into $\mathcal { I } _ { q }$ . Denote

$$
F [ \rho ] = \mathbb { E } _ { z \sim \rho } \left[ \beta \log Z _ { \pi } ( q , z ) - \beta \log \frac { \rho ( z \mid q ) } { \rho _ { \mathrm { r e f } } ( z \mid q ) } \right] = \beta \mathbb { E } _ { z \sim \rho } \left[ \log \frac { \rho _ { \mathrm { r e f } } ( z \mid q ) Z _ { \pi } ( q , z ) } { \rho ( z \mid q ) } \right]
$$

together with the constraint $\textstyle \sum _ { z } \rho ( z | q ) = 1$ . Introduce multiplier $\mu$ and form

$$
\mathcal { L } [ \rho , \mu ] = \sum _ { z } \rho ( z \mid q ) \beta \log Z _ { \pi } ( q , z ) - \beta \sum _ { z } \rho ( z \mid q ) \ln \frac { \rho ( z \mid q ) } { \rho _ { \mathrm { r e f } } ( z \mid q ) } + \mu \left( \sum _ { z } \rho ( z \mid q ) - 1 \right) .
$$

Taking

$$
{ \frac { \partial { \mathcal { L } } } { \partial \rho ( z \mid q ) } } = \beta \log Z _ { \pi } ( q , z ) - \beta \left( \ln \rho ( z \mid q ) - \ln \rho _ { \mathrm { r e f } } ( z \mid q ) + 1 \right) + \mu = 0 .
$$

Rearranging:

$$
\ln \rho ( z \mid q ) = \ln \rho _ { \mathrm { r e f } } ( z \mid q ) + \log Z _ { \pi } ( q , z ) + \left( { \frac { \mu } { \beta } } - 1 \right) .
$$

The optimal policy is:

$$
\rho ^ { * } ( z \mid q ) = \frac { 1 } { Z _ { \rho } ( q ) } \rho _ { \mathrm { r e f } } ( z \mid q ) Z _ { \pi } ( q , z )
$$

where

$$
Z _ { \rho } ( q ) = \sum _ { z } \rho _ { \mathrm { r e f } } ( z \mid q ) Z _ { \pi } ( q , z )
$$

Combining these two results yields exactly the stated closed-form solutions

$$
\begin{array} { r l } & { p ^ { * } ( z \mid q ) \propto p _ { \mathrm { r e f } } ( z \mid q ) \mathbb { E } _ { ( w , a ^ { \prime } ) \sim p _ { \mathrm { r e f } } ( \cdot \mid q , z ) } \left[ \exp \left( \displaystyle \frac { 1 } { \beta } r ( q , a ^ { \prime } , a ) \right) \right] , } \\ & { p ^ { * } ( w , a ^ { \prime } \mid q , z ) \propto p _ { \mathrm { r e f } } ( w , a ^ { \prime } \mid q , z ) \exp \left( \displaystyle \frac { 1 } { \beta } r ( q , a ^ { \prime } , a ) \right) . } \end{array}
$$

# C Omitted Theorems and Proofs

# C.1 Notion

Let $B ( r , x )$ represent the $l _ { 2 }$ -ball of radius $r$ centered at $x$ . For two positive sequences $\left\{ a _ { n } \right\}$ and $\left\{ b _ { n } \right\}$ , $a _ { n } \gtrsim b _ { n }$ if $a _ { n } \geq C b _ { n }$ . The $l _ { 2 }$ norm of a vector $x \in \mathbb { R } ^ { d }$ is defined as $\begin{array} { r l r } { \| \boldsymbol { x } \| _ { 2 } : = } & { { } } & { \left( \sum _ { i = 1 } ^ { d } x _ { i } ^ { 2 } \right) ^ { 1 / 2 } } \end{array}$ 1/2 . A sequence of random variables $X _ { n }$ is said to be $o _ { P } ( 1 )$ if $X _ { n } \overset { P } { \longrightarrow } 0$ , that is, $X _ { n }$ converges to 0 in probability as $n \to \infty$ . The Kullback–Leibler (KL) divergence from a discrete distribution $p$ to a discrete distribution $q$ (defined over a common support $\mathcal { X }$ ) is given by $\begin{array} { r } { \mathbb { D } _ { \mathrm { K L } } \left[ p \parallel q \right] : = \sum _ { x \in \mathcal { X } } p ( x ) \log \left( \frac { p ( x ) } { q ( x ) } \right) } \end{array}$ under the assumption that whenever $p ( x ) > 0$ , one also has $q ( x ) > 0$ for all $x \in \mathcal { X }$ .

# C.2 Main theorem

Recall the losses (4.2) and (4.5) are defined as follows:

$$
\begin{array} { r } { \mathbb { E } _ { q } \left[ \mathbb { E } _ { z \sim \rho _ { \theta } , ( w , a ^ { \prime } ) \sim \pi _ { \theta } } \left[ r ( a ^ { \prime } , q , a ) \right] - \beta \mathbb { D } _ { \mathrm { K L } } \left[ u _ { \theta } ( a ^ { \prime } , z , w \mid q ) \| u _ { \mathrm { r e f } } ( a ^ { \prime } , z , w \mid q ) \right] \right] . } \end{array}
$$

$$
\mathcal { L } _ { \mathrm { m D P 0 } } : = - \mathbb { E } _ { ( x , g ^ { + } , g ^ { - } ) \sim \mathcal { D } _ { \mathrm { p e f } } ^ { ( t ) } } \log \sigma \left( \beta \left[ \log \frac { p _ { \theta } ^ { ( t + 1 ) } ( g ^ { + } \mid x ) } { p _ { \theta } ^ { ( t ) } ( g ^ { + } \mid x ) } - \log \frac { p _ { \theta } ^ { ( t + 1 ) } ( g ^ { - } \mid x ) } { p _ { \theta } ^ { ( t ) } ( g ^ { - } \mid x ) } \right] \right) .
$$

To enable decomposition into a decomposer and a solver, we require the following assumption: assumption C.1 (Conditional Probability decomposition). We assume the following decomposition holds:

$$
p _ { \theta } ( a \mid q ) = \sum _ { z } p _ { \theta } ( z \mid q ) \left( \sum _ { w } p _ { \theta } ( a \mid q , z , w ) p _ { \theta } ( w \mid q , z ) \right)
$$

We present the informal version of our theorem below. Formal statements are given in Theorems C.2 and C.3.

Theorem C.1 (Informal). Under regularity conditions, with high probability, the minimizer of the loss (C.2) at step $t$ is close to the minimizer of the loss (C.1). Furthermore, as $t$ increases, the minimizer converges to the true parameter $\theta ^ { * }$ .

Remark C.1. The main theorem can be divided into two components. The first component establishes the equivalence between loss (C.1) and loss (C.2) are equivalent. The second component shows that, once the equivalence is established and the maximizer of loss (C.1) converges, the minimizer of loss (C.2) also converges.

The proof is organized as follows: In Appendices C.3 and C.4, we analyze the convergence properties of the maximizer of the population version loss (C.3) and sample version of loss (C.6) which corresponds exactly to loss (C.1). In Appendix C.5, we demonstrate the equivalence of loss (C.1) to loss (C.2). Finally, in Appendix C.6, building on these results, we prove that the minimizer of loss (C.2) converges as well.

# C.3 Population Version

Based on the loss (C.1), define the population version loss as

$$
\begin{array} { r } { L ( \theta \mid \theta _ { t - 1 } ) = \mathbb { E } _ { ( q , a ) \sim p _ { \theta ^ { * } } ( \cdot ) } \left[ \mathbb { E } _ { z \sim \rho _ { \theta } ( \cdot \vert q ) } \left[ \mathbb { E } _ { ( w , a ^ { \prime } ) \sim \pi _ { \theta } ( \cdot \vert z , q ) } [ r ( a ^ { \prime } , q , a ) ] \right] \right] } \\ { - \beta \mathbb { D } _ { \mathrm { K L } } \left( u _ { \theta } ( a ^ { \prime } , z , w \mid q ) \Vert u _ { \theta _ { t - 1 } } ( a ^ { \prime } , z , w \mid q ) \right) . } \end{array}
$$

Define the operator $M : \Theta \to \Theta$ ,

$$
M ( \theta ) = \arg \operatorname* { m a x } _ { \theta ^ { \prime } \in \Theta } L ( \theta ^ { \prime } \mid \theta ) ,
$$

where $\Theta$ represents the parameter space. Notice that it is natural to assume that $\theta ^ { * }$ satisfy the self-consistency, i.e. $\theta ^ { * } = M ( \theta ^ { * } )$ . So the first assumption will be:

assumption C.2 (Self-consistency). $\theta ^ { * } = M ( \theta ^ { * } )$

assumption C.3 $\lambda$ -strong Concavity). There is some $\lambda > 0$ such that

$$
L ( \theta _ { 1 } \mid \theta ^ { * } ) - L ( \theta _ { 2 } \mid \theta ^ { * } ) - \langle \nabla L ( \theta _ { 2 } \mid \theta ^ { * } ) , \theta _ { 1 } - \theta _ { 2 } \rangle \leq - \frac { \lambda } { 2 } \| \theta _ { 1 } - \theta _ { 2 } \| _ { 2 } ^ { 2 } \quad \mathrm { f o r ~ a l l ~ } \theta _ { 1 } , \theta _ { 2 } \in B ( r , \theta ^ { * } ) .
$$

Definition C.1 (First-order stability). The functions $\{ L ( \cdot \mid \theta ) , \theta \in \Theta \}$ satisfy the First-order stability condition over $B ( r , \theta ^ { * } )$ if

$$
\begin{array} { r } { \| \nabla L ( M ( \theta ) \mid \theta ^ { * } ) - \nabla L ( M ( \theta ) \mid \theta ) \| _ { 2 } \leq \mu \| \theta - \theta ^ { * } \| _ { 2 } } \end{array}
$$

for all $\theta \in B ( r , \theta ^ { * } )$

assumption C.4. Assume the functions $\{ L ( \cdot \mid \theta ) , \theta \in \Theta \}$ satisfy the First-order stability condition (C.1).

Proposition C.1 (Population Version). For some radius $r > 0$ and pair $( \mu , \lambda )$ such that $0 \leq \mu < \lambda$ , suppose that the Assumption C.1-C.4 hold, then the population operator $M$ is contractive over $B ( r , \theta ^ { * } )$ , in particular with

$$
\lVert M ( \theta _ { t - 1 } ) - \theta ^ { * } \rVert _ { 2 } \leq \frac { \mu } { \lambda } \lVert \theta _ { t - 1 } - \theta ^ { * } \rVert _ { 2 } \quad \mathrm { f o r ~ a l l ~ } \theta \in B ( r , \theta ^ { * } ) .
$$

Proof. By the first order optimality condition, we have:

$$
\begin{array} { r l } & { ~ \langle \nabla L ( \theta ^ { * } \mid \theta ^ { * } ) , \theta - \theta ^ { * } \rangle \leq 0 \quad \forall \theta } \\ & { \Rightarrow \langle \nabla L ( \theta ^ { * } \mid \theta ^ { * } ) , M ( \theta _ { t - 1 } ) - \theta ^ { * } \rangle \leq 0 } \\ & { \quad \langle \nabla L ( M ( \theta _ { t - 1 } ) \mid \theta _ { t - 1 } ) , \theta - M ( \theta _ { t - 1 } ) \rangle \leq 0 \quad \forall \theta } \\ & { \Rightarrow \langle \nabla L ( M ( \theta _ { t - 1 } ) \mid \theta _ { t - 1 } ) , \theta ^ { * } - M ( \theta _ { t - 1 } ) \rangle \leq 0 . } \end{array}
$$

Combine the two terms,

$$
\langle \nabla L ( \theta ^ { * } \mid \theta ^ { * } ) - \nabla L ( M ( \theta _ { t - 1 } ) \mid \theta _ { t - 1 } ) , M ( \theta _ { t - 1 } ) - \theta ^ { * } \rangle \leq 0 .
$$

Thus,

$$
\begin{array} { r l } & { \langle \nabla L ( \theta ^ { * } \mid \theta ^ { * } ) - \nabla L ( M ( \theta _ { t - 1 } ) \mid \theta ^ { * } ) , M ( \theta _ { t - 1 } ) - \theta ^ { * } \rangle \leq } \\ & { \qquad - \langle \nabla L ( M ( \theta _ { t - 1 } ) \mid \theta ^ { * } ) - \nabla L ( M ( \theta _ { t - 1 } ) \mid \theta _ { t - 1 } ) , M ( \theta _ { t - 1 } ) - \theta ^ { * } \rangle . } \end{array}
$$

For the right-hand side, by Cauchy-Schwarz inequality,

$$
\begin{array} { r l } & { - \left. \nabla L ( M ( \theta _ { t - 1 } ) \mid \theta ^ { * } ) - \nabla L ( M ( \theta _ { t - 1 } ) \mid \theta _ { t - 1 } ) , M ( \theta _ { t - 1 } ) - \theta ^ { * } \right. \leq } \\ & { \qquad \| \nabla L ( M ( \theta _ { t - 1 } ) \mid \theta ^ { * } ) - \nabla L ( M ( \theta _ { t - 1 } ) \mid \theta _ { t - 1 } ) \| _ { 2 } \| M ( \theta _ { t - 1 } ) - \theta ^ { * } \| _ { 2 } . } \end{array}
$$

By Assumption C.4,

$$
\begin{array} { r } { \| \nabla L ( M ( \theta _ { t - 1 } ) \mid \theta ^ { * } ) - \nabla L ( M ( \theta _ { t - 1 } ) \mid \theta _ { t - 1 } ) \| _ { 2 } \| M ( \theta _ { t - 1 } ) - \theta ^ { * } \| _ { 2 } \leq \mu \| M ( \theta _ { t - 1 } ) - \theta ^ { * } \| _ { 2 } ^ { 2 } . } \end{array}
$$

For the left-hand side, by Assumption C.3,

$$
\begin{array} { r l } & { \frac { \lambda } { 2 } \| M ( \theta _ { t - 1 } ) - \theta ^ { * } \| _ { 2 } ^ { 2 } \leq L ( \theta ^ { * } \mid \theta ^ { * } ) - L ( M ( \theta _ { t - 1 } ) \mid \theta ^ { * } ) + \langle \nabla L ( \theta ^ { * } \mid \theta ^ { * } ) , M ( \theta _ { t - 1 } ) - \theta ^ { * } \rangle , } \\ & { \frac { \lambda } { 2 } \| M ( \theta _ { t - 1 } ) - \theta ^ { * } \| _ { 2 } ^ { 2 } \leq L ( M ( \theta _ { t - 1 } ) \mid \theta ^ { * } ) - L ( \theta ^ { * } \mid \theta ^ { * } ) + \langle \nabla L ( M ( \theta _ { t - 1 } ) \mid \theta ^ { * } ) , \theta ^ { * } - M ( \theta _ { t - 1 } ) \rangle . } \end{array}
$$

Hence,

$$
\begin{array} { r } { \lambda \| M ( \theta _ { t - 1 } ) - \theta ^ { * } \| _ { 2 } ^ { 2 } \leq \langle \nabla L ( \theta ^ { * } \mid \theta ^ { * } ) - \nabla L ( M ( \theta _ { t - 1 } ) \mid \theta ^ { * } ) , M ( \theta _ { t - 1 } ) - \theta ^ { * } \rangle . } \end{array}
$$

Combining all,

$$
\lambda \| M ( \theta _ { t - 1 } ) - \theta ^ { * } \| _ { 2 } ^ { 2 } \leq \mu \| M ( \theta _ { t - 1 } ) - \theta ^ { * } \| _ { 2 } ^ { 2 } .
$$

Remark C.2. This theorem follows the idea in [3]. It suggests that, under a self-play procedure, the algorithm progressively approaches the true underlying distribution. This behavior is characterized by a contraction parameter $\frac { \mu } { \lambda }$ , which ensures convergence toward the ground-truth parameter $\theta ^ { * }$ . The incorporation of an intermediate reasoning step smooths the local optimization landscape, rendering the loss approximately convex and thereby facilitating convergence to the global optimum.

# C.4 Sample Version

We define the below sample version: assume we have the data

$$
\mathcal { D } _ { q , a } = \{ q _ { i } , a _ { i } \} _ { i = 1 } ^ { N } .
$$

The loss will be:

$$
\begin{array} { r l } & { L _ { N } ( \theta \mid \theta _ { t - 1 } ) = \mathbb { E } _ { ( q , a ) \sim \widetilde { p } _ { \theta ^ { * } } ( \cdot ) } [ \mathbb { E } _ { z \sim \rho _ { \theta } ( \cdot \vert q ) } [ \mathbb { E } _ { ( w , a ^ { \prime } ) \sim \pi _ { \theta } ( \cdot \vert z , q ) } [ r ( a ^ { \prime } , q , a ) ] ] ] } \\ & { \qquad \quad - \ \beta \mathbb { D } _ { \mathrm { K L } } ( u _ { \theta } ( a ^ { \prime } , z , w \mid q )  u _ { \theta _ { t - 1 } } ( a ^ { \prime } , z , w \mid q ) ) , } \end{array}
$$

where $\widetilde { p }$ represents the empirical distribution defined as

$$
\widetilde { p } ( q , a ) = \frac { 1 } { N } \sum _ { i = 1 } ^ { N } 1 \{ ( q , a ) = ( q _ { i } , a _ { i } ) \} .
$$

We also have the similar convergence property. Similar to the population version, we define the sample-based operator $M _ { N } : \Theta \to \Theta$ ,

$$
M _ { N } ( \theta ) = \arg \operatorname* { m a x } _ { \theta ^ { \prime } \in \Theta } L _ { N } ( \theta ^ { \prime } \mid \theta ) .
$$

For a given sample size $N$ and tolerance parameter $\epsilon \in ( 0 , 1 )$ , define $\zeta _ { M } ^ { \mathrm { u n i f } } ( N , \epsilon )$ as the smallest scalar such that

$$
\operatorname* { s u p } _ { \theta \in B _ { 2 } ( r ; \theta ^ { * } ) } \| M _ { N } ( \theta ) - M ( \theta ) \| _ { 2 } \leq \zeta _ { M } ^ { \mathrm { u n i f } } ( N , \epsilon )
$$

with probability at least $1 - \epsilon$

Proposition C.2 (Sample Version). Suppose that for all $\theta \in B ( r , \theta ^ { * } )$ , the mapping $M$ satisfies

$$
\lVert M ( \theta _ { t - 1 } ) - \theta ^ { * } \rVert _ { 2 } \leq \frac \mu \lambda \lVert \theta _ { t - 1 } - \theta ^ { * } \rVert _ { 2 }
$$

with probability at least $1 - \epsilon$ . Then we have

$$
\| M _ { N } ( \theta _ { t - 1 } ) - \theta ^ { * } \| _ { 2 } \leq \frac { \mu } { \lambda } \| \theta _ { t - 1 } - \theta ^ { * } \| _ { 2 } + \zeta _ { M } ^ { \operatorname* { u n i f } } ( N , \epsilon ) , \quad \mathrm { f o r ~ a l l } \ : \theta \in B ( r , \theta ^ { * } )
$$

with probability at least $1 - \epsilon$

Proof. The result follows directly from the triangle inequality:

$$
\begin{array} { r l } & { \| M _ { N } ( \theta _ { t - 1 } ) - \theta ^ { * } \| _ { 2 } \leq \| M ( \theta _ { t - 1 } ) - \theta ^ { * } \| _ { 2 } + \| M _ { N } ( \theta _ { t - 1 } ) - M ( \theta _ { t - 1 } ) \| _ { 2 } } \\ & { \qquad \leq \frac { \mu } { \lambda } \| \theta _ { t - 1 } - \theta ^ { * } \| _ { 2 } + \zeta _ { M } ^ { \mathrm { u n i f } } ( N , \epsilon ) . } \end{array}
$$

# C.5 On the Equivalence with DPO

In the deterministic setting - where $m$ or $m ^ { \prime }$ is fixed and the responses with the maximum and minimum rewards are selected - depending on the data tuple $\left( ( a ^ { \mathrm { m a x } } , z ^ { \mathrm { m a x } } , w ^ { \mathrm { m a x } } ) , ( a ^ { \mathrm { m i n } } , z ^ { \mathrm { m i n } } , w ^ { \mathrm { m i n } } ) , a , q \right)$ , we note that in practice the construction of positive and negative samples can vary, some containing $z$ or $( z , w )$ , and others including full triples such as $( a ^ { \prime } , z , w )$ . For simplicity, we unify the representation and consider the minimal component shared across all formats, namely the tuple $( a ^ { \prime } , z , w )$ . This process can thus be interpreted as observing a finite dataset:

$$
\mathcal { D } = \{ ( ( a _ { i } ^ { + } , z _ { i } ^ { + } , w _ { i } ^ { + } ) , ( a _ { i } ^ { - } , z _ { i } ^ { - } , w _ { i } ^ { - } ) , a _ { i } , q _ { i } ) \} _ { i = 1 } ^ { N } ,
$$

Then the DPO loss will be:

$$
\begin{array} { r l } & { L _ { \mathrm { m D P O } } ( \theta \mid \theta _ { t - 1 } ) = - \operatorname { \mathbb { E } } _ { ( ( a ^ { + } , z ^ { + } , w ^ { + } ) , ( a ^ { - } , z ^ { - } , w ^ { - } ) , a , q ) \sim \mathcal { D } } } \\ & { \phantom { x x x x x x x x x x x x x x x x x x x x x x x x x x x x x x x x x x x x x x x x x x x x x x x x x x x x x x } \log \sigma \Big ( \beta _ { \mathrm { m D P O } } \Big [ \log \frac { u _ { \theta } ( a ^ { + } , z ^ { + } , w ^ { + } \mid q ) } { u _ { \theta _ { t - 1 } } ( a ^ { + } , z ^ { + } , w ^ { + } \mid q ) } - \log \frac { u _ { \theta } ( a ^ { - } , z ^ { - } , w ^ { - } \mid q ) } { u _ { \theta _ { t - 1 } } ( a ^ { - } , z ^ { - } , w ^ { - } \mid q ) } \Big ] \Big ) } \end{array}
$$

To demonstrate the closeness between the loss (C.6) and the loss (C.8), we first show that, with high probability, optimizing the loss (C.8) over the dataset $\mathcal { D }$ is equivalent to maximizing the original reward up to a scaling factor.

Specifically, we can derive a closed-form solution for Equation (C.6) at step $t$ :

$$
u _ { \theta _ { t } ^ { * } } ( a ^ { \prime } , z , w \mid q ) \propto u _ { \theta _ { t - 1 } } ( a ^ { \prime } , z , w \mid q ) \exp { \left( \frac { 1 } { \beta } r ( a ^ { \prime } , q , a ) \right) } ,
$$

where $\theta _ { t } ^ { * }$ denotes the ground truth parameter at step $t$ . Accordingly, the reward function $r ( a ^ { \prime } , q , a )$ can be written as $r _ { \gamma _ { t } ^ { * } } ( a ^ { \prime } , q , a )$ to emphasize its dependence on the true reward parameter $\gamma _ { t } ^ { * }$ . Specifically, consider the dataset $\mathcal { D }$ , which follows the following deterministic model:

$$
\mathbb { P } ( ( a ^ { + } , z ^ { + } , w ^ { + } ) \succ ( a ^ { - } , z ^ { - } , w ^ { - } ) \mid q ) = 1 \quad \mathrm { i f } \quad r _ { \gamma _ { t } ^ { * } } ( a _ { i } ^ { + } , q , a ) > r _ { \gamma _ { t } ^ { * } } ( a _ { i } ^ { - } , q , a ) ,
$$

indicating that we always select $a _ { i } ^ { + }$ as the positive sample. To approximate this deterministic behavior, we introduce the $\alpha$ -BT model:

$$
\mathbb { P } ( ( a ^ { + } , z ^ { + } , w ^ { + } ) \succ ( a ^ { - } , z ^ { - } , w ^ { - } ) \mid q ) = \frac { e ^ { \alpha r _ { \gamma _ { t } ^ { * } } ( a ^ { + } , q , a ) } } { e ^ { \alpha r _ { \gamma _ { t } ^ { * } } ( a ^ { + } , q , a ) } + e ^ { \alpha r _ { \gamma _ { t } ^ { * } } ( a ^ { - } , q , a ) } } .
$$

As $\alpha \to \infty$ , the $\alpha$ -BT model becomes close to the deterministic model (C.10). Then given the above dataset $\mathcal { D }$ , we define the following data set

$$
\begin{array} { r l } & { \mathcal { D } _ { \alpha } = \{ ( ( a _ { \alpha , i } ^ { + } , z _ { \alpha , i } ^ { + } , w _ { \alpha , i } ^ { + } ) , ( a _ { \alpha , i } ^ { - } , z _ { \alpha , i } ^ { - } , w _ { \alpha , i } ^ { - } ) , a _ { i } , q _ { i } ) \} _ { i = 1 } ^ { n } , } \end{array}
$$

where $( ( a _ { \alpha , i } ^ { + } , z _ { \alpha , i } ^ { + } , w _ { \alpha , i } ^ { + } ) , ( a _ { \alpha , i } ^ { - } , z _ { \alpha , i } ^ { - } , w _ { \alpha , i } ^ { - } ) )$ is generated according to the $\alpha$ -BT model (C.11). To ensure the closeness between the dataset $\mathcal { D }$ and $\mathcal { D } _ { \alpha }$ , we have the following lemma: assumption C.5 (Reward Seperation Condition). Assume that given $( q , a )$ , for any $( ( a ^ { + } , \bar { z } ^ { + } , w ^ { + } ) , ( a ^ { - } , z ^ { - } , w ^ { - } ) )$ , there exists $\delta$ such that $| r _ { \gamma _ { t } ^ { * } } ( a ^ { + } , q , a ) - r _ { \gamma _ { t } ^ { * } } ( a ^ { - } , q , a ) | \geq \delta$ .

Lemma C.1. Suppose the Assumption C.5 holds, given $\epsilon$ , there exists $\alpha _ { 0 } \gtrsim \frac { \log \frac { N } { 2 \epsilon } } { \delta }$ ,

$$
\mathbb { P } ( \mathcal { D } = \mathcal { D } _ { \alpha _ { 0 } } ) \ge 1 - \frac { \epsilon } { 2 } .
$$

Proof. We start by bounding the probability of disagreement between two actions:

$$
\mathbb { P } ( ( a _ { \alpha , i } ^ { + } , z _ { \alpha , i } ^ { + } , w _ { \alpha , i } ^ { + } ) \neq ( a _ { i } ^ { + } , z _ { i } ^ { + } , w _ { i } ^ { + } ) ) = \frac { e ^ { \alpha r _ { \gamma _ { t } ^ { * } } ( a ^ { - } , q , a ) } } { e ^ { \alpha r _ { \gamma _ { t } ^ { * } } ( a ^ { + } , q , a ) } + e ^ { \alpha r _ { \gamma _ { t } ^ { * } } ( a ^ { - } , q , a ) } } \leq \frac { 1 } { 1 + e ^ { \alpha _ { 0 } \delta } } .
$$

The total probability that the datasets $\mathcal { D }$ and $\mathcal { D } _ { \alpha }$ differ is bounded by

$$
\mathbb { P } ( \mathcal { D } \neq \mathcal { D } _ { \alpha } ) = \sum _ { i = 1 } ^ { N } \mathbb { P } ( a _ { i } ^ { + } \neq a _ { i } ^ { - } ) \leq \frac { N } { 1 + e ^ { \alpha _ { 0 } \delta } } .
$$

Given $\alpha _ { 0 } \gtrsim \frac { \log \frac { N } { 2 \epsilon } } { \delta }$ , we conclude that

$$
\mathbb { P } ( \mathcal { D } = \mathcal { D } _ { \alpha } ) = 1 - \mathbb { P } ( \mathcal { D } \neq \mathcal { D } _ { \alpha } ) \geq 1 - \frac { \epsilon } { 2 } .
$$

we can take our data generated according to the $\alpha _ { 0 }$ -BT model. In this case the new reward will be

$$
\widetilde { r } _ { \alpha _ { 0 } , \gamma _ { t } ^ { * } } ( a ^ { \prime } , q , a ) = \alpha _ { 0 } r _ { \gamma _ { t } ^ { * } } ( a ^ { \prime } , q , a ) .
$$

Under this model, the minimizer of the loss (C.8) can be obtained via a two-step optimization   
procedure [55]:   
Step 1: minimize the negative log-likelihood to obtain the reward:

$$
\begin{array} { r l } & { L _ { N , \operatorname { N L L } } ( \gamma \mid \alpha _ { 0 } ) = - \mathbb { E } _ { ( ( a ^ { + } , z ^ { + } , w ^ { + } ) , ( a ^ { - } , z ^ { - } , w ^ { - } ) , a , q ) \sim \mathcal { D } } } \\ & { \phantom { a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a } \log \sigma \Big ( \tilde { r } _ { \alpha _ { 0 } , \gamma } ( a ^ { + } , q , a ) - \widetilde { r } _ { \alpha _ { 0 } , \gamma } ( a ^ { - } , q , a ) \Big ) , } \end{array}
$$

Denote the minimizer as $\widetilde { r } _ { \alpha _ { 0 } , \widehat { \gamma } _ { N , t } } ( a ^ { \prime } , q , a )$ .

eStep 2: maximize the reward $\widetilde { r } _ { \alpha _ { 0 } , \widehat { \gamma } _ { N , t } } ( a ^ { \prime } , q , a )$ :

$$
\begin{array} { r l r } & { } & { L _ { \mathrm { { R E W } } } ( \theta \mid \theta _ { t - 1 } ) = { \mathbb E } _ { ( a , q ) \sim \widetilde { p } _ { \theta ^ { * } } ( \cdot ) } \left[ { \mathbb E } _ { z , w \sim \widetilde { p } _ { \theta _ { t - 1 } } ( \cdot \vert a , q ) } \left[ { \mathbb E } _ { a ^ { \prime } \sim f _ { \theta } ( \cdot \vert z , w , q , a ) } \big [ \widetilde { r } _ { \alpha _ { 0 } , \widehat { \gamma } _ { N , t } } ( a ^ { \prime } , q , a ) \big ] \right] \right] } \\ & { } & { - \ \beta _ { \mathrm { { m D P } O } } { \mathbb D } _ { \mathrm { { K L } } } \left( { u } _ { \theta } ( a ^ { \prime } \mid z , w , q , a ) \parallel { u } _ { \theta _ { t - 1 } } ( a ^ { \prime } \mid z , w , q , a ) \right) . } \end{array}
$$

The solution will be

$$
u _ { \widehat { \theta } _ { t } } ( a ^ { \prime } \mid z , w , q , a ) \propto u _ { \theta _ { t - 1 } } ( a ^ { \prime } \mid z , w , q , a ) \exp \left( \frac { 1 } { \beta _ { \mathrm { m D P O } } } \widetilde { r } _ { \alpha _ { 0 } , \widehat { \gamma } _ { N , t } } ( a ^ { \prime } , q , a ) \right) ,
$$

This expression is identical to Equation (C.9), except that it uses a different parameterization of the reward. Specifically, the reward function $\widetilde { r } _ { \alpha _ { 0 } , \gamma _ { t } ^ { * } } ( a ^ { \prime } , q , a )$ is parameterized by the ground truth $\gamma _ { t } ^ { * }$ and a hyperparameter $\alpha _ { 0 }$ e  . To ensure uniform consistency of the maximum likelihood estimator, we invoke the following lemma, which is modified from Theorem 5.7 in [69]. This result guarantees that the minimizer in Step 1 converges to the true reward function $\widetilde { r } _ { \alpha _ { 0 } , \gamma _ { t } ^ { * } } \left( a ^ { \prime } , q , a \right)$ . We need the following assumption:

assumption C.6. Suppose that there exists a constant $c _ { \alpha } > 0$ , for every $\epsilon > 0$ , such that:

$$
\operatorname* { s u p } _ { \alpha _ { 0 } \in [ c _ { \alpha } , \infty ) } \operatorname* { s u p } _ { \gamma \in \Gamma } \vert L _ { N , { \mathrm { N L L } } } ( \gamma \mid \alpha _ { 0 } ) - L _ { \mathrm { N L L } } ( \gamma \mid \alpha _ { 0 } ) \vert \overset { P } { \longrightarrow } 0 ,
$$

where $\Gamma$ represents the parameter space and

$$
\operatorname* { s u p } _ { \alpha _ { 0 } \in [ c _ { \alpha } , \infty ) } \operatorname* { s u p } _ { \substack { \gamma : \| \gamma - \gamma _ { t } ^ { * } \| _ { 2 } \geq \epsilon } } - ( L _ { \mathrm { N L L } } ( \gamma \mid \alpha _ { 0 } ) - L _ { \mathrm { N L L } } ( \gamma _ { t } ^ { * } \mid \alpha _ { 0 } ) ) < 0 .
$$

Lemma C.2 (Uniform MLE Consistency). Let $L _ { N , \mathrm { N L L } } ( \gamma \mid \alpha _ { 0 } )$ be the negative log-likelihood function, and let $L _ { \mathrm { N L L } } ( \gamma \mid \alpha _ { 0 } )$ denote its expected version. Let Assumption C.6 holds, then for the sequence of estimators $\widehat { \gamma } _ { N , t }$ obtained form minimizing the loss (C.14), we have: given $\epsilon > 0$ , there exists $N _ { 1 }$ , when $N \geq N _ { 1 }$ , for any $\alpha _ { 0 } \in [ c _ { \alpha } , \infty )$ ,

$$
\mathbb { P } \big ( \| \widehat { \gamma } _ { N , t } - \gamma _ { t } ^ { * } \| _ { 2 } \leq \epsilon \big ) \geq 1 - \frac { \epsilon } { 2 } .
$$

Proof. For given $\epsilon$ , according to the Equation (C.18), there exists $c _ { \epsilon , N L L }$ , such that:

$$
\operatorname* { s u p } _ { \alpha _ { 0 } \in [ c _ { \alpha } , \infty ) } \operatorname* { s u p } _ { \gamma : \| \gamma - \gamma _ { t } ^ { * } \| _ { 2 } \geq \epsilon } - ( L _ { \mathrm { N L L } } ( \gamma \mid \alpha _ { 0 } ) - L _ { \mathrm { N L L } } ( \gamma _ { t } ^ { * } \mid \alpha _ { 0 } ) ) < - c _ { \epsilon , N L L } .
$$

For $c _ { \epsilon , N L L }$ , according to Equation (C.17), there exists $N _ { 1 }$ , when $N \geq N _ { 1 }$ , for any $\alpha _ { 0 } \in [ c _ { \alpha } , \infty )$

$$
\begin{array} { r l } & { \mathbb { P } \Big ( | L _ { N , \mathrm { N L L } } ( \widehat { \gamma } _ { N , t } \mid \alpha _ { 0 } ) - L _ { \mathrm { N L L } } ( \widehat { \gamma } _ { N , t } \mid \alpha _ { 0 } ) | \leq \frac { c _ { \epsilon , N L L } } { 3 } \Big ) \geq 1 - \frac { \epsilon } { 4 } , } \\ & { \mathbb { P } \Big ( | L _ { N , \mathrm { N L L } } ( \gamma _ { t } ^ { * } \mid \alpha _ { 0 } ) - L _ { \mathrm { N L L } } ( \gamma _ { t } ^ { * } \mid \alpha _ { 0 } ) | \leq \frac { c _ { \epsilon , N L L } } { 3 } \Big ) \geq 1 - \frac { \epsilon } { 4 } . } \end{array}
$$

Since $\widehat { \gamma } _ { N , t }$ is the minimizer of loss (C.14), for any $\alpha _ { 0 } \in [ c _ { \alpha } , \infty )$ , we have:

$$
L _ { N , \mathrm { N L L } } ( \widehat { \gamma } _ { N , t } \mid \alpha _ { 0 } ) \leq L _ { N , \mathrm { N L L } } ( \gamma _ { t } ^ { * } \mid \alpha _ { 0 } )
$$

Consequently,

$$
\mathbb { P } \left( - ( L _ { \mathrm { N L L } } ( \gamma \mid \alpha _ { 0 } ) - L _ { \mathrm { N L L } } ( \gamma _ { 0 } \mid \alpha _ { 0 } ) ) \ge - \frac { 2 c _ { \epsilon , N L L } } { 3 } \right) \ge 1 - \frac { \epsilon } { 2 } .
$$

Thus for any $\alpha _ { 0 } \in [ c _ { \alpha } , \infty )$ ,

$$
\mathbb { P } \big ( \| \widehat { \gamma } _ { N , t } - \gamma _ { t } ^ { * } \| _ { 2 } \leq \epsilon \big ) ~ \geq ~ \mathbb { P } \bigg ( - ( L _ { \operatorname { N L L } } ( \gamma \mid \alpha _ { 0 } ) - L _ { \operatorname { N L L } } ( \gamma _ { 0 } \mid \alpha _ { 0 } ) ) \geq - \frac { 2 c _ { \epsilon , N L L } } { 3 } \bigg ) ~ \geq ~ 1 - \frac { \epsilon } { 2 } .
$$

Having established the necessary groundwork, we are now ready to present Theorem C.2, which establishes the equivalence between the minimizes of the two loss functions:

Theorem C.2. Assume Assumptions C.5 and $\mathrm { C } . 6$ hold, given $\epsilon$ , there exists $N _ { 1 }$ and $\beta _ { \mathrm { m D P O } } \gtrsim \frac { \log \frac { N _ { 1 } } { 2 \epsilon } } { \delta } \beta$ the minimizer of loss (C.8) $\widehat { \theta } _ { t , \mathrm { { m D P O } } }$ will satisfy:

$$
\mathbb { P } \Big ( \Big \lVert \widehat { \theta } _ { t , \mathrm { m D P O } } - \theta _ { t } ^ { * } \Big \rVert _ { 2 } \geq \epsilon \Big ) < \epsilon ,
$$

where $\theta _ { t } ^ { * }$ is defined in Equation (C.9).

Proof. First, according to the Lemma C.2, there exists $N _ { 1 }$ , if we define the event $\begin{array} { r l } { \Omega _ { 1 } } & { { } = } \end{array}$ $\{ \| \widehat { \gamma } _ { N _ { 1 } , t } - \gamma _ { t } ^ { * } \| _ { 2 } \leq \epsilon \}$ , , we have:

$$
\mathbb { P } ( \Omega _ { 1 } ) \geq 1 - \frac { \epsilon } { 2 } .
$$

Secondly, just choose the sample size of $\mathcal { D }$ as $N K$ , define the event $\Omega _ { 2 } = \{ \mathcal { D } = \mathcal { D } _ { \alpha _ { 0 } } \}$ , by Lemma C.1, when we take $\begin{array} { r } { \alpha _ { 0 } \gtrsim \left( \frac { \log \frac { N _ { 1 } } { 2 \epsilon } } { \delta } \vee c _ { \alpha } \right) } \end{array}$ , we have:

$$
\mathbb { P } ( \Omega _ { 2 } ) \geq 1 - \frac { \epsilon } { 2 } .
$$

Since $c _ { \alpha }$ is a constant, we may, without loss of generality, take $\alpha _ { 0 } \gtrsim \frac { \log \frac { N _ { 1 } } { 2 \epsilon } } { \delta }$ log 12ϵδ . Henceforth, we restrict our analysis to the event $\Omega _ { 1 } \cap \Omega _ { 2 }$ , which occurs with probability at least1 $- \ \epsilon$ . Conditioned on this event, the data can be viewed as being generated from the $\alpha _ { 0 }$ -BT model (C.11). Consequently, the minimizer of the loss (C.8) coincides with that of Equation (C.16):

$$
\begin{array} { r } { \begin{array} { r } { u _ { \widehat { \theta } _ { t , \mathrm { m p p } } } ( a ^ { \prime } , z , w \mid q ) \propto u _ { \theta _ { t - 1 } } ( a ^ { \prime } , z , w \mid q ) \exp \left( \frac { 1 } { \beta _ { \mathrm { m D P } 0 } } \widetilde { r } _ { \alpha _ { 0 } , \widehat { \gamma } _ { N _ { 1 } , t } } ( a ^ { \prime } , q , a ) \right) } \\ { \propto u _ { \theta _ { t - 1 } } ( a ^ { \prime } , z , w \mid q ) \exp \left( \frac { \alpha _ { 0 } } { \beta _ { \mathrm { m D P } 0 } } r _ { \widehat { \gamma } _ { N _ { 1 } , t } } ( a ^ { \prime } , q , a ) \right) . } \end{array} } \end{array}
$$

Compared to the solution in (C.9), when $\begin{array} { r } { \beta _ { \mathrm { m D P O } } = \alpha _ { 0 } \beta \gtrsim \frac { \log \frac { N _ { 1 } } { 2 \epsilon } } { \delta } \beta } \end{array}$ log N12ϵδ β, controlling the distance between $\widehat { \theta } t$ , mDPO and $\theta _ { t } ^ { * }$ reduces to controlling the distance between $\widehat { \gamma } N _ { 1 } , t$ and $\gamma _ { t } ^ { * }$ , as established by Lemma C.2. Consequently, we obtain:

$$
\mathbb { P } \Big ( \Big \lVert \widehat { \theta } _ { t , \mathrm { m D P O } } - \theta _ { t } ^ { * } \Big \rVert _ { 2 } \geq \epsilon \Big ) < \epsilon .
$$

This concludes the proof.

# C.6 Convergence Property of DPO

Finally, combining Proposition C.2, we conclude that the sequence $\widehat { \theta } _ { t , \mathrm { { m D P O } } }$ converges as $t$ increases. We formally state the following theorem:

Theorem C.3. For a given iteraton number $T$ , for some radius $r > 0$ and pair $( \mu , \lambda )$ such that $0 \leq \mu < \lambda$ , suppose that the Assumption C.1-C.6 hold and assume $\begin{array} { r } { ( \epsilon + \zeta _ { M } ^ { \mathrm { u n i f } } ( N , \epsilon ) ) < ( 1 - \frac { \mu } { \lambda } ) r } \end{array}$ , then with probability at least $1 - ( T + 1 ) \epsilon$ , we have:

$$
\left\| \widehat { \theta } _ { T , \mathrm { m D P O } } - \theta ^ { * } \right\| _ { 2 } \leq \left( \frac { \mu } { \lambda } \right) ^ { T } \| \theta _ { \mathrm { r e f } } - \theta ^ { * } \| _ { 2 } + \frac { 1 } { 1 - \frac { \mu } { \lambda } } \zeta _ { M } ^ { \mathrm { u n i f } } ( n , \epsilon )
$$

Proof. Notice that $\theta _ { t } ^ { * } = M _ { N } ( \widehat { \theta } _ { t - 1 , \mathrm { m D P O } } )$ , apply Proposition C.2, we get:

$$
\lVert { \boldsymbol { \theta } } _ { t } ^ { * } - { \boldsymbol { \theta } } ^ { * } \rVert _ { 2 } \leq \frac { \mu } { \lambda } \Big \lVert \widehat { { \boldsymbol { \theta } } } _ { t - 1 , \mathrm { m D P O } } - { \boldsymbol { \theta } } ^ { * } \Big \rVert _ { 2 } + \zeta _ { M } ^ { \mathrm { u n i f } } ( N , \epsilon )
$$

with probability at least $1 - \epsilon$ . Combining Theorem C.2,

$$
\left\| \widehat { \theta } _ { t , \mathrm { m D P O } } - \theta ^ { * } \right\| _ { 2 } \leq \frac { \mu } { \lambda } \left\| \widehat { \theta } _ { t - 1 , \mathrm { m D P O } } - \theta ^ { * } \right\| _ { 2 } + \epsilon + \zeta _ { M } ^ { \mathrm { u n i f } } ( N , \epsilon ) ,
$$

with probability at least $1 - 2 \epsilon$ . Notice that $\begin{array} { r } { ( \epsilon + \zeta _ { M } ^ { \mathrm { u n i f } } ( N , \epsilon ) ) \le ( 1 - \frac { \mu } { \lambda } ) r } \end{array}$ , then $\widehat { \theta } _ { t , \mathrm { { m D P O } } } \in B ( r , \theta ^ { * } )$ Based on this, we can perform iteration:

$$
\begin{array} { r l } { \left\| \widehat { \theta } _ { T , \mathrm { m D P O } } - \theta ^ { * } \right\| _ { 2 } \leq \frac { \mu } { \lambda } \Big \| \widehat { \theta } _ { T - 1 , \mathrm { m D P O } } - \theta ^ { * } \Big \| _ { 2 } + \epsilon + \zeta _ { M } ^ { \mathrm { m i f } } ( N , \epsilon ) } & { } \\ & { \leq \frac { \mu } { \lambda } \Big ( \frac { \mu } { \lambda } \Big \| \widehat { \theta } _ { T - 2 , \mathrm { m D P O } } - \theta ^ { * } \Big \| _ { 2 } + \epsilon + \zeta _ { M } ^ { \mathrm { u n i f } } ( N , \epsilon ) \Big ) } \\ & { \leq \left( \frac { \mu } { \lambda } \right) ^ { T } \| \theta _ { \mathrm { r e f } } - \theta ^ { * } \| _ { 2 } + \displaystyle \sum _ { s = 0 } ^ { T - 1 } \Big ( \frac { \mu } { \lambda } \Big ) ^ { s } ( \epsilon + \zeta _ { M } ^ { \mathrm { u n i f } } ( N , \epsilon ) ) } \\ & { \leq \left( \frac { \mu } { \lambda } \right) ^ { T } \| \theta _ { \mathrm { r e f } } - \theta ^ { * } \| _ { 2 } + \displaystyle \frac { 1 } { 1 - \frac { \mu } { \lambda } } ( \epsilon + \zeta _ { M } ^ { \mathrm { u n i f } } ( N , \epsilon ) ) } \end{array}
$$

with probability at least $1 - ( T + 1 ) \epsilon$ .

# D Information for Test Datasets

The information of the test datasets used in AceSearcher is listed in the following table. Note that We conduct evaluations on all questions from StrategyQA and Bamboogle, and the first 500 questions from the development sets of the other datasets following existing studies [68, 57, 36]. For dataset in DocMathEval, we use the testmini version as the evaluation set to compare the performance of AceSearcher and baselines.

Table 4: Descriptions of datasets used in AceSearcher. For SimpLong and CompLong, we use text-embedding-3 to retrieve top-10 relevant context before generate the answer.   

<table><tr><td rowspan=1 colspan=1>Dataset</td><td rowspan=1 colspan=1>Description</td></tr><tr><td rowspan=1 colspan=1>2WikiMHQA[21]</td><td rowspan=1 colspan=1>2WikiMultiHopQA is a multi-hop question answering dataset built from Wikipedia,where each question requires reasoning over two distinct articles. It emphasizesinformation synthesis across multiple documents for accurate answer retrieval.</td></tr><tr><td rowspan=1 colspan=1>HotpotQA [83]</td><td rowspan=1 colspan=1>HotpotQA is a crowd-sourced multi-hop QA dataset where each question demandsreasoning over multiple Wikipedia passages.It also includes supporting fact annotationsto promote explainability in QA systems.</td></tr><tr><td rowspan=1 colspan=1>Bamboogle [53]</td><td rowspan=1 colspan=1>Bamboogle is a multi-hop QA dataset constructed using Bing search engine snippets.It presents naturally occurring,challenging questions requiring reasoning over diverseweb snippets rather than structured sources like Wikipedia.</td></tr><tr><td rowspan=1 colspan=1>MusiQue [67]</td><td rowspan=1 colspan=1>MusiQue is a multi-hop QA dataset featuring real-world questions from communityforums like Quora and Yahoo Answers.It targets complex questions requiring synthesisacross multiple evidence passages,each carefully annotated.</td></tr><tr><td rowspan=1 colspan=1>HOVER [28]</td><td rowspan=1 colspan=1>HOVER is a multi-hop QA dataset with annotated supporting facts,built on entity-linked Wikipedia documents.It stresses explainable reasoning by providing intermedi-ate evidence chains.</td></tr><tr><td rowspan=1 colspan=1>ExFEVER [47]</td><td rowspan=1 colspan=1>ExFEVER extends the FEVER dataset by introducing multi-hop claims requiringevidence from multiple documents.It is designed to support research on fact verificationand evidence-based reasoning.</td></tr><tr><td rowspan=1 colspan=1>DMss (DocMath SimpShort)</td><td rowspan=1 colspan=1>A dataset reannotated from TAT-QA [94] and FinQA [7],consisting of short financialdocuments with a single table for simple numerical reasoning.</td></tr><tr><td rowspan=1 colspan=1>DMcs (DocMath CompShort)</td><td rowspan=1 colspan=1>A dataset reannotated from TAT-HQA [35],consisting of short single-table documentsfor complex numerical reasoning,including hypotheticals.</td></tr><tr><td rowspan=1 colspan=1>DMsL (DocMath SimpLong)</td><td rowspan=1 colspan=1>A dataset reannotated from MultiHiertt [9O],consisting of long multi-table financialdocuments for simple reasoning in realistic contexts.</td></tr><tr><td rowspan=1 colspan=1>DMcL (DocMath CompLong)</td><td rowspan=1 colspan=1>A dataset of long,structured financial documents requiring multi-step compositionalnumerical reasoning.</td></tr></table>

# E Details of Training Data

We provide the data composition for SFT and RFT, including their corresponding tasks, links to access the data, and the number we use in each stage in Table 5. To avoid data contamination, we follow the instructions in the MusiQue repository and remove the training data with overlapping IDs from NQ and Squad to avoid data leakage.

Table 5: The data composition for SFT and RFT stages.   

<table><tr><td>Dataset</td><td>Task</td><td>Link</td><td>Count</td></tr><tr><td colspan="4">Data composition for SFT</td></tr><tr><td>NarrativeQA [32]</td><td>Context-rich QA</td><td>https: //huggingface.co/datasets/deepmind/ narrativeqa</td><td>20000</td></tr><tr><td>SQuAD 1.1 [56]</td><td>Context-rich QA</td><td> https://rajpurkar.github.io/SQuAD-explorer/</td><td>10000</td></tr><tr><td>SQuAD 2.0 [56]</td><td>Context-rich QA</td><td> https://rajpurkar.github.io/SQuAD-explorer/</td><td>10000</td></tr><tr><td>TAT-QA [94]</td><td>Context-rich QA</td><td>https://github.com/NExTplusplus/TAT-QA/ tree/master/dataset_raw</td><td>12000</td></tr><tr><td>FEVER [66]</td><td>Context-rich QA</td><td> https://fever.ai/dataset/fever.html</td><td>10000</td></tr><tr><td>DROP[16]</td><td>Context-rich QA</td><td> https://huggingface.co/datasets/ucinlp/drop</td><td>20000</td></tr><tr><td>Quoref[12]</td><td>Context-rich QA</td><td>https: //huggingface.co/datasets/allenai/ quoref</td><td>20000</td></tr><tr><td>ROPES [38]</td><td>Context-rich QA</td><td>https://huggingface.co/datasets/allenai/ ropes</td><td>10000</td></tr><tr><td>NQ[33]</td><td>Context-rich QA</td><td>https://dl.fbaipublicfiles.com/dpr/data/ retriever/biencoder-nq-train.json.gz</td><td>20000</td></tr><tr><td>GSM8K [11]</td><td>Question Decomposition</td><td>https: //huggingface.co/datasets/openai/ gsm8k/viewer/socratic</td><td>7000</td></tr><tr><td>ConvFinQA [9]</td><td>Question Decomposition</td><td> https://github.com/czyssrs/ConvFinQA</td><td>1000</td></tr><tr><td>StrategyQA [19]</td><td>Question Decomposition</td><td>https://huggingface.co/datasets/ChilleD/ StrategyQA</td><td>1600</td></tr><tr><td>IfQA [85]</td><td>CoT</td><td>https://github.com/wyu97/IfQA/tree/main/ dataset</td><td>2000</td></tr><tr><td>TabMWP [46]</td><td>CoT</td><td>https://promptpg.github.io/index.html# dataset</td><td>10000</td></tr><tr><td>GSM8K [11]</td><td>CoT</td><td>https: //huggingface.co/datasets/openai/ gsm8k/viewer/socratic</td><td>7000</td></tr><tr><td>MathInstruct-COT [87]</td><td>CoT</td><td>https: //huggingface.co/datasets/TIGER-Lab/ MathInstruct</td><td>10000</td></tr><tr><td>MathInstruct-POT [87]</td><td>CoT</td><td>https: //huggingface.co/datasets/TIGER-Lab/ MathInstruct</td><td>10000</td></tr><tr><td>TOTAL</td><td>1</td><td>一</td><td>180600</td></tr><tr><td colspan="4">Data composition for RFT</td></tr><tr><td>HotpotQA [83]</td><td>RAG</td><td> https://github.com/hotpotqa/hotpot</td><td>10000</td></tr><tr><td>2WikiMQA [21]</td><td>RAG</td><td>https://huggingface.co/datasets/xanhho/ 2WikiMultihopQA</td><td>10000</td></tr><tr><td>HOVER [28]</td><td>RAG</td><td>https://github.com/hover-nlp/hover</td><td>10000</td></tr><tr><td>GSM8K[11]</td><td>Context-rich Reasoning</td><td>https://huggingface.co/datasets/openai/ gsm8k/viewer/socratic</td><td>7000</td></tr><tr><td>TabMWP [46]</td><td>Context-rich Reasoning</td><td>https://promptpg.github.io/index.html# dataset</td><td>10000</td></tr><tr><td>ConvFinQA [9]</td><td>Context-rich Reasoning</td><td>https://github.com/czyssrs/ConvFinQA</td><td>2000</td></tr><tr><td>Total</td><td>丨</td><td></td><td>49000</td></tr></table>

# F Prompt Templates

# F.1 Prompts for Direct RAG

You have the following context passages: {context}

Given the question: “{question}” as well as the context above, please answer the above question with one or a list of entities with the given context as the reference. Your answer needs to be a span with one or a list of entities.

Figure 6: Prompt for direct RAG on complex question answering tasks.

Answer the following questions with SUPPORTED or NOT_SUPPORTED with the given context as the reference.

Question: {question} Context: {context}

Your answer should only be SUPPORTED or NOT_SUPPORTED.

Figure 7: Prompt for direct RAG on fact verification tasks.

You have the following passages and table:

Passages: {passage}

# Tables: {table}

For the question “{question}”, write a Python program to solve the question. Store the final result in the variable ans.

Figure 8: Prompt for direct RAG on document-level reasoning tasks with PoT.

You have the following passages and table:

# Passages: {passage}

For the question “{question}”, reason step by step to calculate the final answer. Please use \boxed{} to wrap your final answer.

Figure 9: Prompt for direct RAG on document-level reasoning tasks with CoT.

Please break down the question “{question}” into multiple specific sub-questions that address individual components of the original question.

Mark each sub-question with ### at the beginning. If you need to refer to answers from earlier sub-questions, use #1, #2, etc., to indicate the corresponding answers.

Decomposed question:

Figure 10: Prompt for question decomposition on complex question answering tasks.

Please break down the claim “{claim}” into multiple smaller sub-claims that each focus on a specific component of the original statement, making it easier for a model to verify. Begin each sub-claim with ###. If needed, refer to answers from earlier sub-claims using #1, #2, etc.

Decomposed claim:

Figure 11: Prompt for question decomposition on fact verification tasks.

You have the following passages and table:

Passages: {passages}

# Tables: {tables}

Please break down the question “{question}” into multiple specific sub-questions that address individual components of the original question, with the table and passages as the reference. Use ### to mark the start of each sub-question.

Decomposed question:

Figure 12: Prompt for question decomposition on document-level reasoning tasks.

# F.3 Prompts for subquestion answering

You have the following context passages: {passages}

Please answer the question “{subquestion}” with a short span using the context as reference. If no answer is found in the context, use your own knowledge. Your answer needs to be as short as possible.

Figure 13: Prompt for subquestion answering on complex question answering tasks.

You have the following context passages: {passages}

Please verify whether the claim “{subquestion}” is correct using the context as reference. If no answer is found in the context, use your own knowledge. Please only output Yes or No and do not give any explanation.

Figure 14: Prompt for subquestion answering on fact verification tasks.

You have the following passages and tables:

Passage: {passages}

Table: {tables}

For the question “{subquestion}”, write a Python program to solve the question. Store the final result in the variable ans.

Figure 15: Prompt for subquestion answering on document-level reasoning tasks with PoT.

You have the following passages and tables:

Passage: {passages}

# Table:

# {tables}

For the question “{subquestion}”, reason step by step to calculate the final answer. Please use \boxed{} to wrap your final answer.

Figure 16: Prompt for subquestion answering on document-level reasoning tasks with CoT.

# F.4 Prompts for final answer generation

You have the following passages: {passages}

You are also given some subquestions and their answers: # subquestion #1: {subquestion_1} Answer: {answer_1} # subquestion #2: {subquestion_2} Answer: {answer_2}

Please answer the question “{the_original_question}” with a short span using the documents and subquestions as reference.

Make sure your response is grounded in documents and provides clear reasoning followed by a concise conclusion. If no relevant information is found, use your own knowledge.

Wrap your answer with <answer> and </answer> tags.

Figure 17: Prompt for final answer generation on complex question answering tasks.

You are given some subquestions and their answers: # subquestion #1: {subquestion_1} Answer: {answer_1} # subquestion #2: {subquestion_2} Answer: {answer_2}

Please answer the question “{the_original_question}” with only Yes or No using the subquestions as reference. Provides clear reasoning followed by a concise conclusion. If no relevant information is found, use your own knowledge.

Wrap your answer with <answer> and </answer> tags.

Figure 18: Prompt for final answer generation on fact verification tasks.

You have the following passages and table:

Passages: {passage}

For the question “{question}”, here is a referenced breakdown: {decomposition}.

Write a Python program to solve the question. Store the final result in the variable ans.

Figure 19: Prompt for final answer generation on document-level reasoning tasks with PoT.

You have the following passages and table:

# Passages:

{passage}

For the question “{question}”, here is a referenced breakdown: {decomposition}.

Reason step by step to calculate the final answer. Please use \boxed{} to wrap your final answer.

Figure 20: Prompt for final answer generation on document-level reasoning tasks with CoT.

# F.5 Prompts for InstructRAG

Read the following documents relevant to the given question: {question}

Documents: {documents} ...

Please identify documents that are useful to answer the given question: “{question}”. If none of the documents is aligned with the answer, in that case, you have to explain the answer only based on your own knowledge, without referring to the provided information.

Note that the question may be compositional and require intermediate analysis to deduce the final answer. Make sure your response is grounded and provides clear reasoning details followed by a concise conclusion. Your answer should be in a short span with a few keywords. Use <answer> and </answer> tag to mark your final answer.

Figure 21: Prompt for InstructRAG on complex question answering tasks.

Read the following documents relevant to the given question: {question}

Documents: {documents} ·

Please identify documents that are useful to answer the given question: “{question}”. If none of the documents is aligned with the answer, in that case, you have to explain the answer only based on your own knowledge, without referring to the provided information.

Note that the question may be compositional and require intermediate analysis to deduce the final answer. Make sure your response is grounded and provides clear reasoning details followed by a concise conclusion. Your answer should be yes or no only. Use <answer> and </answer> tag to mark your final answer.

Figure 22: Prompt for InstructRAG on fact verification tasks.

# G Additional Implementation Details

# G.1 Implementation Details for SFT

For SFT, we set the batch size to 64 for every example, and set the learning rate as Table 7. With maximum number of tokens to 2560.

Table 6: Results for different model sizes for SFT.   

<table><tr><td>Model Size</td><td>Learning Rate</td><td> Warmup Steps</td></tr><tr><td>AceSearcher 1.5B</td><td>5e-6</td><td>5%</td></tr><tr><td>AceSearcher 8B</td><td>1e-6</td><td>5%</td></tr><tr><td>AceSearcher 14B</td><td>le-6</td><td>5%</td></tr><tr><td>AceSearcher 32B (LoRA)</td><td>le-5</td><td>5%</td></tr></table>

# G.2 Implementation Details for RFT

We set the hyperparameters to $m = 3$ , $m ^ { \prime } = 4$ , and $t = 1 . 0$ when generating multiple rollouts. Examples with identical maximum and minimum rewards are discarded. For RFT, we use $\beta = 0 . 1$

Table 7: Results for different model sizes for RFT.   

<table><tr><td>Model Size</td><td>Learning Rate</td><td> Warmup Steps</td></tr><tr><td>AceSearcher 1.5B</td><td>1e-6</td><td>5%</td></tr><tr><td>AceSearcher 8B</td><td>5e-7</td><td>5%</td></tr><tr><td>AceSearcher 14B</td><td>5e-7</td><td>5%</td></tr><tr><td>AceSearcher 32B (LoRA)</td><td>1e-6</td><td>5%</td></tr></table>

and run for the DPO for 2 iterations by default. All models are optimized using AdamW with $\beta _ { 1 } = 0 . 9$ and $\beta _ { 2 } = 0 . 9 8$ , and experiments are conducted on 8 NVIDIA A100 GPUs.

# G.3 Implementation Details for Baselines

We implement and evaluate a variety of baselines using standardized decoding and prompting configurations to ensure fair comparison. For Qwen-3, we follow the official guidance5 to adopt distinct sampling strategies depending on the task setting. In thinking mode (enable_thinking $=$ True), we use temperature $= 0 . 6$ , top- $\cdot { \tt p } = 0 . 9 5$ , top- $\mathbf { \partial } \cdot \mathbf { k } = 2 0$ , and min- $\mathtt { p } = 0$ to encourage diverse yet coherent generation. Greedy decoding is explicitly avoided to prevent performance degradation and repetitive outputs. In non-thinking mode (enable_thinking=False), we slightly increase the temperature to 0.7 and reduce top-p to 0.8 while keeping top- $\mathbf { \nabla } \cdot \mathbf { k }$ and min- $\boldsymbol { \cdot } \boldsymbol { \mathrm { p } }$ unchanged. In practice, we find that using the thinking mode leads to slightly better performance despite being slower. For R1-distill models, we set the maximum generation length to 32,768 tokens and use temperature $= 0 . 6$ , top- $\cdot { \tt p } = 0 . 9 5$ . In Plan-RAG, we incorporate 3-shot demonstrations in the prompt to guide the model toward producing outputs in the correct format. For InstructRAG, we use the same SFT training set as AceSearcher and generate CoT-style demonstrations tailored to context-rich QA datasets. For Llama-4, GPT-4.1, and GPT-4o, we use greedy decoding (temperature ${ } = 0$ ) for consistency with their default inference behavior. For IRCOT and RAG-Star, we reproduce results by following the original repositories and hyperparameter settings. For these methods, we tune the number of retrieved passages from $\{ 5 , 1 0 , 2 0 \}$ and report the best performance. We refer to other baselines’ reported numbers in the corresponding paper.

# H Additional Experimental Results

![](images/ce209da2fa6d0f84da1c78f7735ad86a38512c0e66358dc66bab4f7e5d89dbd7.jpg)  
Figure 23: Parameter Study on $\beta$

![](images/62791c51ca463121ab440475fc60c9120232eedd1f71ac4e84751ecd7c6c388f.jpg)  
Figure 24: Effect of different retrievers.

Effect of $\beta$ . We study the effect of $\beta$ in preference optimization with Llama-3.1-8B as the backbone, and find that AceSearcher is generally robust to this parameter, with $\beta = 0 . 1$ leads to slightly better performance.

Effect of Different Retrievers. We evaluate AceSearcher and representative baselines (at the 8B scale) using two different retrievers: Dragon6 and Contriever7. Overall, the E5 retriever achieves the best performance, supporting our hypothesis that stronger retrieval models yield more relevant passages and thus enhance answer quality. Notably, AceSearcher consistently outperforms baselines across different retrievers, demonstrating its robustness to retrieval choices.

Table 8: Performance comparison across models and prompting methods.   

<table><tr><td>Model</td><td>Prompt Method</td><td>DMSimpShort</td><td>DMCompShort</td><td>DMSimpLong</td><td>DMCompLong</td><td>Avg.</td></tr><tr><td>AceSearcher-32B</td><td>PoT</td><td>89.5</td><td>84.0</td><td>53.0</td><td>43.0</td><td>66.1</td></tr><tr><td>AceSearcher-14B</td><td>PoT</td><td>84.0</td><td>82.0</td><td>49.0</td><td>39.3</td><td>62.4</td></tr><tr><td>AceSearcher-8B</td><td>PoT</td><td>83.0</td><td>80.5</td><td>48.0</td><td>32.3</td><td>59.0</td></tr><tr><td>AceSearcher-1.5B</td><td>PoT</td><td>66.5</td><td>77.5</td><td>39.0</td><td>18.0</td><td>47.6</td></tr><tr><td>AceSearcher-32B</td><td>CoT</td><td>73.5</td><td>70.0</td><td>50.0</td><td>33.0</td><td>54.5</td></tr><tr><td>AceSearcher-14B</td><td>CoT</td><td>78.5</td><td>75.5</td><td>44.0</td><td>34.7</td><td>57.0</td></tr><tr><td>AceSearcher-8B</td><td>CoT</td><td>44.0</td><td>31.5</td><td>30.0</td><td>15.7</td><td>28.5</td></tr><tr><td>AceSearcher-1.5B</td><td>CoT</td><td>37.5</td><td>32.0</td><td>18.0</td><td>9.7</td><td>23.2</td></tr></table>

Comparison of CoT and PoT for Document-level Reasoning. Table 8 presents a comparison between Program of Thought (POT) and Chain of Thought (COT) prompting methods across four evaluation settings. POT consistently outperforms COT across all tasks, with notable improvements on both simple and complex reasoning benchmarks. For example, across models, POT yields higher average scores than COT on $\mathrm { D M _ { C o m p L o n g } }$ (e.g., 43.0 vs. 33.0 for AceSearcher-32b) and DMSimpShort (e.g., 89.5 vs. 73.5 for AceSearcher-32b), demonstrating its advantage in guiding structured reasoning. These results highlight the effectiveness of POT in enhancing model performance on decision-making tasks requiring multi-step reasoning, regardless of model scale.

# I Case Studies

Details of Human Study Our human study has received IRB approval from our institute. The below is the form used in human evaluation:

You are provided with:

• The original complex question • A proposed decomposition into subquestions

Please assess the overall quality of the decomposition using the criteria below.

• Relevance: Do the subquestions help solve the original question?   
• Completeness: Are all important aspects covered?   
• Coherence: Is the breakdown logically structured and easy to follow?   
• Usefulness: Does the decomposition make the reasoning process easier or more interpretable?

Please rate the overall quality of the subquestion decomposition.

• 1: Very Poor: Subquestions are irrelevant, incomplete, or incoherent.   
• 2: Poor: Some relevance, but major gaps or unclear logic.   
• 3: Fair: Moderately helpful with minor issues in coverage or clarity.   
• 4: Good: Clear and mostly complete decomposition.   
• 5: Excellent: Subquestions are highly relevant, complete, and well-structured, with proper reference to answers from previous subquestions.

# Details of Case Study

We present two case studies from the MusiQue, 2WikiMHQA and DocMathEval datasets in Tables 9, 10 and 11. Despite its larger size, the Qwen3-32B-reasoning model struggles with handling complex

questions. In contrast, AceSearcher effectively decomposes each question into manageable subquestions, generates accurate answers for each sub-questions, and performs multi-step reasoning to arrive at the correct final answer.

Table 9: A case study from MusiQue dataset.   

<table><tr><td> A sample from MusiQue</td></tr><tr><td>Question: In which state is Vera Barbosa&#x27;s place of birth located? Ground Truth Answer: Lisbon District</td></tr><tr><td>AceSearcher-8B Sub-question 1: Who is Vera Barbosa?</td></tr><tr><td>Answer1:a Portuguese track and field athlete Sub-question 2:Where was Vera Barbosa born? Answer 2:Vila Franca de Xira Sub-question 3: In which state is #2 located?</td></tr></table>

# Final Answer:

The documents state that Vera Barbosa is a Portuguese track and field athlete and was born in Vila Franca de Xira. Additionally, Vila Franca de Xira is located in the Lisbon District. Therefore, Vera Barbosa’s place of birth, Vila Franca de Xira, is in the Lisbon District.

# <answer>Lisbon District</answer>

# Qwen3-32B Reasoning

<think>

Okay, let’s see. The question is asking about the state where Vera Barbosa’s place of birth is located. First, I need to figure out which Vera Barbosa they’re referring to here because there are several people named Vera Barbosa in the provided contexts.

Looking at the first entry: Vera Barbosa, born 13 January 1989 in Vila Franca de Xira, Portugal. That’s a Portuguese athlete. Then there’s another Vera Krasova, a Russian model, and Vera Begic, a Croatian athlete.´ There’s also a mention of a place called Barbosa in Colombia and Brazil. But the key here is the name Vera Barbosa specifically.

The user is asking about Vera Barbosa’s birthplace state. The first context says she was born in Vila Franca de Xira, which is in Portugal. However, the question is phrased as "In which state is Vera Barbosa’s place of birth located?" So, states are typically administrative divisions in countries like the US, Brazil, etc. Portugal is divided into districts, not states. But maybe the user is using "state" in a general sense here.

Wait, but looking at other entries, there’s a Carlos Barbosa in Brazil’s Rio Grande do Sul state, and Bárbara Barbosa is a Brazilian footballer. But the specific Vera Barbosa mentioned in the first paragraph is the Portuguese athlete. Her birthplace is Vila Franca de Xira, Portugal. Since Portugal doesn’t have states, but the question uses "state," perhaps the answer is Portugal. Alternatively, if the user is confused and actually refers to a different person, but based on the given data, the only Vera Barbosa with a birthplace listed is the Portuguese one. Therefore, the answer should be Portugal.   
</think>

<answer>Portugal</answer>

Table 10: A case study from 2WikiMHQA dataset.   

<table><tr><td>A sample from 2WikiMHQA</td></tr><tr><td>Question: Which film has the director who was born later, The Silver Treasure or Taxi To Paradise? Ground Truth Answer: Taxi To Paradise</td></tr><tr><td>AceSearcher-8B Sub-question 1: Who directed The Silver Treasure?</td></tr><tr><td>Answer1: Rowland V.Lee Sub-question 2:Who directed Taxi To Paradise? Answer 2:Adrian Brunel Sub-question 3: When was the director of #1 born? Answer 3:September 6,1891</td></tr></table>

# Final Answer:

From the documents, “The Silver Treasure” was directed by Rowland V. Lee, born on September 6, 1891 (Q3), and "Taxi To Paradise" was directed by Adrian Brunel, born on September 4, 1892 (Q4). Comparing these dates, Adrian Brunel was born later than Rowland V. Lee (Q5 confirms this). Thus, the film with the director born later is “Taxi To Paradise.”

# <answer>Taxi To Paradise</answer>

# Qwen3-32B Reasoning

<think>

Okay, let’s see. The user is asking which film has the director born later between The Silver Treasure and Taxi to Paradise.

First, I need to find the directors of both films. From the context:

- The Silver Treasure (1926) is directed by Rowland V. Lee. - Taxi to Paradise (1933) is directed by Adrian Brunel.

Now, I need to check their birth dates. The context doesn’t provide birth dates for these directors. So I’ll have to rely on my own knowledge.

Rowland V. Lee was born on April 22, 1894. Adrian Brunel was born on October 2, 1887. Wait, Brunel was born earlier than Lee? Wait, no: if Brunel was born in 1887 and Lee in 1894, then Brunel was born earlier. Therefore, Rowland V. Lee was born later. So The Silver Treasure’s director was born later than Taxi to Paradise’s director. Therefore, the answer is The Silver Treasure.   
</think>

<answer>The Silver Treasure</answer>

A sample from DMCS subset of DocMathEval.

Table:   
Question: What is the percentage change in Asia sales between 2018 and 2019 if the 2019 sales is doubled and increased by another 400 thousand? (in percent) Ground Truth Answer: 151.5705   

<table><tr><td>Year</td><td>Segment</td><td>Americas</td><td>Europe</td><td>Asia</td><td>Total</td><td>% of Total</td></tr><tr><td colspan="7">(Amountsin thousands)</td></tr><tr><td>2019 2019 2019</td><td>TS HPP Total</td><td>$67,728 $5,294 $72,522</td><td>$3,285 $771 $4,056</td><td>$646 $1,837 $2,483</td><td>$71,159 $7,902 $79,061</td><td>90% 10% 100%</td></tr><tr><td>2019 2018</td><td>% of Total TS</td><td>92% $52,034</td><td>5% $9,059</td><td>3% $1,344</td><td>100% $62,437</td><td>86%</td></tr><tr><td>2018</td><td>HPP</td><td>$8,424</td><td>$1,266</td><td>$789</td><td>$10,479</td><td>14%</td></tr><tr><td>2018</td><td>Total</td><td>$60,458</td><td>$10,325</td><td></td><td></td><td></td></tr><tr><td>2018</td><td>% of Total</td><td>83%</td><td>14%</td><td>$2,133 3%</td><td>$72,916 100%</td><td>100%</td></tr></table>

Table 12: The following table details the Company’s sales by operating segment for fiscal years ended September 30, 2019 and 2018. The Company’s sales by geographic area based on the location of where the products were shipped or services rendered are as follows: Substantially all Americas amounts are United States.

# AceSearcher-8B

Sub-question 1: What was the value of Asia sales in 2019?

-question 2: What is the value of Asia sales in 2019 after doubling it?

Sub-question 3: What is the value of Asia sales in 2019 aft

Sub-question 4: What was the value of Asia sales in 2018?

Sub-question 5: What is the net change in the value of Asia sales from 2018 to 2019, after adjusting the 2019 value?

Sub-question 6: What is the percentage change in the value of Asia sales from 2018 to 2019, after adjusting the 2019 value?

# Final Answer:

# Given data asia_sales $. 2 0 1 9 \ = \ 2 4 8 3$ # in thousands (Q1) asia_sales $2 0 1 8 \ = \ 2 1 3 3$ # in thousands (Q4)

# Adjust 2019 sales: double it and add 400 thousand (Q2, Q3) adjusted_2019_sales $=$ (asia_sales_2019 $^ *$ 2) $^ +$ 400

# Compute value change (Q5) change_in_sales $=$ adjusted_2019_sales - asia_sales_2018

# Compute percentage change (Q6) ans $=$ (change_in_sales / asia_sales_2018) $^ *$ 100

# 151.57055789967183

# Qwen3-32B Reasoning

# Original 2019 Asia sales in thousands original_2019_asia $=$ 646

# Adjusted 2019 sales after doubling and adding 400 thousand adjusted_2019_asia $=$ original_2019_asia $* \ 2 \ + \ 4 0 0$

# Original 2018 Asia sales in thousands original_2018_asia $=$ 1344

# Calculate percentage change   
percentage_change $=$ ((adjusted_2019_asia - original_2018_asia) /   
original_2018_asia) $^ *$ 100   
ans $=$ percentage_change

25.892857142857146